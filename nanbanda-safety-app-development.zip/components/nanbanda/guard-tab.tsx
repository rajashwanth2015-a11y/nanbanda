'use client'

import { useEffect, useRef, useState } from 'react'
import {
  AlertTriangle,
  AudioLines,
  Bike,
  Car,
  Compass,
  Crosshair,
  FileText,
  Gauge,
  Hospital,
  Loader2,
  MapPin,
  MessageCircle,
  Moon,
  Phone,
  Power,
  Volume2,
} from 'lucide-react'
import { generatePoliceReport } from '@/lib/police-report'
import { getPosition, speak, useApp } from '@/lib/store'
import { cn } from '@/lib/utils'
import { Panel, SectionTitle, ToggleRow } from './primitives'

const HOSPITALS = [
  { ta: 'காவேரி அவசர சிகிச்சை மையம்', en: 'Kauvery Emergency Care Centre', km: '0.8', phone: '9876543210' },
  { ta: 'அப்போலோ ட்ராமா கேர்', en: 'Apollo Trauma Care', km: '1.5', phone: '9876543211' },
  { ta: 'அரசு பொது மருத்துவமனை', en: 'Government General Hospital', km: '2.3', phone: '9876543212' },
]

const bikeMsg = (n: string) =>
  `வணக்கம் ${n}, பயணம் பாதுகாப்பாக அமைய வாழ்த்துகள்! வேகம் வேண்டாம். நண்பேன்டா உங்களுடன் விழிப்புடன் இருக்கும்!`
const cabMsg = (n: string) =>
  `வணக்கம் ${n}, உங்கள் பயணம் தொடங்கியாச்சு. கவலை வேண்டாம், உங்களது வழித்தடத்தை நான் தொடர்ந்து கண்காணித்துக் கொண்டிருக்கிறேன், தைரியமாகச் செல்லுங்கள்!`

export function GuardTab() {
  const [pos, setPos] = useState<{ lat: number; lng: number } | null>(null)
  return (
    <div className="flex flex-col gap-4">
      <LiveMap pos={pos} setPos={setPos} />
      <Hospitals pos={pos} />
      <AntiTheft />
      <PoliceReport />
      <DrunkDrivingGuard />
      <Sensors />
      <VoiceGuard />
    </div>
  )
}

function LiveMap({
  pos,
  setPos,
}: {
  pos: { lat: number; lng: number } | null
  setPos: (p: { lat: number; lng: number }) => void
}) {
  const { L, gpsLog } = useApp()
  const [locating, setLocating] = useState(false)
  const current = pos ?? (gpsLog[0] ? { lat: gpsLog[0].lat, lng: gpsLog[0].lng } : { lat: 13.0827, lng: 80.2707 })
  const d = 0.008
  const bbox = `${current.lng - d},${current.lat - d},${current.lng + d},${current.lat + d}`

  const locate = async () => {
    setLocating(true)
    setPos(await getPosition())
    setLocating(false)
  }

  return (
    <Panel className="p-0 overflow-hidden">
      <div className="flex items-center justify-between gap-2 p-4 pb-3">
        <h2 className="flex items-center gap-2 text-base font-bold text-gold">
          <MapPin className="size-5 text-primary" aria-hidden />
          {L('நேரடி லொகேஷன் மேப்', 'Live Location Map')}
        </h2>
        <span className="inline-flex items-center gap-1.5 rounded-full border-2 border-primary/60 bg-primary/15 px-2.5 py-0.5 text-[11px] font-bold text-primary">
          <span className="pulse-dot size-2 rounded-full bg-primary" aria-hidden />
          {L('நேரலை', 'LIVE')}
        </span>
      </div>
      <div className="relative h-64 border-y-2 border-white/15 bg-secondary">
        <iframe
          title={L('உங்கள் தற்போதைய இருப்பிடம்', 'Your current location')}
          src={`https://www.openstreetmap.org/export/embed.html?bbox=${bbox}&layer=mapnik&marker=${current.lat},${current.lng}`}
          className="size-full grayscale-[30%] contrast-125"
          loading="lazy"
        />
        <div className="pointer-events-none absolute inset-x-3 bottom-3 rounded-xl border-2 border-white/20 bg-background/90 px-3 py-2 font-mono text-xs font-bold">
          <span className="text-primary">GPS</span> {current.lat.toFixed(5)}° N, {current.lng.toFixed(5)}° E
        </div>
      </div>
      <div className="p-4 pt-3">
        <button
          type="button"
          onClick={locate}
          disabled={locating}
          className="btn-thick flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3.5 font-bold text-primary-foreground disabled:opacity-60"
        >
          {locating ? <Loader2 className="size-5 animate-spin" aria-hidden /> : <Crosshair className="size-5" aria-hidden />}
          {L('என் இருப்பிடத்தைப் புதுப்பி', 'Refresh my location')}
        </button>
      </div>
    </Panel>
  )
}

function Hospitals({ pos }: { pos: { lat: number; lng: number } | null }) {
  const { L } = useApp()
  const share = (h: (typeof HOSPITALS)[number]) => {
    const loc = pos ? ` https://maps.google.com/?q=${pos.lat},${pos.lng}` : ''
    const text = `🏥 ${h.ta} (${h.km} கி.மீ) - 📞 ${h.phone}. அவசர உதவி தேவை! என் இருப்பிடம்:${loc}`
    window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, '_blank', 'noopener,noreferrer')
  }
  return (
    <Panel>
      <SectionTitle icon={<Hospital className="size-5 text-sos" aria-hidden />}>
        {L('அருகிலுள்ள அவசர சிகிச்சை மருத்துவமனைகள்', 'Nearby Emergency Hospitals')}
      </SectionTitle>
      <ol className="flex flex-col gap-3">
        {HOSPITALS.map((h, i) => (
          <li key={h.phone} className="rounded-xl border-2 border-white/15 bg-secondary p-3">
            <div className="flex items-start gap-3">
              <span className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-sos font-black text-foreground">{i + 1}</span>
              <div className="min-w-0 flex-1">
                <p className="font-bold leading-snug">{L(h.ta, h.en)}</p>
                <p className="mt-0.5 text-sm text-foreground/80">
                  <span className="font-bold text-primary">{h.km} {L('கி.மீ', 'km')}</span>
                  <span aria-hidden> · </span>
                  <span className="font-mono">{h.phone}</span>
                </p>
              </div>
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <a
                href={`tel:${h.phone}`}
                className="btn-thick flex items-center justify-center gap-1.5 rounded-lg bg-primary py-2.5 text-sm font-bold text-primary-foreground"
              >
                <Phone className="size-4" aria-hidden />
                {L('அழைக்கவும்', 'Call')}
              </a>
              <button
                type="button"
                onClick={() => share(h)}
                className="btn-thick flex items-center justify-center gap-1.5 rounded-lg bg-whatsapp py-2.5 text-sm font-bold text-background"
              >
                <MessageCircle className="size-4" aria-hidden />
                {L('வாட்ஸ்அப் பகிர்வு', 'WhatsApp')}
              </button>
            </div>
          </li>
        ))}
      </ol>
    </Panel>
  )
}

function AntiTheft() {
  const { activateSOS, emergency, L } = useApp()
  return (
    <Panel>
      <SectionTitle icon={<Power className="size-5" aria-hidden />}>
        {L('போலி சுவிட்ச்-ஆஃப் பாதுகாப்பு', 'Stealth Fake Power-Off')}
      </SectionTitle>
      <p className="text-sm leading-relaxed text-foreground/90">
        {L(
          'திருடன் போனை ஆஃப் செய்துவிட்டதாக ஏமாறுவான். ஆனால் பின்னணியில் உங்கள் போனின் லைவ் ஜிபிஎஸ் ட்ராக்கிங், திருடனின் முகத்தைப் படம் பிடிக்கும் முன���பக்க கேமரா, மற்றும் கிளவுட் வாய்ஸ் ரெக்கார்டிங் 24 மணிநேரமும் ரகசியமாக ஓடிக்கொண்டே இருக்கும்!',
          'The thief will believe the phone is switched off. But live GPS tracking, the front camera capturing the thief’s face, and cloud voice recording keep running secretly in the background 24 hours!',
        )}
      </p>
      <button
        type="button"
        disabled={emergency.stage !== 'idle'}
        onClick={() => activateSOS('Manual SOS')}
        className="btn-thick mt-4 w-full rounded-xl border-2 border-white/20 bg-background py-3.5 text-sm font-bold text-foreground disabled:opacity-50"
      >
        {L('SOS தொடங்கி ஸ்டெல்த் சோதனை செய்', 'Start SOS to test stealth mode')}
      </button>
    </Panel>
  )
}

function PoliceReport() {
  const { userName, imei, contacts, gpsLog, showToast, L } = useApp()
  const [busy, setBusy] = useState(false)

  const onGenerate = async () => {
    setBusy(true)
    try {
      const ref = await generatePoliceReport({ userName, imei, contacts, gpsLog })
      showToast(L(`அறிக்கை ${ref} பதிவிறக்கம் செய்யப்பட்டது`, `Report ${ref} downloaded`))
    } finally {
      setBusy(false)
    }
  }

  return (
    <Panel>
      <SectionTitle icon={<FileText className="size-5" aria-hidden />}>{L('காவல் துறை உதவி அறிக்கை', 'Police Assistance Report')}</SectionTitle>
      <div role="note" className="flex gap-3 rounded-xl border-2 border-sos bg-sos/15 p-3">
        <AlertTriangle className="mt-0.5 size-6 shrink-0 text-sos" aria-hidden />
        <p className="text-sm leading-relaxed">
          <strong className="font-black text-sos">{L('சட்ட எச்சரிக்கை:', 'Legal warning:')}</strong>{' '}
          {L(
            'திருடனை நீங்கள் நேரடியாகப் பிடிக்கச் செல்லக் கூடாது! அது ஆபத்தானது. இந்த ஆதாரங்களை காவல்துறையிடம் ஒப்படைக்கவும்.',
            'Never try to catch the thief yourself! It is dangerous. Hand this evidence over to the police.',
          )}
        </p>
      </div>
      <dl className="mt-3 grid grid-cols-2 gap-2 text-sm">
        <div className="rounded-xl border-2 border-white/10 bg-secondary p-3">
          <dt className="text-xs text-foreground/75">{L('சாதன IMEI', 'Device IMEI')}</dt>
          <dd className="mt-0.5 font-mono font-bold">{imei}</dd>
        </div>
        <div className="rounded-xl border-2 border-white/10 bg-secondary p-3">
          <dt className="text-xs text-foreground/75">{L('பதிவான GPS புள்ளிகள்', 'GPS points logged')}</dt>
          <dd className="mt-0.5 font-bold">{gpsLog.length}</dd>
        </div>
      </dl>
      <button
        type="button"
        onClick={onGenerate}
        disabled={busy}
        className="btn-thick mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-neon py-4 font-black text-background disabled:opacity-60"
      >
        {busy ? <Loader2 className="size-5 animate-spin" aria-hidden /> : <FileText className="size-5" aria-hidden />}
        {L('காவல்துறை டிராக்கிங் PDF அறிக்கை', 'Police Tracking PDF Report')}
      </button>
    </Panel>
  )
}

const DRUNK_MSG =
  'நண்பா, உங்களது தற்போதைய அசைவுகள் வண்டி ஓட்டுவதற்குப் பாதுகாப்பாக இல்லை. உங்கள் உயிரும், உங்களை நம்பியிருக்கும் குடும்பமும் முக்கியம். தயவுசெய்து வாகனத்தை இயக்க வேண்டாம்! உங்களுக்கு ஆட்டோ அல்லது கேப் புக் செய்யவா?'

function DrunkDrivingGuard() {
  const { L, showToast } = useApp()
  const [phase, setPhase] = useState<'idle' | 'analysing' | 'warn' | 'booking' | 'booked'>('idle')
  const [sway, setSway] = useState<number[]>([])

  useEffect(() => {
    if (phase !== 'analysing') return
    let n = 0
    const id = setInterval(() => {
      n++
      setSway((s) => [...s, 20 + Math.random() * 70].slice(-18))
      if (n >= 14) {
        clearInterval(id)
        setPhase('warn')
      }
    }, 120)
    return () => clearInterval(id)
  }, [phase])

  useEffect(() => {
    if (phase === 'warn') speak(DRUNK_MSG)
    if (phase !== 'booking') return
    const id = setTimeout(() => setPhase('booked'), 2000)
    return () => clearTimeout(id)
  }, [phase])

  const close = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) window.speechSynthesis.cancel()
    setPhase('idle')
    setSway([])
  }

  return (
    <Panel>
      <SectionTitle icon={<Car className="size-5 text-primary" aria-hidden />} hint={L('ரகசியம்', 'Private')}>
        {L('மது அருந்தி வாகனம் ஓட்டுதல் எச்சரிக்கை', 'Stealth Drunk Driving Warning')}
      </SectionTitle>
      <p className="text-sm leading-relaxed text-foreground/90 text-pretty">
        {L(
          'வண்டி ஓட்டத் தொடங்கும் முன் உங்கள் அசைவுகள் தடுமாறினால், குடும்பத்திற்குத் தெரிவிக்காமல் உங்களுக்கு மட்டும் ரகசியமாக எச்சரிக்கை காட்டப்படும்.',
          'If your movement is unsteady before driving, a private warning is shown only to you — your family is not alerted.',
        )}
      </p>
      <div className="mt-3 flex h-16 items-end gap-1 rounded-xl border-2 border-white/15 bg-secondary p-2" aria-hidden>
        {(sway.length ? sway : Array.from({ length: 18 }, () => 12)).map((h, i) => (
          <span key={i} className={cn('flex-1 rounded-sm', h > 60 ? 'bg-sos' : 'bg-primary/70')} style={{ height: `${h}%` }} />
        ))}
      </div>
      <button
        type="button"
        onClick={() => {
          setSway([])
          setPhase('analysing')
        }}
        disabled={phase === 'analysing'}
        className="btn-thick mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3.5 font-black text-primary-foreground disabled:opacity-60"
      >
        {phase === 'analysing' ? <Loader2 className="size-5 animate-spin" aria-hidden /> : <Gauge className="size-5" aria-hidden />}
        {phase === 'analysing' ? L('அசைவுகள் ஆய்வு செய்யப்படுகின்றன…', 'Analysing movement…') : L('தடுமாறும் அசைவு சோதனை', 'Test unsteady movement')}
      </button>

      {phase === 'warn' || phase === 'booking' || phase === 'booked' ? (
        <div role="alertdialog" aria-modal="true" aria-labelledby="drunk-title" className="absolute inset-0 z-50 flex flex-col justify-center gap-5 overflow-y-auto bg-background px-5 py-8 animate-in fade-in">
          <span className="mx-auto flex size-20 items-center justify-center rounded-full border-4 border-primary bg-primary/15 text-primary">
            <AlertTriangle className="size-10" aria-hidden />
          </span>
          <h2 id="drunk-title" className="text-center text-xl font-black text-primary">
            {L('நண்பனின் அன்பான எச்சரிக்கை', "A friend's caring warning")}
          </h2>
          <p className="rounded-2xl border-2 border-primary/60 bg-card p-4 text-lg font-bold leading-relaxed text-pretty">
            {L(DRUNK_MSG, 'Friend, your current movements are not safe for driving. Your life, and the family that depends on you, matter. Please do not drive! Shall I book an auto or cab for you?')}
          </p>
          <p className="text-center text-xs font-semibold text-foreground/70">
            {L('இந்த எச்சரிக்கை உங்கள் குடும்பத்திற்கு அனுப்பப்படவில்லை.', 'This warning was not sent to your family.')}
          </p>
          {phase === 'booked' ? (
            <div className="rounded-2xl border-2 border-success bg-success/10 p-4 text-center">
              <p className="text-lg font-black text-success">{L('ஆட்டோ புக் செய்யப்பட்டது! 4 நிமிடத்தில் வரும்', 'Auto booked! Arriving in 4 min')}</p>
              <p className="mt-1 font-mono text-sm">TN 09 AK 2231 · OTP 4821</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {[
                { ta: 'ஆட்டோ புக் செய்', en: 'Book Auto' },
                { ta: 'கேப் புக் செய்', en: 'Book Cab' },
              ].map((b) => (
                <button
                  key={b.en}
                  type="button"
                  disabled={phase === 'booking'}
                  onClick={() => setPhase('booking')}
                  className="btn-thick flex items-center justify-center gap-2 rounded-2xl bg-success py-4 font-black text-background disabled:opacity-60"
                >
                  {phase === 'booking' ? <Loader2 className="size-5 animate-spin" aria-hidden /> : <Car className="size-5" aria-hidden />}
                  {L(b.ta, b.en)}
                </button>
              ))}
            </div>
          )}
          <button
            type="button"
            onClick={() => {
              close()
              if (phase !== 'booked') showToast(L('பாதுகாப்பாக இருங்கள் நண்பா', 'Stay safe, friend'))
            }}
            className="rounded-2xl border-2 border-white/25 py-3.5 font-bold"
          >
            {phase === 'booked' ? L('சரி, மூடு', 'OK, close') : L('நான் வண்டி ஓட்டமாட்டேன்', "I won't drive")}
          </button>
        </div>
      ) : null}
    </Panel>
  )
}

function Sensors() {
  const { sensors, update, L } = useApp()
  const set = (k: keyof typeof sensors) => (v: boolean) => update({ sensors: { ...sensors, [k]: v } })
  return (
    <Panel>
      <SectionTitle>{L('பின்னணி சென்சார்கள்', 'Background Sensors')}</SectionTitle>
      <div className="divide-y divide-white/10">
        <ToggleRow icon={<Gauge className="size-4" />} title={L('முடுக்கமானி', 'Accelerometer')} desc={L('வேகம், திடீர் பிரேக், மோதல் கண்டறிதல்', 'Detects acceleration, braking & impact')} checked={sensors.accelerometer} onChange={set('accelerometer')} />
        <ToggleRow icon={<Compass className="size-4" />} title={L('கைரோஸ்கோப்', 'Gyroscope')} desc={L('சாய்வு, சறுக்கல், விழுதல் கண்டறிதல்', 'Detects tilt, skid & fall')} checked={sensors.gyroscope} onChange={set('gyroscope')} />
        <ToggleRow icon={<AudioLines className="size-4" />} title={L('ஒலி சென்சார்', 'Acoustic sensor')} desc={L('அலறல் மற்றும் பிரேக் சத்தம் கண்டறிதல்', 'Scream & screech recognition')} checked={sensors.acoustic} onChange={set('acoustic')} />
        <ToggleRow icon={<Volume2 className="size-4" />} title={L('தானியங்கி குரல் அறிவிப்பு', 'Automatic voice prompts')} desc={L('பயணம் தொடங்கும்போது தமிழ் குரல் வாழ்த்து', 'Tamil voice greeting when a trip starts')} checked={sensors.voicePrompts} onChange={set('voicePrompts')} />
      </div>
    </Panel>
  )
}

function VoiceGuard() {
  const { userName, sensors, showToast, L } = useApp()
  const [vehicle, setVehicle] = useState<'bike' | 'cab'>('bike')
  const [last, setLast] = useState<string | null>(null)
  const isNight = (() => {
    const h = new Date().getHours()
    return h >= 19 || h < 6
  })()

  const simulate = () => {
    const text = vehicle === 'bike' ? bikeMsg(userName) : cabMsg(userName)
    setLast(text)
    if (!sensors.voicePrompts) return showToast(L('குரல் அறிவிப்பு அணைக்கப்பட்டுள்ளது', 'Voice prompts are off'))
    if (!speak(text)) showToast(L('இந்த சாதனத்தில் குரல் வசதி இல்லை', 'Text-to-speech not supported'))
  }

  return (
    <Panel>
      <SectionTitle hint={isNight ? L('இரவு பயன்முறை', 'Night mode') : undefined}>{L('குரல் காவலர் உதவியாளர்', 'Voice Guard Assistant')}</SectionTitle>
      <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label={L('வாகன வகை', 'Vehicle type')}>
        {[
          { id: 'bike' as const, label: L('பைக் / கார்', 'Bike / Car'), icon: Bike },
          { id: 'cab' as const, label: L('ஆட்டோ / கேப்', 'Auto / Cab'), icon: Car },
        ].map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            type="button"
            role="radio"
            aria-checked={vehicle === id}
            onClick={() => setVehicle(id)}
            className={cn(
              'flex items-center gap-2 rounded-xl border-2 border-white/15 bg-secondary p-3 text-sm font-bold',
              vehicle === id && 'border-primary bg-primary/15 text-primary',
            )}
          >
            <Icon className="size-5" aria-hidden />
            {label}
            {id === 'cab' && isNight ? <Moon className="ml-auto size-4" aria-label={L('இரவு', 'Night')} /> : null}
          </button>
        ))}
      </div>
      <button type="button" onClick={simulate} className="btn-thick mt-3 w-full rounded-xl bg-secondary py-3 text-sm font-bold">
        {L('வாகனப் பயணத்தை உருவ���ப்படுத்து', 'Simulate vehicle movement')}
      </button>
      {last ? <blockquote className="mt-3 rounded-xl border-2 border-primary/50 bg-secondary p-3 text-sm leading-relaxed">{last}</blockquote> : null}
    </Panel>
  )
}

export function SensorWatcher() {
  const { sensors, emergency, triggerDetection } = useApp()
  const cooldown = useRef(0)

  useEffect(() => {
    if (!sensors.accelerometer || typeof window === 'undefined' || !('DeviceMotionEvent' in window)) return
    const onMotion = (e: DeviceMotionEvent) => {
      const a = e.accelerationIncludingGravity
      if (!a || a.x == null || a.y == null || a.z == null) return
      const g = Math.sqrt(a.x ** 2 + a.y ** 2 + a.z ** 2)
      if (g > 38 && emergency.stage === 'idle' && Date.now() > cooldown.current) {
        cooldown.current = Date.now() + 30000
        triggerDetection('Crash')
      }
    }
    window.addEventListener('devicemotion', onMotion)
    return () => window.removeEventListener('devicemotion', onMotion)
  }, [sensors.accelerometer, emergency.stage, triggerDetection])

  return null
}
