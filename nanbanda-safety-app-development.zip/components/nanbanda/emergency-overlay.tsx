'use client'

import { useEffect, useRef, useState } from 'react'
import { Camera, Check, Loader2, Lock, MapPin, Mic, Phone, Power, RotateCcw, ShieldOff, Users, Volume2, VolumeX } from 'lucide-react'
import { beep, startSiren } from '@/lib/audio'
import { SOURCE_LABEL, useApp, vibrate, type TriggerSource } from '@/lib/store'
import { cn } from '@/lib/utils'

const COUNTDOWN = 15
const RECORD_SECONDS = 30

export function EmergencyOverlay() {
  const { emergency } = useApp()
  if (emergency.stage === 'countdown') return <Countdown source={emergency.source} />
  if (emergency.stage === 'active') return <ActiveSOS source={emergency.source} />
  return null
}

function Countdown({ source }: { source: TriggerSource }) {
  const { L, cancelEmergency, activateSOS, contacts } = useApp()
  const [left, setLeft] = useState(COUNTDOWN)

  useEffect(() => {
    vibrate([800, 200])
    beep(1250)
    const id = setInterval(() => {
      setLeft((l) => {
        if (l <= 1) {
          clearInterval(id)
          return 0
        }
        vibrate([800, 200])
        beep(l % 2 ? 1250 : 880)
        return l - 1
      })
    }, 1000)
    return () => {
      clearInterval(id)
      vibrate(0)
    }
  }, [])

  useEffect(() => {
    if (left === 0) activateSOS(source)
  }, [left, source, activateSOS])

  const pct = ((COUNTDOWN - left) / COUNTDOWN) * 100
  const named = contacts.map((c) => c.name).filter(Boolean)
  const C = 2 * Math.PI * 45

  return (
    <div
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="cd-title"
      className="absolute inset-0 z-50 flex flex-col items-center justify-between overflow-y-auto bg-[#2a0606]/97 px-5 py-8 backdrop-blur animate-in fade-in"
    >
      <div className="text-center">
        <p className="inline-flex rounded-full border-2 border-gold/60 bg-gold/15 px-3 py-1 text-xs font-bold text-gold">
          {L('குடும்ப முன்னுரிமை அலாரத் தடுப்பு', 'Family-First Anti-False Alarm')}
        </p>
        <h2 id="cd-title" className="mt-3 text-2xl font-black text-balance">
          {L(SOURCE_LABEL[source][0], SOURCE_LABEL[source][1])} {L('கண்டறியப்பட்டது!', 'detected!')}
        </h2>
        <p className="mt-2 text-lg font-bold text-gold text-balance" aria-live="assertive">
          {L(`தவறான அலாரமா? நிறுத்த ${left} வினாடிகள் உள்ளன`, `False alarm? ${left} seconds left to stop`)}
        </p>
      </div>

      <div className="relative my-4 flex size-56 shrink-0 items-center justify-center">
        <div className="sos-glow absolute inset-6 rounded-full" aria-hidden />
        <svg viewBox="0 0 100 100" className="absolute inset-0 -rotate-90" aria-hidden>
          <circle cx="50" cy="50" r="45" fill="none" stroke="rgb(255 255 255 / 0.12)" strokeWidth="8" />
          <circle
            cx="50"
            cy="50"
            r="45"
            fill="none"
            stroke="var(--sos)"
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={C}
            strokeDashoffset={(C * (100 - pct)) / 100}
            className="transition-[stroke-dashoffset] duration-1000 ease-linear"
          />
        </svg>
        <div className="text-center">
          <span className="block text-8xl font-black tabular-nums">{left}</span>
          <span className="text-sm font-bold text-foreground/80">{L('வினாடிகள்', 'seconds')}</span>
        </div>
      </div>

      <div className="w-full space-y-3">
        <p className="rounded-xl border-2 border-white/15 bg-black/30 p-3 text-center text-xs leading-relaxed text-foreground/90 text-pretty">
          {L('ரத்து செய்யாவிட்டால், அரசு அதிகாரிகளுக்குப் பதிலாக முதலில் இவர்களுக்கு அனுப்பப்படும்: ', 'If not cancelled, this goes first to: ')}
          <strong className="text-gold">{named.join(', ') || L('உங்கள் 3 அவசரத் தொடர்புகள்', 'your 3 emergency contacts')}</strong>
        </p>
        <button
          type="button"
          onClick={cancelEmergency}
          autoFocus
          className="btn-thick w-full rounded-2xl border-2 border-white bg-white py-5 text-xl font-black text-[#0F172A]"
        >
          {L('அலாரத்தை ரத்துசெய் (Cancel)', 'Cancel Alarm')}
        </button>
        <button
          type="button"
          onClick={() => activateSOS(source)}
          className="w-full rounded-2xl border-2 border-sos py-3 text-sm font-bold text-red-300"
        >
          {L('இப்போதே எச்சரிக்கை அனுப்பு', 'Send alert now')}
        </button>
      </div>
    </div>
  )
}

function ActiveSOS({ source }: { source: TriggerSource }) {
  const { L, cancelEmergency, contacts, cloudRecording, gpsLog, logLocation } = useApp()
  const [recorded, setRecorded] = useState(0)
  const [sentCount, setSentCount] = useState(0)
  const [selfie, setSelfie] = useState<'pending' | 'captured'>('pending')
  const [shutdown, setShutdown] = useState(false)
  const [sirenOn, setSirenOn] = useState(true)

  useEffect(() => {
    if (!sirenOn || shutdown) return
    return startSiren()
  }, [sirenOn, shutdown])

  useEffect(() => {
    const rec = setInterval(() => setRecorded((r) => Math.min(RECORD_SECONDS, r + 1)), 1000)
    const send = setInterval(() => setSentCount((c) => (c >= 3 ? c : c + 1)), 700)
    const track = setInterval(() => void logLocation('Background tracking'), 10000)
    const snap = setTimeout(() => setSelfie('captured'), 2500)
    return () => {
      clearInterval(rec)
      clearInterval(send)
      clearInterval(track)
      clearTimeout(snap)
    }
  }, [logLocation])

  const last = gpsLog[0]
  const automatic = source !== 'Manual SOS'

  return (
    <div className="absolute inset-0 z-50 flex flex-col overflow-y-auto bg-background animate-in fade-in" role="dialog" aria-modal="true" aria-labelledby="sos-title">
      <div className="bg-sos px-5 pb-5 pt-7 text-white">
        <div className="flex items-center justify-between gap-2">
          <p className="inline-flex items-center gap-1.5 rounded-full bg-black/25 px-2.5 py-1 text-xs font-bold">
            <Lock className="size-3.5" aria-hidden /> SOS · {L(SOURCE_LABEL[source][0], SOURCE_LABEL[source][1])}
          </p>
          <button
            type="button"
            onClick={() => setSirenOn((s) => !s)}
            className="inline-flex items-center gap-1.5 rounded-full border-2 border-white/40 px-3 py-1 text-xs font-bold"
          >
            {sirenOn ? <VolumeX className="size-4" aria-hidden /> : <Volume2 className="size-4" aria-hidden />}
            {sirenOn ? L('சைரன் நிறுத்து', 'Mute siren') : L('சைரன் இயக்கு', 'Siren on')}
          </button>
        </div>
        <h2 id="sos-title" className="mt-3 text-2xl font-black leading-tight text-balance">
          {L('உங்கள் குடும்பத்தினருக்கு எச்சரிக்கை அனுப்பப்படுகிறது', 'Alerting your family')}
        </h2>
        <p className="mt-1 text-sm font-medium text-white/90">
          {L('அமைதியாக இருங்கள். முடிந்தால் பாதுகாப்பான பொது இடத்திற்குச் செல்லுங்கள்.', 'Stay calm. Move to a safe public place if you can.')}
        </p>
      </div>

      <div className="flex-1 space-y-3 p-4">
        {automatic ? (
          <div className="flex items-start gap-3 rounded-2xl border-2 border-gold/50 bg-gold/10 p-3.5">
            <ShieldOff className="mt-0.5 size-5 shrink-0 text-gold" aria-hidden />
            <p className="text-xs font-semibold leading-relaxed text-foreground/95">
              {L(
                'சிஸ்டம் லாக் செய்யப்பட்டது. தவறான அரசு அலாரத்தைத் தடுக்க, பொது அதிகாரிகள் தவிர்க்கப்பட்டு உங்கள் 3 அவசரத் தொடர்புகளுக்கு மட்டும் முதலில் அனுப்பப்படுகிறது.',
                'System locked. Public authorities are bypassed to prevent false alarms — routing to your 3 emergency contacts first.',
              )}
            </p>
          </div>
        ) : null}

        <StatusRow icon={<Users className="size-5" />} title={L('அவசரத் தொடர்புகள்', 'Emergency contacts')} done={sentCount >= 3}>
          {L(`${sentCount}/3 பேருக்கு அனுப்பப்பட்டது`, `${sentCount}/3 notified`)}
          {contacts.some((c) => c.phone) ? '' : L(' (தனியுரிமை தாவலில் எண்களைச் சேர்க்கவும்)', ' (add numbers in Privacy tab)')}
        </StatusRow>
        <StatusRow icon={<MapPin className="size-5" />} title={L('லைவ் ஜிபிஎஸ்', 'Live GPS')} done={!!last}>
          {last ? `${last.lat.toFixed(5)}, ${last.lng.toFixed(5)}` : L('இருப்பிடம் கண்டறியப்படுகிறது…', 'Locating…')}
        </StatusRow>
        <StatusRow icon={<Mic className="size-5" />} title={L('மைக்ரோஃபோன் குரல் பதிவு', 'Ambient voice recording')} done={recorded >= RECORD_SECONDS}>
          {cloudRecording ? L(`${recorded} / ${RECORD_SECONDS} வினாடி பாதுகாப்பாகப் பதிவு`, `${recorded}s / ${RECORD_SECONDS}s encrypted`) : L('முடக்கப்பட்டுள்ளது', 'Disabled')}
          {cloudRecording ? (
            <span className="mt-2 block h-2 overflow-hidden rounded-full bg-white/10">
              <span className="block h-full bg-primary transition-all" style={{ width: `${(recorded / RECORD_SECONDS) * 100}%` }} />
            </span>
          ) : null}
        </StatusRow>
        <StatusRow icon={<Camera className="size-5" />} title={L('முன்பக்க கேமரா புகைப்படம்', 'Front-camera intruder photo')} done={selfie === 'captured'}>
          {selfie === 'captured' ? L('ஊடுருவியவரின் படம் பாதுகாக்கப்பட்டது', 'Intruder photo secured') : L('ரகசியமாகப் படம் எடுக்கப்படுகிறது…', 'Capturing silently…')}
        </StatusRow>

        <a href="tel:112" className="btn-thick flex items-center justify-center gap-2 rounded-2xl border-2 border-white bg-white py-4 text-base font-black text-[#0F172A]">
          <Phone className="size-5" aria-hidden /> {L('காவல்துறைக்கு அழை · 112', 'Escalate to Police · 112')}
        </a>

        <div className="rounded-2xl border-2 border-dashed border-white/25 p-4">
          <p className="text-sm font-bold text-gold">{L('போலி சுவிட்ச்-ஆஃப் சோதனை', 'Stealth power-off demo')}</p>
          <p className="mt-1 text-xs leading-relaxed text-foreground/85">
            {L(
              'திருடன் பவர் பட்டனை அழுத்திப் பிடிப்பது போல் சோதிக்கவும். கருப்புத் திரையிலிருந்து வெளியேற இடது மேல் மூலையை 3 முறை தட்டவும்.',
              'Simulate a thief holding the power button. Triple-tap the top-left corner of the black screen to exit.',
            )}
          </p>
          <button
            type="button"
            onClick={() => setShutdown(true)}
            className="btn-thick mt-3 inline-flex items-center gap-2 rounded-xl border-2 border-white/20 bg-black px-4 py-2.5 text-sm font-bold text-white"
          >
            <Power className="size-4" aria-hidden /> {L('பவர் ஆஃப் முயற்சி', 'Try power off')}
          </button>
        </div>

        <button type="button" onClick={cancelEmergency} className="w-full rounded-2xl border-2 border-success/60 bg-success/10 py-4 text-base font-bold text-success">
          {L('நான் பாதுகாப்பாக இருக்கிறேன் — SOS முடி', "I'm safe — end SOS")}
        </button>
      </div>

      {shutdown ? <FakeShutdown onExit={() => setShutdown(false)} /> : null}
    </div>
  )
}

function StatusRow({ icon, title, done, children }: { icon: React.ReactNode; title: string; done: boolean; children: React.ReactNode }) {
  const { L } = useApp()
  return (
    <div className="flex items-start gap-3 rounded-2xl border-2 border-white/15 bg-card p-3.5">
      <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/15 text-primary">{icon}</span>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-bold">{title}</p>
        <div className="text-xs text-foreground/80">{children}</div>
      </div>
      {done ? (
        <Check className="size-6 text-success" aria-label={L('முடிந்தது', 'Done')} />
      ) : (
        <Loader2 className="size-6 animate-spin text-primary" aria-label={L('நடைபெறுகிறது', 'In progress')} />
      )}
    </div>
  )
}

function FakeShutdown({ onExit }: { onExit: () => void }) {
  const { L } = useApp()
  const [phase, setPhase] = useState<'menu' | 'shutting' | 'black'>('menu')
  const taps = useRef<number[]>([])

  useEffect(() => {
    if (phase !== 'shutting') return
    const id = setTimeout(() => setPhase('black'), 2600)
    return () => clearTimeout(id)
  }, [phase])

  const secretTap = () => {
    const now = Date.now()
    taps.current = [...taps.current.filter((t) => now - t < 800), now]
    if (taps.current.length >= 3) onExit()
  }

  return (
    <div className="absolute inset-0 z-[70] bg-black">
      <button type="button" aria-label={L('மறைவான வெளியேற்றம் — 3 முறை தட்டவும்', 'Hidden exit — triple tap')} onClick={secretTap} className="absolute left-0 top-0 z-10 size-16 opacity-0" />

      {phase === 'menu' ? (
        <div className="flex h-full flex-col items-center justify-center gap-8 bg-black/80 backdrop-blur-xl animate-in fade-in">
          <button type="button" onClick={() => setPhase('shutting')} className="flex flex-col items-center gap-2">
            <span className="flex size-16 items-center justify-center rounded-full bg-[#e53935] text-white">
              <Power className="size-7" aria-hidden />
            </span>
            <span className="text-sm text-white">Power off</span>
          </button>
          <button type="button" onClick={() => setPhase('shutting')} className="flex flex-col items-center gap-2">
            <span className="flex size-16 items-center justify-center rounded-full bg-white/15 text-white">
              <RotateCcw className="size-7" aria-hidden />
            </span>
            <span className="text-sm text-white">Restart</span>
          </button>
        </div>
      ) : null}

      {phase === 'shutting' ? (
        <div className="flex h-full flex-col items-center justify-center gap-4 animate-in fade-in">
          <Loader2 className="size-8 animate-spin text-white/70" aria-hidden />
          <p className="text-sm text-white/70">Shutting down…</p>
        </div>
      ) : null}

      <div className={cn('absolute inset-0 bg-black transition-opacity duration-700', phase === 'black' ? 'opacity-100' : 'pointer-events-none opacity-0')} />
    </div>
  )
}
