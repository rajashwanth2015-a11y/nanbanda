'use client'

import { useEffect, useRef, useState } from 'react'
import { CloudRain, Gamepad2, HeartHandshake, ImagePlus, Mic, Pause, Play, Sparkles, Square, Trash2, Trees, Waves, Wind } from 'lucide-react'
import { startAmbient, type AmbientKind } from '@/lib/audio'
import { useApp } from '@/lib/store'
import { cn } from '@/lib/utils'
import { Panel, SectionTitle } from './primitives'
import { ChellaKuralMode, MoodTracker } from './chella-kural-mode'
import { EntertainmentRoom } from './entertainment-room'

function resizeImage(file: File, max = 640): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onerror = reject
    reader.onload = () => {
      const img = new Image()
      img.crossOrigin = 'anonymous'
      img.onload = () => {
        const scale = Math.min(1, max / Math.max(img.width, img.height))
        const canvas = document.createElement('canvas')
        canvas.width = Math.round(img.width * scale)
        canvas.height = Math.round(img.height * scale)
        canvas.getContext('2d')?.drawImage(img, 0, 0, canvas.width, canvas.height)
        resolve(canvas.toDataURL('image/jpeg', 0.82))
      }
      img.onerror = reject
      img.src = reader.result as string
    }
    reader.readAsDataURL(file)
  })
}

const ROOMS = [
  { id: 'chella', icon: Mic, ta: 'செல்லக் குரல்', en: 'Pet Voice' },
  { id: 'calm', icon: Wind, ta: 'தியானம்', en: 'Meditation' },
  { id: 'fun', icon: Gamepad2, ta: 'பொழுதுபோக்கு', en: 'Entertainment' },
] as const

export function WellnessTab() {
  const { L } = useApp()
  const [room, setRoom] = useState<(typeof ROOMS)[number]['id']>('chella')
  return (
    <div className="flex flex-col gap-4">
      <div role="tablist" aria-label={L('நலம் அறைகள்', 'Wellness rooms')} className="grid grid-cols-3 gap-1.5 rounded-2xl border-2 border-white/15 bg-card p-1.5">
        {ROOMS.map((r) => {
          const Icon = r.icon
          const active = room === r.id
          return (
            <button
              key={r.id}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => setRoom(r.id)}
              className={cn(
                'flex flex-col items-center gap-1 rounded-xl px-1 py-2.5 text-xs font-black leading-tight transition-colors',
                active ? 'bg-success text-background' : 'text-foreground/80 hover:bg-secondary',
              )}
            >
              <Icon className="size-5" aria-hidden />
              {L(r.ta, r.en)}
            </button>
          )
        })}
      </div>
      {room === 'chella' ? <ChellaKuralBlock /> : null}
      {room === 'calm' ? (
        <>
          <CalmIntro />
          <CalmingSounds />
          <BreathingGuide />
          <Panel>
            <SectionTitle>{L('மனநிலை பதிவு', 'Mood Tracker')}</SectionTitle>
            <MoodTracker />
          </Panel>
        </>
      ) : null}
      {room === 'fun' ? <EntertainmentRoom /> : null}
    </div>
  )
}

function CalmIntro() {
  const { L } = useApp()
  return (
    <>
      <section className="rounded-2xl border-2 border-success/50 bg-success/10 p-4">
        <h2 className="flex items-center gap-2 text-lg font-black text-success">
          <HeartHandshake className="size-6" aria-hidden />
          {L('மனநல மற்றும் பதற்ற நிவாரண மையம்', 'Mental Health & Tension Relief Centre')}
        </h2>
        <p className="mt-1.5 text-sm leading-relaxed text-foreground/90 text-pretty">
          {L(
            'கடும் பதற்றம், கோபம் அல்லது மன அழுத்தத்தில் இருக்கிறீர்களா? கீழே உள்ள கருவிகள் உங்களை உடனே அமைதிப்படுத்தும்.',
            'Feeling extreme anxiety, anger or stress? The tools below will calm you right away.',
          )}
        </p>
      </section>
    </>
  )
}

function ChellaKuralBlock() {
  const { chellaPhoto, chellaAudio, update, showToast, L } = useApp()
  const [open, setOpen] = useState(false)
  const [recording, setRecording] = useState(false)
  const recorder = useRef<MediaRecorder | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  const onPhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    try {
      update({ chellaPhoto: await resizeImage(file) })
      showToast(L('புகைப்படம் உங்கள் போனில் சேமிக்கப்பட்டது', 'Photo saved on your phone'))
    } catch {
      showToast(L('இந்தப் படத்தைப் படிக்க முடியவில்லை', 'Could not read that image'))
    }
  }

  const toggleRecord = async () => {
    if (recording) {
      recorder.current?.stop()
      return
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const rec = new MediaRecorder(stream)
      const chunks: Blob[] = []
      rec.ondataavailable = (ev) => chunks.push(ev.data)
      rec.onstop = () => {
        stream.getTracks().forEach((t) => t.stop())
        setRecording(false)
        const reader = new FileReader()
        reader.onload = () => {
          update({ chellaAudio: reader.result as string })
          showToast(L('குரல் பதிவு சேமிக்கப்பட்டது', 'Voice note saved'))
        }
        reader.readAsDataURL(new Blob(chunks, { type: rec.mimeType }))
      }
      rec.start()
      recorder.current = rec
      setRecording(true)
      setTimeout(() => rec.state === 'recording' && rec.stop(), 15000)
    } catch {
      showToast(L('பதிவு செய்ய மைக்ரோஃபோன் அனுமதி தேவை', 'Microphone permission is needed'))
    }
  }

  return (
    <section className="rounded-2xl border-2 border-pink/60 bg-pink/10 p-4" aria-labelledby="chella-title">
      <h2 id="chella-title" className="text-xl font-black text-pink">
        {L('செல்லக் குரல்', 'Chella Kural')} <span className="text-sm font-bold text-foreground/80">(AI Emotional Reset Shield)</span>
      </h2>
      <p className="mt-1 text-sm leading-relaxed text-foreground/90 text-pretty">
        {L(
          'உங்கள் மகள் / மகன் / அன்புக்குரியவரின் குழந்தைப் பருவப் புகைப்படத்தையும் குரலையும் சேமியுங்கள்.',
          'Save a childhood photo and voice of your daughter / son / loved one.',
        )}
      </p>

      <div className="mt-4 grid grid-cols-[104px_1fr] gap-3">
        <button
          type="button"
          onClick={() => fileRef.current?.click()}
          className="relative flex aspect-square items-center justify-center overflow-hidden rounded-2xl border-2 border-dashed border-pink/70 bg-secondary"
          aria-label={chellaPhoto ? L('புகைப்படத்தை மாற்று', 'Change photo') : L('புகைப்படம் பதிவேற்று', 'Upload photo')}
        >
          {chellaPhoto ? (
            <img src={chellaPhoto || '/placeholder.svg'} alt={L('உங்கள் அன்புக்குரியவர்', 'Your loved one')} className="size-full object-cover" />
          ) : (
            <span className="flex flex-col items-center gap-1 text-center text-xs font-bold text-pink">
              <ImagePlus className="size-7" aria-hidden />
              {L('புகைப்படம்', 'Photo')}
            </span>
          )}
        </button>
        <input ref={fileRef} type="file" accept="image/*" className="sr-only" onChange={onPhoto} tabIndex={-1} />

        <div className="flex flex-col justify-between gap-2">
          <div className="flex gap-2">
            <button
              type="button"
              onClick={toggleRecord}
              className={cn(
                'btn-thick flex flex-1 items-center justify-center gap-2 rounded-xl py-3 text-sm font-bold',
                recording ? 'bg-sos text-foreground' : 'bg-secondary',
              )}
            >
              {recording ? <Square className="size-4" aria-hidden /> : <Mic className="size-4" aria-hidden />}
              {recording ? L('நிறுத்து', 'Stop') : chellaAudio ? L('மீண்டும் பதிவு', 'Re-record') : L('குரல் பதிவு', 'Record voice')}
            </button>
            {chellaAudio ? (
              <>
                <button type="button" aria-label={L('சேமித்த குரலை இயக்கு', 'Play saved voice')} onClick={() => new Audio(chellaAudio).play()} className="rounded-xl border-2 border-white/15 bg-secondary px-3">
                  <Play className="size-4" aria-hidden />
                </button>
                <button type="button" aria-label={L('குரலை நீக்கு', 'Delete voice')} onClick={() => update({ chellaAudio: null })} className="rounded-xl border-2 border-white/15 bg-secondary px-3">
                  <Trash2 className="size-4" aria-hidden />
                </button>
              </>
            ) : null}
          </div>
          <p className="text-xs leading-relaxed text-foreground/80">
            {chellaAudio
              ? L('குரல் பதிவு சேமிக்கப்பட்டது.', 'Voice note saved.')
              : L('பதிவு இல்லை — இனிய தமிழ்க் குரல் பயன்படுத்தப்படும்.', 'No recording — a gentle Tamil voice will be used.')}
          </p>
        </div>
      </div>

      <button
        type="button"
        onClick={() => setOpen(true)}
        className="pink-glow mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-pink py-4 text-base font-black text-background"
      >
        <Sparkles className="size-5" aria-hidden />
        {L('செல்லக் குரல் (Chella Kural) இயக்கவும்', 'Launch Chella Kural')}
      </button>
      {open ? <ChellaKuralMode onClose={() => setOpen(false)} /> : null}
    </section>
  )
}

const SOUNDS: { id: AmbientKind; ta: string; en: string; icon: typeof CloudRain }[] = [
  { id: 'rain', ta: 'மழையின் ஓசை', en: 'Rain Sound Loop', icon: CloudRain },
  { id: 'forest', ta: 'காட்டின் அமைதி', en: 'Forest Meditation', icon: Trees },
  { id: 'ocean', ta: 'கடல் அலைகள்', en: 'Ocean Waves', icon: Waves },
]

function CalmingSounds() {
  const { L } = useApp()
  const [playing, setPlaying] = useState<AmbientKind | null>(null)
  const stopRef = useRef<(() => void) | null>(null)

  useEffect(() => () => stopRef.current?.(), [])

  const toggle = (id: AmbientKind) => {
    stopRef.current?.()
    stopRef.current = null
    if (playing === id) return setPlaying(null)
    stopRef.current = startAmbient(id)
    setPlaying(id)
  }

  return (
    <Panel>
      <SectionTitle>{L('மன அமைதி தரும் தியான ஒலிகள்', 'Mind Calming Sounds')}</SectionTitle>
      <ul className="flex flex-col gap-2">
        {SOUNDS.map((s, i) => {
          const Icon = s.icon
          const on = playing === s.id
          return (
            <li key={s.id}>
              <button
                type="button"
                onClick={() => toggle(s.id)}
                aria-pressed={on}
                className={cn(
                  'flex w-full items-center gap-3 rounded-xl border-2 p-3 text-left transition-colors',
                  on ? 'border-success bg-success/15' : 'border-white/15 bg-secondary',
                )}
              >
                <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-background text-success">
                  <Icon className="size-5" aria-hidden />
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block font-bold">
                    {i + 1}. {L(s.ta, s.en)}
                  </span>
                  <span className="block text-xs text-foreground/75">
                    {on ? L('இயங்குகிறது…', 'Playing…') : s.en}
                  </span>
                </span>
                <span className={cn('flex size-11 items-center justify-center rounded-full', on ? 'bg-success text-background' : 'bg-primary text-primary-foreground')}>
                  {on ? <Pause className="size-5" aria-hidden /> : <Play className="size-5" aria-hidden />}
                  <span className="sr-only">{on ? L('நிறுத்து', 'Pause') : L('இயக்கு', 'Play')}</span>
                </span>
              </button>
            </li>
          )
        })}
      </ul>
    </Panel>
  )
}

function BreathingGuide() {
  const { L } = useApp()
  const [running, setRunning] = useState(false)
  const [inhale, setInhale] = useState(true)
  const [count, setCount] = useState(4)

  useEffect(() => {
    if (!running) return
    const id = setInterval(() => {
      setCount((c) => {
        if (c > 1) return c - 1
        setInhale((v) => !v)
        return 4
      })
    }, 1000)
    return () => clearInterval(id)
  }, [running])

  const expanded = running && inhale

  return (
    <Panel>
      <SectionTitle icon={<Wind className="size-5 text-success" aria-hidden />}>{L('மூச்சுப் பயிற்சி வழிகாட்டி', 'Breathing Guide')}</SectionTitle>
      <div className="flex h-60 items-center justify-center">
        <div
          className="flex items-center justify-center rounded-full border-[6px] border-success bg-success/15 transition-all ease-in-out"
          style={{ width: expanded ? 220 : 120, height: expanded ? 220 : 120, transitionDuration: running ? '4s' : '0.4s' }}
          aria-live="polite"
        >
          <div className="text-center">
            <p className="text-3xl font-black tabular-nums text-success">{running ? count : '4'}</p>
          </div>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2 text-center text-sm font-bold">
        <p className={cn('rounded-xl border-2 p-2', running && inhale ? 'border-success bg-success/15 text-success' : 'border-white/15 text-foreground/70')}>
          {L('மூச்சை உள்ளே இழுக்கவும்', 'Inhale')} (4s)
        </p>
        <p className={cn('rounded-xl border-2 p-2', running && !inhale ? 'border-success bg-success/15 text-success' : 'border-white/15 text-foreground/70')}>
          {L('மூச்சை வெளியே விடவும்', 'Exhale')} (4s)
        </p>
      </div>
      <button
        type="button"
        onClick={() => {
          setRunning((r) => !r)
          setInhale(true)
          setCount(4)
        }}
        className="btn-thick mt-3 w-full rounded-xl bg-success py-3.5 font-black text-background"
      >
        {running ? L('பயிற்சியை நிறுத்து', 'Stop exercise') : L('பயிற்சியைத் தொடங்கு', 'Start exercise')}
      </button>
    </Panel>
  )
}
