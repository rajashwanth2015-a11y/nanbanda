'use client'

import { useEffect, useState } from 'react'
import { CreditCard, Loader2, PartyPopper, ShieldCheck, Smartphone } from 'lucide-react'
import { useApp } from '@/lib/store'
import { cn } from '@/lib/utils'
import { Sheet } from './primitives'

const METHODS = [
  { id: 'gpay', label: 'Google Pay', color: 'bg-[#1a73e8]' },
  { id: 'phonepe', label: 'PhonePe', color: 'bg-[#5f259f]' },
  { id: 'paytm', label: 'Paytm', color: 'bg-[#00baf2]' },
  { id: 'card', label: 'Debit / Credit Card', color: 'bg-background' },
] as const

export function CheckoutSheet({ mode, onClose }: { mode: 'pay' | 'waiver'; onClose: () => void }) {
  const { update, L } = useApp()
  const [method, setMethod] = useState<(typeof METHODS)[number]['id']>('gpay')
  const [phase, setPhase] = useState<'select' | 'processing' | 'done'>('select')
  const [card, setCard] = useState({ number: '', exp: '', cvv: '' })
  const [policyNo, setPolicyNo] = useState('')
  const amount = mode === 'waiver' ? 0 : 49

  useEffect(() => {
    if (phase !== 'processing') return
    const id = setTimeout(() => {
      setPhase('done')
      update({ premium: true })
    }, 2400)
    return () => clearTimeout(id)
  }, [phase, update])

  const cardValid = card.number.replace(/\s/g, '').length >= 15 && /^\d{2}\/\d{2}$/.test(card.exp) && card.cvv.length >= 3
  const canPay = mode === 'waiver' ? policyNo.trim().length >= 6 : method !== 'card' || cardValid

  if (phase === 'processing') {
    return (
      <Sheet title={L('பணம் செலுத்துதல்', 'Checkout')} onClose={() => {}}>
        <div className="flex flex-col items-center py-10" role="status">
          <Loader2 className="size-14 animate-spin text-primary" aria-hidden />
          <p className="mt-4 text-lg font-black">{L('பணம் செலுத்தப்படுகிறது...', 'Processing payment...')}</p>
          <p className="mt-1 text-sm text-foreground/75">{L('ஆப்பை மூட வேண்டாம்', 'Do not close the app')}</p>
        </div>
      </Sheet>
    )
  }

  if (phase === 'done') {
    return (
      <Sheet title={L('வெற்றி!', 'Success!')} onClose={onClose}>
        <div className="flex flex-col items-center rounded-2xl border-2 border-success bg-success/15 px-4 py-8 text-center animate-in zoom-in-95">
          <span className="flex size-20 items-center justify-center rounded-full bg-success">
            <PartyPopper className="size-10 text-background" aria-hidden />
          </span>
          <p className="mt-4 text-xl font-black leading-snug text-success text-balance">
            {L('பிரீமியம் பிளான் ஆக்டிவேட் செய்யப்பட்டது! 🎉', 'Premium plan activated! 🎉')}
          </p>
          <p className="mt-2 text-sm font-medium">
            {mode === 'waiver'
              ? L('100% கட்டண விலக்கு — ₹0 வசூலிக்கப்பட்டது.', '100% waiver applied — ₹0 charged.')
              : L(`₹${amount} ${METHODS.find((m) => m.id === method)?.label} மூலம் செலுத்தப்பட்டது.`, `₹${amount} paid via ${METHODS.find((m) => m.id === method)?.label}.`)}
          </p>
          <button type="button" onClick={onClose} className="btn-thick mt-6 w-full rounded-xl bg-success py-3.5 font-black text-background">
            {L('தொடரவும்', 'Continue')}
          </button>
        </div>
      </Sheet>
    )
  }

  return (
    <Sheet title={mode === 'waiver' ? L('பாலிசி இணைத்து கட்டண விலக்கு', 'Link Policy & Waiver') : L('நண்பேன்டா பிரீமியம்', 'Nanbanda Premium')} onClose={onClose}>
      <div className="flex items-center justify-between rounded-xl border-2 border-gold/60 bg-secondary p-3">
        <span className="text-sm font-bold">{L('பிரீமியம் · மாதாந்திரம்', 'Premium · Monthly')}</span>
        <span className="text-right">
          {mode === 'waiver' ? <span className="mr-2 text-sm text-muted-foreground line-through">₹49</span> : null}
          <span className="text-lg font-bold">₹{amount}</span>
        </span>
      </div>

      {mode === 'waiver' ? (
        <div className="mt-4">
          <label htmlFor="pol" className="text-xs font-medium text-muted-foreground">
            {L('பாலிசி / புதுப்பித்தல் எண்', 'Policy / renewal number')}
          </label>
          <input
            id="pol"
            value={policyNo}
            onChange={(e) => setPolicyNo(e.target.value)}
            placeholder="e.g. ICL/MTR/26/88120"
            className="mt-1.5 w-full rounded-xl border bg-secondary px-3 py-2.5 text-sm outline-none focus:border-primary"
          />
        </div>
      ) : (
        <>
          <p className="mt-4 text-sm font-bold">{L('UPI அல்லது கார்டு மூலம் செலுத்தவும்', 'Pay with UPI or card')}</p>
          <div className="mt-2 flex flex-col gap-2" role="radiogroup" aria-label={L('பணம் செலுத்தும் முறை', 'Payment method')}>
            {METHODS.map((m) => (
              <button
                key={m.id}
                type="button"
                role="radio"
                aria-checked={method === m.id}
                onClick={() => setMethod(m.id)}
                className={cn('flex w-full items-center gap-3 rounded-xl border p-3 text-left text-sm font-medium', method === m.id && 'border-primary bg-primary/10')}
              >
                <span className={cn('flex size-8 items-center justify-center rounded-lg text-white', m.color)}>
                  {m.id === 'card' ? <CreditCard className="size-4" aria-hidden /> : <Smartphone className="size-4" aria-hidden />}
                </span>
                {m.label}
                <span className={cn('ml-auto size-4 rounded-full border-2', method === m.id ? 'border-primary bg-primary' : 'border-white/30')} aria-hidden />
              </button>
            ))}
          </div>
          {method === 'card' ? (
            <div className="mt-3 grid grid-cols-2 gap-2">
              <input
                aria-label="Card number"
                inputMode="numeric"
                placeholder="Card number"
                value={card.number}
                onChange={(e) => setCard({ ...card, number: e.target.value.replace(/[^\d ]/g, '').slice(0, 19) })}
                className="col-span-2 rounded-xl border bg-secondary px-3 py-2.5 text-sm outline-none focus:border-primary"
              />
              <input
                aria-label="Expiry MM/YY"
                placeholder="MM/YY"
                value={card.exp}
                onChange={(e) => setCard({ ...card, exp: e.target.value.slice(0, 5) })}
                className="rounded-xl border bg-secondary px-3 py-2.5 text-sm outline-none focus:border-primary"
              />
              <input
                aria-label="CVV"
                inputMode="numeric"
                type="password"
                placeholder="CVV"
                value={card.cvv}
                onChange={(e) => setCard({ ...card, cvv: e.target.value.replace(/\D/g, '').slice(0, 4) })}
                className="rounded-xl border bg-secondary px-3 py-2.5 text-sm outline-none focus:border-primary"
              />
            </div>
          ) : null}
        </>
      )}

      <button
        type="button"
        disabled={!canPay}
        onClick={() => setPhase('processing')}
        className="btn-thick mt-5 w-full rounded-xl bg-primary py-4 font-black text-primary-foreground disabled:opacity-50"
      >
        {mode === 'waiver' ? L('சரிபார்த்து இலவசமாக ஆக்டிவேட் செய்', 'Verify & activate free') : L(`₹${amount} செலுத்து`, `Pay ₹${amount}`)}
      </button>
      <p className="mt-3 flex items-center justify-center gap-1.5 text-xs text-foreground/70">
        <ShieldCheck className="size-3.5" aria-hidden /> {L('டெமோ செக்அவுட் · உண்மையான பணம் வசூலிக்கப்படாது', 'Demo checkout · no real money charged')}
      </p>
    </Sheet>
  )
}
