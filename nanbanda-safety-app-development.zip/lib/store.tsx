'use client'

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import { pick, type Lang } from './i18n'

export type Contact = { name: string; phone: string }
export type GpsPoint = { lat: number; lng: number; at: string; event: string }
export type Mood = { mood: string; at: string }
export type TriggerSource = 'Shake' | 'Fall' | 'Voice' | 'Crash' | 'Manual SOS' | 'Smartwatch'

export type CareSettings = {
  enabled: boolean | null
  health: { on: boolean; condition: 'bp' | 'sugar' | 'custom'; custom: string; times: string[] }
  work: { on: boolean; tasks: { title: string; time: string }[] }
  child: { on: boolean; name: string; arrival: string; arrivedOn: string | null }
  morning: { on: boolean; time: string }
  checkins: { date: string; took: boolean }[]
}

export const CARE_DEFAULTS: CareSettings = {
  enabled: null,
  health: { on: false, condition: 'bp', custom: '', times: ['09:00', '21:00'] },
  work: { on: false, tasks: [] },
  child: { on: false, name: 'மகள்', arrival: '17:00', arrivedOn: null },
  morning: { on: true, time: '08:00' },
  checkins: [],
}

type Persisted = {
  userName: string
  language: Lang
  contacts: Contact[]
  premium: boolean
  cloudRecording: boolean
  sensors: { accelerometer: boolean; gyroscope: boolean; acoustic: boolean; voicePrompts: boolean }
  imei: string
  chellaPhoto: string | null
  chellaAudio: string | null
  moods: Mood[]
  gpsLog: GpsPoint[]
  watchPaired: string | null
  trackingPin: string | null
  voiceSos: boolean
  care: CareSettings
}

export const SOURCE_LABEL: Record<TriggerSource, [ta: string, en: string]> = {
  Shake: ['ஃபோன் குலுக்கல்', 'Phone shake'],
  Fall: ['தடுமாறி விழுதல்', 'Fall detected'],
  Voice: ['குரல் அலறல்', 'Scream detected'],
  Crash: ['விபத்து மோதல்', 'Crash impact'],
  'Manual SOS': ['SOS பொத்தான்', 'SOS button'],
  Smartwatch: ['ஸ்மார்ட்வாட்ச்', 'Smartwatch'],
}

const DEFAULTS: Persisted = {
  userName: 'கார்த்திக்',
  language: 'ta',
  contacts: [
    { name: 'அம்மா', phone: '' },
    { name: 'அப்பா', phone: '' },
    { name: 'அண்ணன்', phone: '' },
  ],
  premium: false,
  cloudRecording: true,
  sensors: { accelerometer: true, gyroscope: true, acoustic: false, voicePrompts: true },
  imei: '35-209900-176148-1',
  chellaPhoto: null,
  chellaAudio: null,
  moods: [],
  gpsLog: [],
  watchPaired: null,
  trackingPin: null,
  voiceSos: false,
  care: CARE_DEFAULTS,
}

const STORAGE_KEY = 'nanbanda.secure.v2'
const FALLBACK = { lat: 13.0827, lng: 80.2707 }

type Emergency =
  | { stage: 'idle' }
  | { stage: 'countdown'; source: TriggerSource }
  | { stage: 'active'; source: TriggerSource; startedAt: string }

type Ctx = Persisted & {
  hydrated: boolean
  update: (patch: Partial<Persisted>) => void
  L: (ta: string, en: string) => string
  emergency: Emergency
  triggerDetection: (source: TriggerSource) => void
  activateSOS: (source: TriggerSource) => void
  cancelEmergency: () => void
  logLocation: (event: string) => Promise<GpsPoint>
  toast: string | null
  showToast: (msg: string) => void
}

const AppContext = createContext<Ctx | null>(null)

export function getPosition(): Promise<{ lat: number; lng: number }> {
  return new Promise((resolve) => {
    if (typeof navigator === 'undefined' || !navigator.geolocation) return resolve(FALLBACK)
    navigator.geolocation.getCurrentPosition(
      (p) => resolve({ lat: p.coords.latitude, lng: p.coords.longitude }),
      () => resolve(FALLBACK),
      { enableHighAccuracy: true, timeout: 4000 },
    )
  })
}

export function vibrate(pattern: number | number[]) {
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) navigator.vibrate(pattern)
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<Persisted>(DEFAULTS)
  const [hydrated, setHydrated] = useState(false)
  const [emergency, setEmergency] = useState<Emergency>({ stage: 'idle' })
  const [toast, setToast] = useState<string | null>(null)
  const toastTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY)
      if (raw) {
        const saved = JSON.parse(raw) as Partial<Persisted>
        setState({ ...DEFAULTS, ...saved, care: { ...CARE_DEFAULTS, ...saved.care } })
      }
    } catch {}
    setHydrated(true)
  }, [])

  useEffect(() => {
    if (!hydrated) return
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state))
    } catch {
      // Large media may exceed quota; keep the rest of the state in memory.
    }
  }, [state, hydrated])

  useEffect(() => {
    document.documentElement.lang = state.language === 'en' ? 'en' : 'ta'
  }, [state.language])

  const update = useCallback((patch: Partial<Persisted>) => setState((s) => ({ ...s, ...patch })), [])

  const showToast = useCallback((msg: string) => {
    setToast(msg)
    if (toastTimer.current) clearTimeout(toastTimer.current)
    toastTimer.current = setTimeout(() => setToast(null), 2800)
  }, [])

  const logLocation = useCallback(async (event: string) => {
    const pos = await getPosition()
    const point: GpsPoint = { ...pos, at: new Date().toISOString(), event }
    setState((s) => ({ ...s, gpsLog: [point, ...s.gpsLog].slice(0, 60) }))
    return point
  }, [])

  const triggerDetection = useCallback((source: TriggerSource) => {
    setEmergency({ stage: 'countdown', source })
  }, [])

  const activateSOS = useCallback(
    (source: TriggerSource) => {
      setEmergency({ stage: 'active', source, startedAt: new Date().toISOString() })
      vibrate([400, 100, 400])
      void logLocation(`SOS: ${source}`)
    },
    [logLocation],
  )

  const cancelEmergency = useCallback(() => {
    setEmergency({ stage: 'idle' })
    vibrate(0)
  }, [])

  const L = useCallback((ta: string, en: string) => pick(state.language, ta, en), [state.language])

  const value = useMemo<Ctx>(
    () => ({
      ...state,
      hydrated,
      update,
      L,
      emergency,
      triggerDetection,
      activateSOS,
      cancelEmergency,
      logLocation,
      toast,
      showToast,
    }),
    [state, hydrated, update, L, emergency, triggerDetection, activateSOS, cancelEmergency, logLocation, toast, showToast],
  )

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used inside AppProvider')
  return ctx
}

export function speak(text: string, lang = 'ta-IN') {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return false
  window.speechSynthesis.cancel()
  const u = new SpeechSynthesisUtterance(text)
  u.lang = lang
  u.rate = 0.92
  const voice = window.speechSynthesis.getVoices().find((v) => v.lang.startsWith(lang.slice(0, 2)))
  if (voice) u.voice = voice
  window.speechSynthesis.speak(u)
  return true
}
