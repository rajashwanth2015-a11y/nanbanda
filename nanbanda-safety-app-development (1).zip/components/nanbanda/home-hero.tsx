'use client'

import { useState } from 'react'
import Image from 'next/image'
import { Ambulance, HeartPulse, Lock, Phone, ShieldAlert, Siren, Timer, X } from 'lucide-react'
import { useApp } from '@/lib/store'
import { cn } from '@/lib/utils'
import { Panel, SectionTitle } from './primitives'

const BADGES = [
  { label: 'Crash Detection 🏍️', className: 'left-2 top-3' },
  { label: 'Anti-Theft 📴', className: 'right-2 top-3' },
  { label: 'Parents Care 👵', className: 'bottom-3 left-1/2 -translate-x-1/2' },
]

export function FamilyHero() {
  const { L } = useApp()
  return (
    <section aria-labelledby="hero-title" className="relative overflow-hidden rounded-3xl border-2 border-white/15 bg-[#0b1426] px-3 pb-12 pt-12">
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center" aria-hidden>
        {[0, 1.2, 2.4].map((d) => (
          <span key={d} className="radar-ring absolute size-72 rounded-full border-2 border-neon/25" style={{ animationDelay: `${d}s` }} />
        ))}
      </div>

      {BADGES.map((b) => (
        <span
          key={b.label}
          className={cn('absolute z-10 rounded-full border border-white/20 bg-background/85 px-2.5 py-1 text-[11px] font-black backdrop-blur', b.className)}
        >
          {b.label}
        </span>
      ))}

      <h2 id="hero-title" className="sr-only">
        {L('நண்பேன்டா — குடும்பப் பாதுகாப்பு அமைப்பு', 'Nanbanda — family safety ecosystem')}
      </h2>

      <div className="relative flex items-center gap-3">
        <div className="relative aspect-square flex-1 overflow-hidden rounded-2xl border-2 border-white/20">
          <Image
            src="/images/family-hero.png"
            alt={L('மகிழ்ச்சியாகச் சிரிக்கும் தமிழ் குடும்பம் — அப்பா, அம்மா, மகள்', 'A happy smiling Tamil family — father, mother and daughter')}
            fill
            sizes="(max-width: 448px) 45vw, 200px"
            className="object-cover"
            priority
          />
        </div>

        <div aria-hidden className="w-[42%] shrink-0 rounded-[1.6rem] border-4 border-white/25 bg-background p-2 shadow-2xl">
          <div className="mx-auto mb-2 h-1.5 w-10 rounded-full bg-white/25" />
          <div className="flex flex-col items-center gap-2 rounded-2xl bg-card px-1.5 py-3">
            <span className="sos-glow flex size-20 flex-col items-center justify-center rounded-full bg-[radial-gradient(circle_at_35%_30%,#f87171,#dc2626_55%,#991b1b)] text-white">
              <span className="text-xl font-black leading-none">SOS</span>
              <span className="mt-0.5 text-[9px] font-bold">அழுத்தவும்</span>
            </span>
            <div className="grid w-full grid-cols-2 gap-1.5">
              <span className="flex items-center justify-center gap-1 rounded-lg bg-[#b91c1c] py-1.5 text-[11px] font-black text-white">
                <Siren className="size-3" /> 112
              </span>
              <span className="flex items-center justify-center gap-1 rounded-lg bg-primary py-1.5 text-[11px] font-black text-primary-foreground">
                <Ambulance className="size-3" /> 108
              </span>
            </div>
          </div>
        </div>
      </div>

      <p className="relative mt-3 text-center text-base font-black leading-snug text-balance">
        {L('உங்கள் குடும்பத்தின் நண்பன் — எப்போதும் அருகில்', "Your family's friend — always close by")}
      </p>
    </section>
  )
}

const PROTOCOLS = [
  'SOS அவசர எச்சரிக்கை',
  'விபத்து மோதல் கண்டறிதல்',
  'திருட்டுத் தடுப்பு',
  'குரல் SOS',
  'பெற்றோர் நல்வாழ்வு அரண்',
  '2 நிமிட பாதுகாப்பு அரண்',
]

export function ProtocolMarquee() {
  const { L } = useApp()
  const items = [...PROTOCOLS, ...PROTOCOLS]
  return (
    <div className="overflow-hidden rounded-2xl border-2 border-primary/50 bg-primary/10 py-2.5" role="region" aria-label={L('6 முக்கியப் பாதுகாப்பு நெறிமுறைகள்', '6 core safety protocols')}>
      <ul className="sr-only">
        {PROTOCOLS.map((p) => (
          <li key={p}>{p}</li>
        ))}
      </ul>
      <div className="marquee-track flex w-max gap-6" aria-hidden>
        {items.map((p, i) => (
          <span key={i} className="flex items-center gap-2 whitespace-nowrap text-sm font-black">
            <ShieldAlert className="size-4 text-primary" />
            {p}
          </span>
        ))}
      </div>
    </div>
  )
}

export function FailSafeInfo() {
  const { L } = useApp()
  return (
    <Panel className="border-sos/60 bg-sos/10">
      <SectionTitle icon={<Timer className="size-5 text-red-400" aria-hidden />} hint={L('2 நிமிடம்', '2 min')}>
        {L('2 நிமிட அவசரப் பாதுகாப்பு அரண்', '2-Minute Fail-Safe Backup')}
      </SectionTitle>
      <p className="text-sm leading-relaxed text-foreground/90 text-pretty">
        {L(
          'SOS தொடங்கியதும் 2 நிமிட டைமர் ஓடும். குடும்பத்தினர் யாரும் பதில் அளிக்காவிட்டால் (சைலண்ட் / ஸ்விட்ச்-ஆஃப் / தொலைவில்), 108 ஆம்புலன்ஸ் மற்றும் 112 காவல்துறைக்கு உங்கள் GPS இருப்பிடத்துடன் அழைப்பு / SMS திரை தானாகத் திறக்கும்.',
          'When SOS starts, a 2-minute timer runs. If no family member responds (silent / switched off / away), a call / SMS screen to 108 Ambulance and 112 Police opens automatically with your GPS location.',
        )}
      </p>
      <p className="mt-2 text-xs leading-relaxed text-foreground/70 text-pretty">
        {L(
          'குறிப்பு: குடும்பத்தினர் லிங்கைத் திறந்தார்களா என்பதை இந்த ஆப்பால் அறிய முடியாது. அவர்கள் பதில் அளித்தால் "குடும்பம் பதில் அளித்தது" பட்டனை அழுத்துங்கள். அழைப்பு மற்றும் SMS-ஐ நீங்களே அனுப்ப வேண்டும்.',
          'Note: the app cannot tell whether family opened the link. Tap "Family responded" when they reply. You still press Call / Send yourself.',
        )}
      </p>
    </Panel>
  )
}

const BYPASS = [
  { ta: 'அம்மா', en: 'Mother' },
  { ta: 'அப்பா', en: 'Father' },
  { ta: 'மனைவி/கணவன்', en: 'Spouse' },
]

export function LockScreenCardButton() {
  const { L } = useApp()
  const [open, setOpen] = useState(false)
  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="btn-thick flex w-full items-center gap-3 rounded-2xl border-2 border-white/20 bg-secondary p-4 text-left"
      >
        <span className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-sos text-white">
          <HeartPulse className="size-7" aria-hidden />
        </span>
        <span className="min-w-0 flex-1">
          <span className="block text-base font-black leading-snug">{L('லாக் ஸ்கிரீன் அவசர மருத்துவ அட்டை', 'Lock Screen Emergency ID')}</span>
          <span className="block text-xs font-medium text-foreground/75">
            {L('PIN இல்லாமல் உதவுபவர்கள் குடும்பத்தை அழைக்க', 'Lets bystanders call family without your PIN')}
          </span>
        </span>
      </button>
      {open ? <LockScreenCard onClose={() => setOpen(false)} /> : null}
    </>
  )
}

function LockScreenCard({ onClose }: { onClose: () => void }) {
  const { L, contacts, userName } = useApp()
  const now = new Date()
  return (
    <div role="dialog" aria-modal="true" aria-labelledby="lock-title" className="absolute inset-0 z-50 flex flex-col overflow-y-auto bg-[#05080f] px-5 py-6 animate-in fade-in">
      <div className="flex items-center justify-between">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-2.5 py-1 text-xs font-bold">
          <Lock className="size-3.5" aria-hidden /> {L('முன்னோட்டம்', 'Preview')}
        </span>
        <button type="button" onClick={onClose} aria-label={L('மூடு', 'Close')} className="rounded-full bg-white/10 p-2">
          <X className="size-5" aria-hidden />
        </button>
      </div>

      <p className="mt-6 text-center font-mono text-6xl font-black tabular-nums">
        {now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: false })}
      </p>
      <p className="text-center text-sm font-semibold text-foreground/70">
        {now.toLocaleDateString('ta-IN', { weekday: 'long', day: 'numeric', month: 'long' })}
      </p>

      <div className="mt-6 rounded-2xl border-2 border-sos bg-sos/15 p-4">
        <h2 id="lock-title" className="flex items-center gap-2 text-lg font-black text-red-300">
          <HeartPulse className="size-6" aria-hidden /> {L('அவசர மருத்துவ அட்டை', 'Emergency Medical ID')}
        </h2>
        <p className="mt-1 text-sm font-semibold">
          {userName} · {L('இவருக்கு உதவ கீழே அழுத்தவும்', 'Tap below to help this person')}
        </p>
      </div>

      <ul className="mt-4 flex flex-col gap-3">
        {BYPASS.map((b, i) => {
          const phone = contacts[i]?.phone.replace(/[^\d+]/g, '') ?? ''
          const ready = phone.replace(/\D/g, '').length >= 10
          return (
            <li key={b.en}>
              <a
                href={ready ? `tel:${phone}` : undefined}
                aria-disabled={!ready}
                className={cn(
                  'btn-thick flex items-center gap-3 rounded-2xl border-2 p-4',
                  ready ? 'border-success bg-success text-background' : 'pointer-events-none border-white/15 bg-secondary text-foreground/60',
                )}
              >
                <Phone className="size-7 shrink-0" aria-hidden />
                <span className="min-w-0 flex-1">
                  <span className="block text-lg font-black leading-tight">
                    {b.ta} ({b.en})
                  </span>
                  <span className="block font-mono text-sm font-bold">
                    {ready ? phone : L('எண் சேமிக்கப்படவில்லை — தனியுரிமை தாவலில் சேர்க்கவும்', 'No number saved — add it in Privacy')}
                  </span>
                </span>
              </a>
            </li>
          )
        })}
      </ul>

      <div className="mt-3 grid grid-cols-2 gap-3">
        <a href="tel:112" className="btn-thick flex items-center justify-center gap-2 rounded-2xl bg-[#b91c1c] py-3.5 font-black text-white">
          <Siren className="size-5" aria-hidden /> 112
        </a>
        <a href="tel:108" className="btn-thick flex items-center justify-center gap-2 rounded-2xl bg-primary py-3.5 font-black text-primary-foreground">
          <Ambulance className="size-5" aria-hidden /> 108
        </a>
      </div>

      <p className="mt-4 text-xs leading-relaxed text-foreground/65 text-pretty">
        {L(
          'இது ஒரு முன்னோட்டம். உண்மையான லாக் ஸ்கிரீனில் இதைக் காட்ட: Android Settings › Safety & emergency › Medical information மற்றும் Emergency contacts-ல் இதே எண்களைச் சேர்க்கவும்.',
          'This is a preview. To show it on your real lock screen, add the same numbers in Android Settings › Safety & emergency › Medical information and Emergency contacts.',
        )}
      </p>
    </div>
  )
}
