'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { Check, Info, Loader2, Lock, MapPin, MessageCircle, MessageSquare, Phone, Power, RotateCcw, Users, Volume2, VolumeX } from 'lucide-react'
import { beep, startSiren } from '@/lib/audio'
import { SOURCE_LABEL, toIntlNumber, useApp, vibrate, type TriggerSource } from '@/lib/store'
import { cn } from '@/lib/utils'
import { GpsErrorAlert } from './primitives'

const COUNTDOWN = 15

export function EmergencyOverlay() {
  const { emergency } = useApp()
  if (emergency.stage === 'countdown') return <Countdown source={emergency.source} />
  if (emergency.stage === 'active') return <ActiveSOS source={emergency.source} />
  return null
}

function Countdown({ source }: { source: TriggerSource }) {
  const { L, cancelEmergency, activateSOS, contacts } = useApp()
  const [left, setLeft] = useState(COUNTDOWN)

  useEffect(() => {
    vibrate([800, 200])
    beep(1250)
    const id = setInterval(() => {
      setLeft((l) => {
        if (l <= 1) {
          clearInterval(id)
          return 0
        }
        vibrate([800, 200])
        beep(l % 2 ? 1250 : 880)
        return l - 1
      })
    }, 1000)
    return () => {
      clearInterval(id)
      vibrate(0)
    }
  }, [])

  useEffect(() => {
    if (left === 0) activateSOS(source)
  }, [left, source, activateSOS])

  const pct = ((COUNTDOWN - left) / COUNTDOWN) * 100
  const named = contacts.map((c) => c.name).filter(Boolean)
  const C = 2 * Math.PI * 45

  return (
    <div
      role="alertdialog"
      aria-modal="true"
      aria-labelledby="cd-title"
      className="absolute inset-0 z-50 flex flex-col items-center justify-between overflow-y-auto bg-[#2a0606]/97 px-5 py-8 backdrop-blur animate-in fade-in"
    >
      <div className="text-center">
        <p className="inline-flex rounded-full border-2 border-gold/60 bg-gold/15 px-3 py-1 text-xs font-bold text-gold">
          {L('குடும்ப முன்னுரிமை அலாரத் தடுப்பு', 'Family-First Anti-False Alarm')}
        </p>
        <h2 id="cd-title" className="mt-3 text-2xl font-black text-balance">
          {L(SOURCE_LABEL[source][0], SOURCE_LABEL[source][1])} {L('கண்டறியப்பட்டது!', 'detected!')}
        </h2>
        <p className="mt-2 text-lg font-bold text-gold text-balance" aria-live="assertive">
          {L(`தவறான அலாரமா? நிறுத்த ${left} வினாடிகள் உள்ளன`, `False alarm? ${left} seconds left to stop`)}
        </p>
      </div>

      <div className="relative my-4 flex size-56 shrink-0 items-center justify-center">
        <div className="sos-glow absolute inset-6 rounded-full" aria-hidden />
        <svg viewBox="0 0 100 100" className="absolute inset-0 -rotate-90" aria-hidden>
          <circle cx="50" cy="50" r="45" fill="none" stroke="rgb(255 255 255 / 0.12)" strokeWidth="8" />
          <circle
            cx="50"
            cy="50"
            r="45"
            fill="none"
            stroke="var(--sos)"
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={C}
            strokeDashoffset={(C * (100 - pct)) / 100}
            className="transition-[stroke-dashoffset] duration-1000 ease-linear"
          />
        </svg>
        <div className="text-center">
          <span className="block text-8xl font-black tabular-nums">{left}</span>
          <span className="text-sm font-bold text-foreground/80">{L('வினாடிகள்', 'seconds')}</span>
        </div>
      </div>

      <div className="w-full space-y-3">
        <p className="rounded-xl border-2 border-white/15 bg-black/30 p-3 text-center text-xs leading-relaxed text-foreground/90 text-pretty">
          {L('ரத்து செய்யாவிட்டால், இவர்களுக்கான அவசரச் செய்தி தயாராகும்: ', 'If not cancelled, an emergency message will be prepared for: ')}
          <strong className="text-gold">{named.join(', ') || L('உங்கள் 3 அவசரத் தொடர்புகள்', 'your 3 emergency contacts')}</strong>
        </p>
        <button
          type="button"
          onClick={cancelEmergency}
          autoFocus
          className="btn-thick w-full rounded-2xl border-2 border-white bg-white py-5 text-xl font-black text-[#0F172A]"
        >
          {L('அலாரத்தை ரத்துசெய் (Cancel)', 'Cancel Alarm')}
        </button>
        <button
          type="button"
          onClick={() => activateSOS(source)}
          className="w-full rounded-2xl border-2 border-sos py-3 text-sm font-bold text-red-300"
        >
          {L('இப்போதே எச்சரிக்கை அனுப்பு', 'Send alert now')}
        </button>
      </div>
    </div>
  )
}

type GpsState = 'locating' | 'error' | { lat: number; lng: number; at: string }

function buildAlert(lang: 'ta' | 'en', name: string, source: TriggerSource, gps: GpsState) {
  const loc = typeof gps === 'object' ? `https://maps.google.com/?q=${gps.lat.toFixed(6)},${gps.lng.toFixed(6)}` : null
  const time = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
  if (lang === 'en') {
    return `SOS from ${name} via Nanbanda (${SOURCE_LABEL[source][1]}, ${time}). I need help now. ${
      loc ? `My location: ${loc}` : 'My GPS is unavailable — please call me.'
    } If you cannot reach me, call 112.`
  }
  return `அவசர உதவி! ${name} — நண்பேன்டா SOS (${SOURCE_LABEL[source][0]}, ${time}). எனக்கு உடனே உதவி தேவை. ${
    loc ? `என் இருப்பிடம்: ${loc}` : 'என் GPS கிடைக்கவில்லை — உடனே அழைக்கவும்.'
  } என்னைத் தொடர்பு கொள்ள முடியாவிட்டால் 112-ஐ அழைக்கவும்.`
}

function ActiveSOS({ source }: { source: TriggerSource }) {
  const { L, language, userName, cancelEmergency, contacts, logLocation } = useApp()
  const [gps, setGps] = useState<GpsState>('locating')
  const [opened, setOpened] = useState<Record<string, boolean>>({})
  const [shutdown, setShutdown] = useState(false)
  const [sirenOn, setSirenOn] = useState(true)

  useEffect(() => {
    if (!sirenOn || shutdown) return
    return startSiren()
  }, [sirenOn, shutdown])

  const locate = useCallback(async () => {
    setGps('locating')
    const point = await logLocation(`SOS: ${source}`)
    setGps(point ? { lat: point.lat, lng: point.lng, at: point.at } : 'error')
  }, [logLocation, source])

  useEffect(() => {
    void locate()
    const track = setInterval(async () => {
      const point = await logLocation('SOS tracking')
      if (point) setGps({ lat: point.lat, lng: point.lng, at: point.at })
    }, 15000)
    return () => clearInterval(track)
  }, [locate, logLocation])

  const automatic = source !== 'Manual SOS'
  const saved = contacts.filter((c) => c.phone.replace(/\D/g, '').length >= 10)
  const message = buildAlert(language === 'en' ? 'en' : 'ta', userName || L('நண்பேன்டா பயனர்', 'Nanbanda user'), source, gps)
  const body = encodeURIComponent(message)
  const smsAll = `sms:${saved.map((c) => `+${toIntlNumber(c.phone)}`).join(',')}?body=${body}`
  const mark = (key: string) => setOpened((o) => ({ ...o, [key]: true }))

  return (
    <div className="absolute inset-0 z-50 flex flex-col overflow-y-auto bg-background animate-in fade-in" role="dialog" aria-modal="true" aria-labelledby="sos-title">
      <div className="bg-sos px-5 pb-5 pt-7 text-white">
        <div className="flex items-center justify-between gap-2">
          <p className="inline-flex items-center gap-1.5 rounded-full bg-black/25 px-2.5 py-1 text-xs font-bold">
            <Lock className="size-3.5" aria-hidden /> SOS · {L(SOURCE_LABEL[source][0], SOURCE_LABEL[source][1])}
          </p>
          <button
            type="button"
            onClick={() => setSirenOn((s) => !s)}
            className="inline-flex items-center gap-1.5 rounded-full border-2 border-white/40 px-3 py-1 text-xs font-bold"
          >
            {sirenOn ? <VolumeX className="size-4" aria-hidden /> : <Volume2 className="size-4" aria-hidden />}
            {sirenOn ? L('சைரன் நிறுத்து', 'Mute siren') : L('சைரன் இயக்கு', 'Siren on')}
          </button>
        </div>
        <h2 id="sos-title" className="mt-3 text-2xl font-black leading-tight text-balance">
          {L('அவசரச் செய்தி தயார் — இப்போதே அனுப்புங்கள்', 'Emergency message ready — send it now')}
        </h2>
        <p className="mt-1 text-sm font-medium text-white/90 text-pretty">
          {L(
            'கீழே உள்ள SMS / வாட்ஸ்அப் பட்டனை அழுத்தி அனுப்பு என்பதைத் தட்டவும். அமைதியாக இருங்கள்.',
            'Tap an SMS / WhatsApp button below, then press Send in that app. Stay calm.',
          )}
        </p>
      </div>

      <div className="flex-1 space-y-3 p-4">
        <div className="flex items-start gap-3 rounded-2xl border-2 border-gold/60 bg-gold/10 p-3.5" role="note">
          <Info className="mt-0.5 size-5 shrink-0 text-gold" aria-hidden />
          <div className="text-xs leading-relaxed text-foreground/95">
            <p className="font-black text-gold">{L('சிமுலேஷன் முறை — தானியங்கி அனுப்புதல் இல்லை', 'Simulation mode — nothing is sent automatically')}</p>
            <p className="mt-1 font-medium text-pretty">
              {L(
                'உங்கள் சேமித்த 3 அவசரத் தொடர்புகளுக்கான நேரடி SMS / வாட்ஸ்அப் செய்தி டெம்ப்ளேட்கள் லைவ் லொகேஷனுடன் உருவாக்கப்படுகின்றன. நீங்கள் அனுப்பு அழுத்தும் வரை யாருக்கும் செய்தி செல்லாது.',
                'Live SMS / WhatsApp text templates with your real-time location are generated for your 3 saved emergency contacts. No one is alerted until you press Send.',
              )}
            </p>
            {automatic ? (
              <p className="mt-1 font-medium">{L(`தூண்டியது: ${SOURCE_LABEL[source][0]}`, `Triggered by: ${SOURCE_LABEL[source][1]}`)}</p>
            ) : null}
          </div>
        </div>

        {gps === 'error' ? (
          <GpsErrorAlert onRetry={() => void locate()} />
        ) : (
          <div className="flex items-center gap-3 rounded-2xl border-2 border-white/15 bg-card p-3.5">
            <span className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary/15 text-primary">
              <MapPin className="size-5" aria-hidden />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold">{L('லைவ் ஜிபிஎஸ்', 'Live GPS')}</p>
              <p className="font-mono text-xs text-foreground/80" aria-live="polite">
                {gps === 'locating' ? L('இருப்பிடம் கண்டறியப்படுகிறது…', 'Getting your location…') : `${gps.lat.toFixed(5)}, ${gps.lng.toFixed(5)}`}
              </p>
            </div>
            {gps === 'locating' ? (
              <Loader2 className="size-6 animate-spin text-primary" aria-label={L('நடைபெறுகிறது', 'In progress')} />
            ) : (
              <Check className="size-6 text-success" aria-label={L('கிடைத்தது', 'Located')} />
            )}
          </div>
        )}

        <section className="rounded-2xl border-2 border-white/15 bg-card p-3.5" aria-labelledby="tpl-title">
          <h3 id="tpl-title" className="flex items-center gap-2 text-sm font-bold">
            <Users className="size-5 text-primary" aria-hidden /> {L('அவசரத் தொடர்புகளுக்கான செய்தி', 'Message for your emergency contacts')}
          </h3>
          <p className="mt-2 whitespace-pre-wrap rounded-xl border-2 border-dashed border-white/20 bg-secondary p-3 text-xs leading-relaxed">{message}</p>

          {saved.length === 0 ? (
            <p className="mt-3 rounded-xl border-2 border-sos bg-sos/10 p-3 text-xs font-bold text-sos" role="alert">
              {L(
                'அவசர எண்கள் எதுவும் சேமிக்கப்படவில்லை. தனியுரிமை தாவலில் 3 எண்களைச் சேர்க்கவும். இப்போது 112-ஐ அழைக்கவும்.',
                'No emergency numbers saved. Add 3 numbers in the Privacy tab. Call 112 now.',
              )}
            </p>
          ) : (
            <>
              <a
                href={smsAll}
                onClick={() => mark('sms-all')}
                className="btn-thick mt-3 flex items-center justify-center gap-2 rounded-xl bg-primary py-3.5 text-sm font-black text-primary-foreground"
              >
                <MessageSquare className="size-5" aria-hidden />
                {L(`${saved.length} பேருக்கும் SMS திற`, `Open SMS to all ${saved.length}`)}
                {opened['sms-all'] ? <Check className="size-4" aria-label={L('திறக்கப்பட்டது', 'Opened')} /> : null}
              </a>
              <ul className="mt-2 flex flex-col gap-2">
                {saved.map((c, i) => {
                  const key = `wa-${i}`
                  return (
                    <li key={key} className="flex items-center gap-2 rounded-xl border-2 border-white/15 bg-secondary p-2.5">
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-bold">{c.name || L(`தொடர்பு ${i + 1}`, `Contact ${i + 1}`)}</p>
                        <p className="font-mono text-xs text-foreground/75">+{toIntlNumber(c.phone)}</p>
                      </div>
                      <a
                        href={`https://wa.me/${toIntlNumber(c.phone)}?text=${body}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={() => mark(key)}
                        className="btn-thick inline-flex items-center gap-1.5 rounded-lg bg-whatsapp px-3 py-2 text-xs font-black text-background"
                      >
                        {opened[key] ? <Check className="size-4" aria-hidden /> : <MessageCircle className="size-4" aria-hidden />}
                        {opened[key] ? L('திறக்கப்பட்டது', 'Opened') : L('வாட்ஸ்அப்', 'WhatsApp')}
                      </a>
                    </li>
                  )
                })}
              </ul>
              <p className="mt-2 text-[11px] leading-relaxed text-foreground/70">
                {L(
                  '"திறக்கப்பட்���து" என்றால் செய்தி ஆப் திறந்தது மட்டுமே — அனுப்பியதாக அர்த்தமில்லை.',
                  '"Opened" only means the messaging app was opened — not that the message was delivered.',
                )}
              </p>
            </>
          )}
        </section>

        <a href="tel:112" className="btn-thick flex items-center justify-center gap-2 rounded-2xl border-2 border-white bg-white py-4 text-base font-black text-[#0F172A]">
          <Phone className="size-5" aria-hidden /> {L('காவல்துறைக்கு அழை · 112', 'Escalate to Police · 112')}
        </a>

        <FailSafe message={message} />

        <div className="rounded-2xl border-2 border-dashed border-white/25 p-4">
          <p className="text-sm font-bold text-gold">{L('போலி சுவிட்ச்-ஆஃப் சோதனை', 'Stealth power-off demo')}</p>
          <p className="mt-1 text-xs leading-relaxed text-foreground/85">
            {L(
              'திருடன் பவர் பட்டனை அழுத்திப் பிடிப்பது போல் சோதிக்கவும். கருப்புத் திரையிலிருந்து வெளியேற இடது மேல் மூலையை 3 முறை தட்டவும்.',
              'Simulate a thief holding the power button. Triple-tap the top-left corner of the black screen to exit.',
            )}
          </p>
          <button
            type="button"
            onClick={() => setShutdown(true)}
            className="btn-thick mt-3 inline-flex items-center gap-2 rounded-xl border-2 border-white/20 bg-black px-4 py-2.5 text-sm font-bold text-white"
          >
            <Power className="size-4" aria-hidden /> {L('பவர் ஆஃப் முயற்சி', 'Try power off')}
          </button>
        </div>

        <button type="button" onClick={cancelEmergency} className="w-full rounded-2xl border-2 border-success/60 bg-success/10 py-4 text-base font-bold text-success">
          {L('நான் பாதுகாப்பாக இருக்கிறேன் — SOS முடி', "I'm safe — end SOS")}
        </button>
      </div>

      {shutdown ? <FakeShutdown onExit={() => setShutdown(false)} /> : null}
    </div>
  )
}

const FAIL_SAFE_SECONDS = 120

function FailSafe({ message }: { message: string }) {
  const { L } = useApp()
  const [left, setLeft] = useState(FAIL_SAFE_SECONDS)
  const [responded, setResponded] = useState(false)

  useEffect(() => {
    if (responded) return
    const id = setInterval(() => setLeft((l) => Math.max(0, l - 1)), 1000)
    return () => clearInterval(id)
  }, [responded])

  const escalated = left === 0 && !responded

  useEffect(() => {
    if (!escalated) return
    vibrate([600, 200, 600, 200, 600])
    beep(1400)
  }, [escalated])

  if (responded) {
    return (
      <p role="status" className="flex items-center gap-2 rounded-2xl border-2 border-success bg-success/10 p-3.5 text-sm font-black text-success">
        <Check className="size-5" aria-hidden /> {L('குடும்பம் பதில் அளித்தது — 108/112 தானியங்கி திறப்பு நிறுத்தப்பட்டது', 'Family responded — 108/112 auto-escalation stopped')}
      </p>
    )
  }

  const mm = String(Math.floor(left / 60)).padStart(1, '0')
  const ss = String(left % 60).padStart(2, '0')
  const body = encodeURIComponent(message)

  return (
    <section
      aria-labelledby="failsafe-title"
      className={cn('rounded-2xl border-2 p-3.5', escalated ? 'border-sos bg-sos text-white' : 'border-sos/60 bg-sos/10')}
    >
      <div className="flex items-center justify-between gap-3">
        <h3 id="failsafe-title" className="text-sm font-black">
          {escalated ? L('குடும்பம் பதில் இல்லை — 108 / 112-ஐ இப்போதே தொடர்பு கொள்ளுங்கள்', 'No family response — contact 108 / 112 now') : L('2 நிமிட பாதுகாப்பு அரண்', '2-minute fail-safe')}
        </h3>
        {!escalated ? (
          <span className="rounded-lg bg-sos px-2.5 py-1 font-mono text-lg font-black tabular-nums text-white" aria-live="off">
            {mm}:{ss}
          </span>
        ) : null}
      </div>

      {escalated ? (
        <div role="alert" className="mt-3 flex flex-col gap-2">
          <div className="grid grid-cols-2 gap-2">
            <a href="tel:108" className="btn-thick flex items-center justify-center gap-2 rounded-xl bg-white py-3.5 font-black text-[#0F172A]">
              <Phone className="size-5" aria-hidden /> 108
            </a>
            <a href="tel:112" className="btn-thick flex items-center justify-center gap-2 rounded-xl bg-white py-3.5 font-black text-[#0F172A]">
              <Phone className="size-5" aria-hidden /> 112
            </a>
          </div>
          <a href={`sms:112?body=${body}`} className="btn-thick flex items-center justify-center gap-2 rounded-xl border-2 border-white py-3 text-sm font-black">
            <MessageSquare className="size-5" aria-hidden /> {L('GPS உடன் 112-க்கு SMS திற', 'Open SMS to 112 with GPS')}
          </a>
        </div>
      ) : (
        <p className="mt-2 text-xs leading-relaxed text-foreground/85 text-pretty">
          {L(
            'குடும்பத்தினர் பதில் அளிக்காவிட்டால், டைமர் முடிந்ததும் 108 / 112 அழைப்பு & GPS SMS திரை தானாகத் திறக்கும்.',
            'If family does not respond, the 108 / 112 call & GPS SMS screen opens when the timer ends.',
          )}
        </p>
      )}

      <button
        type="button"
        onClick={() => setResponded(true)}
        className={cn('mt-3 w-full rounded-xl border-2 py-3 text-sm font-bold', escalated ? 'border-white/70' : 'border-success/60 text-success')}
      >
        {L('குடும்பம் பதில் அளித்தது', 'Family responded')}
      </button>
    </section>
  )
}

function FakeShutdown({ onExit }: { onExit: () => void }) {
  const { L } = useApp()
  const [phase, setPhase] = useState<'menu' | 'shutting' | 'black'>('menu')
  const taps = useRef<number[]>([])

  useEffect(() => {
    if (phase !== 'shutting') return
    const id = setTimeout(() => setPhase('black'), 2600)
    return () => clearTimeout(id)
  }, [phase])

  const secretTap = () => {
    const now = Date.now()
    taps.current = [...taps.current.filter((t) => now - t < 800), now]
    if (taps.current.length >= 3) onExit()
  }

  return (
    <div className="absolute inset-0 z-[70] bg-black">
      <button type="button" aria-label={L('மறைவான வெளியேற்றம் — 3 முறை தட்டவும்', 'Hidden exit — triple tap')} onClick={secretTap} className="absolute left-0 top-0 z-10 size-16 opacity-0" />

      {phase === 'menu' ? (
        <div className="flex h-full flex-col items-center justify-center gap-8 bg-black/80 backdrop-blur-xl animate-in fade-in">
          <button type="button" onClick={() => setPhase('shutting')} className="flex flex-col items-center gap-2">
            <span className="flex size-16 items-center justify-center rounded-full bg-[#e53935] text-white">
              <Power className="size-7" aria-hidden />
            </span>
            <span className="text-sm text-white">Power off</span>
          </button>
          <button type="button" onClick={() => setPhase('shutting')} className="flex flex-col items-center gap-2">
            <span className="flex size-16 items-center justify-center rounded-full bg-white/15 text-white">
              <RotateCcw className="size-7" aria-hidden />
            </span>
            <span className="text-sm text-white">Restart</span>
          </button>
        </div>
      ) : null}

      {phase === 'shutting' ? (
        <div className="flex h-full flex-col items-center justify-center gap-4 animate-in fade-in">
          <Loader2 className="size-8 animate-spin text-white/70" aria-hidden />
          <p className="text-sm text-white/70">Shutting down…</p>
        </div>
      ) : null}

      <div className={cn('absolute inset-0 bg-black transition-opacity duration-700', phase === 'black' ? 'opacity-100' : 'pointer-events-none opacity-0')} />
    </div>
  )
}
