'use client'

import { useEffect, useState } from 'react'
import { ChevronDown, CreditCard, Landmark, Loader2, Lock, PartyPopper, ShieldCheck, Smartphone } from 'lucide-react'
import { useApp } from '@/lib/store'
import { cn } from '@/lib/utils'
import { Sheet } from './primitives'

const UPI_APPS = [
  { id: 'gpay', label: 'Google Pay', logo: '/brands/google-pay.svg' },
  { id: 'phonepe', label: 'PhonePe', logo: '/brands/phonepe.svg' },
  { id: 'paytm', label: 'Paytm', logo: '/brands/paytm.svg' },
] as const

const BANKS = [
  { id: 'sbi', label: 'State Bank of India' },
  { id: 'hdfc', label: 'HDFC Bank' },
  { id: 'icici', label: 'ICICI Bank' },
  { id: 'axis', label: 'Axis Bank' },
  { id: 'iob', label: 'Indian Overseas Bank' },
  { id: 'indian', label: 'Indian Bank' },
] as const

const SAVED_CARDS = [
  { id: 'card-hdfc', label: 'HDFC Bank · Visa', last4: '4821' },
  { id: 'card-sbi', label: 'SBI · RuPay', last4: '0937' },
] as const

type Section = 'upi' | 'netbanking' | 'cards'
type Choice = string

function labelFor(choice: Choice) {
  return (
    UPI_APPS.find((u) => u.id === choice)?.label ??
    BANKS.find((b) => b.id === choice)?.label ??
    SAVED_CARDS.find((c) => c.id === choice)?.label ??
    'Razorpay'
  )
}

function RazorpayMark({ className }: { className?: string }) {
  return (
    <span className={cn('inline-flex items-center gap-1 font-black tracking-tight', className)}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src="/brands/razorpay.svg" alt="" aria-hidden className="size-4" />
      Razorpay
    </span>
  )
}

export function CheckoutSheet({ mode, onClose }: { mode: 'pay' | 'waiver'; onClose: () => void }) {
  const { update, L } = useApp()
  const [section, setSection] = useState<Section>('upi')
  const [choice, setChoice] = useState<Choice>('gpay')
  const [phase, setPhase] = useState<'select' | 'processing' | 'done'>('select')
  const [policyNo, setPolicyNo] = useState('')
  const amount = mode === 'waiver' ? 0 : 49

  useEffect(() => {
    if (phase !== 'processing') return
    const id = setTimeout(() => {
      setPhase('done')
      update({ premium: true })
    }, 2600)
    return () => clearTimeout(id)
  }, [phase, update])

  const canPay = mode === 'waiver' ? /^[A-Z0-9/-]{6,}$/i.test(policyNo.trim()) : Boolean(choice)

  const openSection = (s: Section) => {
    setSection(s)
    setChoice(s === 'upi' ? 'gpay' : s === 'netbanking' ? 'sbi' : SAVED_CARDS[0].id)
  }

  if (phase === 'processing') {
    return (
      <Sheet title="Razorpay" onClose={() => {}}>
        <div className="flex flex-col items-center py-10 text-center" role="status" aria-live="polite">
          <span className="relative flex size-20 items-center justify-center">
            <Loader2 className="absolute size-20 animate-spin text-razorpay" aria-hidden />
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/brands/razorpay.svg" alt="" aria-hidden className="size-8" />
          </span>
          <p className="mt-5 text-lg font-black">{L('Razorpay மூலம் செயலாக்கப்படுகிறது...', 'Processing via Razorpay...')}</p>
          <p className="mt-1 text-sm text-foreground/75">
            {mode === 'waiver' ? L('பாலிசி சரிபார்க்கப்படுகிறது', 'Verifying policy') : labelFor(choice)}
            {' · '}
            {L('ஆப்பை மூட வேண்டாம்', 'Do not close the app')}
          </p>
        </div>
      </Sheet>
    )
  }

  if (phase === 'done') {
    return (
      <Sheet title={L('வெற்றி!', 'Success!')} onClose={onClose}>
        <div className="flex flex-col items-center rounded-2xl border-2 border-success bg-success/15 px-4 py-8 text-center animate-in zoom-in-95">
          <span className="flex size-20 items-center justify-center rounded-full bg-success">
            <PartyPopper className="size-10 text-background" aria-hidden />
          </span>
          <p className="mt-4 text-xl font-black leading-snug text-success text-balance">
            {L('பிரீமியம் பிளான் ஆக்டிவேட் செய்யப்பட்டது!', 'Premium plan activated!')}
          </p>
          <p className="mt-2 text-sm font-medium">
            {mode === 'waiver'
              ? L('100% கட்டண விலக்கு — ₹0 வசூலிக்கப்பட்டது.', '100% waiver applied — ₹0 charged.')
              : L(`₹${amount} ${labelFor(choice)} மூலம் (டெஸ்ட் முறை)`, `₹${amount} via ${labelFor(choice)} (test mode)`)}
          </p>
          <button type="button" onClick={onClose} className="btn-thick mt-6 w-full rounded-xl bg-success py-3.5 font-black text-background">
            {L('தொடரவும்', 'Continue')}
          </button>
        </div>
      </Sheet>
    )
  }

  return (
    <Sheet title={mode === 'waiver' ? L('பாலிசி இணைத்து கட்டண விலக்கு', 'Link Policy & Waiver') : L('பணம் செலுத்துதல்', 'Checkout')} onClose={onClose}>
      <div className="overflow-hidden rounded-2xl border-2 border-razorpay/50">
        <div className="flex items-center justify-between gap-3 bg-razorpay-navy px-4 py-3 text-foreground">
          <div className="min-w-0">
            <p className="text-xs font-semibold opacity-80">{L('நண்பேன்டா பிரீமியம் · மாதாந்திரம்', 'Nanbanda Premium · Monthly')}</p>
            <p className="text-2xl font-black tabular-nums">
              {mode === 'waiver' ? <span className="mr-2 text-base font-bold opacity-60 line-through">₹49</span> : null}₹{amount}
            </p>
          </div>
          <span className="rounded-lg bg-foreground px-2.5 py-1.5 text-xs text-razorpay-navy">
            <RazorpayMark />
          </span>
        </div>

        {mode === 'waiver' ? (
          <div className="bg-card p-4">
            <label htmlFor="pol" className="text-xs font-bold text-foreground/80">
              {L('பாலிசி / புதுப்பித்தல் எண்', 'Policy / renewal number')}
            </label>
            <input
              id="pol"
              value={policyNo}
              onChange={(e) => setPolicyNo(e.target.value.toUpperCase())}
              placeholder="ICL/MTR/26/88120"
              autoComplete="off"
              className="mt-1.5 w-full rounded-xl border-2 bg-secondary px-3 py-2.5 font-mono text-sm outline-none focus:border-razorpay"
            />
          </div>
        ) : (
          <div className="flex flex-col bg-card">
            <MethodSection
              open={section === 'upi'}
              onOpen={() => openSection('upi')}
              icon={<Smartphone className="size-5" aria-hidden />}
              title="UPI"
              hint={L('GPay · PhonePe · Paytm', 'GPay · PhonePe · Paytm')}
            >
              <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label={L('UPI ஆப்', 'UPI app')}>
                {UPI_APPS.map((u) => (
                  <button
                    key={u.id}
                    type="button"
                    role="radio"
                    aria-checked={choice === u.id}
                    onClick={() => setChoice(u.id)}
                    className={cn(
                      'flex flex-col items-center gap-1.5 rounded-xl border-2 bg-secondary p-3 text-xs font-bold',
                      choice === u.id ? 'border-razorpay bg-razorpay/15' : 'border-white/15',
                    )}
                  >
                    <span className="flex size-10 items-center justify-center rounded-lg bg-foreground p-1.5">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={u.logo} alt="" aria-hidden className="size-full object-contain" />
                    </span>
                    {u.label}
                  </button>
                ))}
              </div>
            </MethodSection>

            <MethodSection
              open={section === 'netbanking'}
              onOpen={() => openSection('netbanking')}
              icon={<Landmark className="size-5" aria-hidden />}
              title={L('நெட்பேங்கிங்', 'Netbanking')}
              hint={L('அனைத்து முக்கிய வங்கிகள்', 'All major banks')}
            >
              <div className="grid grid-cols-2 gap-2" role="radiogroup" aria-label={L('வங்கி', 'Bank')}>
                {BANKS.map((b) => (
                  <button
                    key={b.id}
                    type="button"
                    role="radio"
                    aria-checked={choice === b.id}
                    onClick={() => setChoice(b.id)}
                    className={cn(
                      'rounded-xl border-2 bg-secondary px-3 py-2.5 text-left text-xs font-bold leading-snug',
                      choice === b.id ? 'border-razorpay bg-razorpay/15' : 'border-white/15',
                    )}
                  >
                    {b.label}
                  </button>
                ))}
              </div>
              <p className="mt-2 text-[11px] text-foreground/70">
                {L('உங்கள் வங்கியின் பாதுகாப்பான பக்கத்தில் உள்நுழைவீர்கள்.', "You'll sign in on your bank's secure page.")}
              </p>
            </MethodSection>

            <MethodSection
              open={section === 'cards'}
              onOpen={() => openSection('cards')}
              icon={<CreditCard className="size-5" aria-hidden />}
              title={L('சேமித்த கார்டுகள்', 'Saved Cards')}
              hint={L('RBI டோக்கனைஸ்டு', 'RBI tokenised')}
            >
              <div className="flex flex-col gap-2" role="radiogroup" aria-label={L('சேமித்த கார்டு', 'Saved card')}>
                {SAVED_CARDS.map((c) => (
                  <button
                    key={c.id}
                    type="button"
                    role="radio"
                    aria-checked={choice === c.id}
                    onClick={() => setChoice(c.id)}
                    className={cn(
                      'flex items-center gap-3 rounded-xl border-2 bg-secondary p-3 text-left',
                      choice === c.id ? 'border-razorpay bg-razorpay/15' : 'border-white/15',
                    )}
                  >
                    <CreditCard className="size-5 text-razorpay" aria-hidden />
                    <span className="min-w-0 flex-1">
                      <span className="block text-sm font-bold">{c.label}</span>
                      <span className="block font-mono text-xs text-foreground/75">•••• •••• •••• {c.last4}</span>
                    </span>
                    <span className={cn('size-4 rounded-full border-2', choice === c.id ? 'border-razorpay bg-razorpay' : 'border-white/30')} aria-hidden />
                  </button>
                ))}
              </div>
              <p className="mt-2 text-[11px] text-foreground/70">
                {L(
                  'புதிய கார்டு விவரங்கள் இந்த ஆப்பில் கேட்கப்படாது — Razorpay பாதுகாப்பான பக்கத்தில் மட்டுமே.',
                  'New card details are never collected in this app — only on Razorpay’s secure page.',
                )}
              </p>
            </MethodSection>
          </div>
        )}
      </div>

      <button
        type="button"
        disabled={!canPay}
        onClick={() => setPhase('processing')}
        className="btn-thick mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-razorpay py-4 font-black text-foreground disabled:opacity-50"
      >
        <Lock className="size-4" aria-hidden />
        {mode === 'waiver' ? L('சரிபார்த்து இலவசமாக ஆக்டிவேட் செய்', 'Verify & activate free') : L(`₹${amount} பாதுகாப்பாகச் செலுத்து`, `Pay ₹${amount} securely`)}
      </button>

      <div className="mt-3 flex flex-col items-center gap-1.5 text-center">
        <p className="flex items-center gap-1.5 text-xs font-bold text-foreground/85">
          <ShieldCheck className="size-4 text-success" aria-hidden />
          {L('பாதுகாப்பானது', 'Secured by')} <RazorpayMark className="text-razorpay" />
        </p>
        <p className="text-[11px] text-foreground/65">PCI DSS · 256-bit SSL · UPI · RuPay · Visa · Mastercard</p>
        <p className="rounded-full border border-gold/50 px-2.5 py-0.5 text-[11px] font-bold text-gold">
          {L('டெஸ்ட் முறை · உண்மையான பணம் வசூலிக்கப்படாது', 'Test mode · no real money charged')}
        </p>
      </div>
    </Sheet>
  )
}

function MethodSection({
  open,
  onOpen,
  icon,
  title,
  hint,
  children,
}: {
  open: boolean
  onOpen: () => void
  icon: React.ReactNode
  title: string
  hint: string
  children: React.ReactNode
}) {
  return (
    <div className="border-t-2 border-white/10 first:border-t-0">
      <button type="button" onClick={onOpen} aria-expanded={open} className="flex w-full items-center gap-3 px-4 py-3 text-left">
        <span className={cn('flex size-9 items-center justify-center rounded-lg', open ? 'bg-razorpay text-foreground' : 'bg-secondary text-razorpay')}>{icon}</span>
        <span className="min-w-0 flex-1">
          <span className="block text-sm font-black">{title}</span>
          <span className="block text-xs text-foreground/70">{hint}</span>
        </span>
        <ChevronDown className={cn('size-5 transition-transform', open && 'rotate-180')} aria-hidden />
      </button>
      {open ? <div className="px-4 pb-4">{children}</div> : null}
    </div>
  )
}
