'use client'

import { useEffect, useRef, useState } from 'react'
import {
  AlarmClock,
  Baby,
  BellRing,
  Briefcase,
  Check,
  ChevronDown,
  HeartPulse,
  Home,
  Loader2,
  MapPin,
  Moon,
  Phone,
  Pill,
  Plus,
  Send,
  ThumbsDown,
  ThumbsUp,
  Trash2,
  Volume2,
  X,
} from 'lucide-react'
import { chime } from '@/lib/audio'
import { getPosition, speak, toIntlNumber, useApp, type CareSettings, type ParentLogEntry, type ParentSlot } from '@/lib/store'
import { cn } from '@/lib/utils'
import { GpsErrorAlert, Panel, SectionTitle, Switch } from './primitives'

const CHILD_MSG = 'உங்கள் பிள்ளைகள் இன்னும் வீடு திரும்பவில்லை! அவர்களின் தற்போதைய லைவ் லொகேஷனை நான் சரிபார்த்துச் சொல்லட்டுமா?'
const MORNING_MSG = 'காலை உணவு சாப்பிட்டீர்களா? உங்கள் சுகர்/பிபி மாத்திரை போட வேண்டிய நேரம் இது, மறந்துவிடாதீர்கள்!'
const ALERT_EVENT = 'nanbanda:care-alert'

type AlertKind = 'child' | 'morning'

const today = () => new Date().toLocaleDateString('en-CA')
const nowHHMM = () => new Date().toTimeString().slice(0, 5)

export function previewCareAlert(kind: AlertKind) {
  window.dispatchEvent(new CustomEvent<AlertKind>(ALERT_EVENT, { detail: kind }))
}

function useCare() {
  const { care, update } = useApp()
  const patch = <K extends keyof CareSettings>(key: K, value: Partial<CareSettings[K]> | CareSettings[K]) =>
    update({
      care: {
        ...care,
        [key]: typeof value === 'object' && !Array.isArray(value) && value !== null ? { ...(care[key] as object), ...value } : value,
      },
    })
  return { care, patch, update }
}

const CONDITIONS = [
  { id: 'bp' as const, ta: 'இரத்த அழுத்தம் (BP)', en: 'Blood Pressure (BP)' },
  { id: 'sugar' as const, ta: 'சர்க்கரை (Sugar)', en: 'Sugar (Diabetes)' },
  { id: 'custom' as const, ta: 'பிற நோய்', en: 'Custom condition' },
]

export function DailyCareTab() {
  const { care, patch } = useCare()
  const { L } = useApp()

  return (
    <div className="flex flex-col gap-4">
      <section className="rounded-2xl border-2 border-success/60 bg-success/10 p-4" aria-labelledby="care-q">
        <h2 id="care-q" className="flex items-center gap-2 text-lg font-black text-success">
          <BellRing className="size-6" aria-hidden />
          {L('தினசரி நல்வாழ்வு அமைப்பு', 'Daily Care Setup')}
        </h2>
        <p className="mt-2 text-base font-bold leading-relaxed text-pretty">
          {L('நண்பேன்டா தினசரி நல்வாழ்வு அறிவிப்புகள் உங்களுக்குத் தேவையா?', 'Do you want Nanbanda daily care notifications?')}
        </p>
        <div className="mt-3 grid grid-cols-2 gap-3" role="radiogroup" aria-labelledby="care-q">
          {[
            { v: true, ta: 'ஆம்', en: 'Yes', icon: Check },
            { v: false, ta: 'இல்லை', en: 'No', icon: X },
          ].map(({ v, ta, en, icon: Icon }) => (
            <button
              key={ta}
              type="button"
              role="radio"
              aria-checked={care.enabled === v}
              onClick={() => patch('enabled', v)}
              className={cn(
                'btn-thick flex items-center justify-center gap-2 rounded-xl border-2 py-4 text-lg font-black',
                care.enabled === v
                  ? v
                    ? 'border-success bg-success text-background'
                    : 'border-sos bg-sos text-foreground'
                  : 'border-white/20 bg-secondary text-foreground',
              )}
            >
              <Icon className="size-5" aria-hidden />
              {L(ta, en)}
            </button>
          ))}
        </div>
        {care.enabled === false ? (
          <p className="mt-3 text-sm text-foreground/80">
            {L('சரி நண்பா! எப்போது வேண்டுமானாலும் [ஆம்] அழுத்தி இயக்கலாம்.', 'Okay friend! Tap [Yes] any time to turn it on.')}
          </p>
        ) : null}
      </section>

      {care.enabled ? (
        <>
          <HealthReminders />
          <WorkReminders />
          <ChildAlert />
        </>
      ) : null}

      <ParentsCareShield />
      <NightCheckIn />
      <MorningAlarm />
    </div>
  )
}

export const PARENT_SLOTS: { slot: ParentSlot; time: string; label: [string, string]; msg: string; en: string }[] = [
  {
    slot: 'breakfast',
    time: '08:00',
    label: ['காலை', 'Morning'],
    msg: 'அம்மா, காலை உணவு சாப்பிட்டீர்களா? சுகர் மாத்திரை போட வேண்டிய நேரம் இது!',
    en: 'Amma, did you have breakfast? It is time for your sugar tablet!',
  },
  {
    slot: 'lunch',
    time: '12:30',
    label: ['மதியம்', 'Afternoon'],
    msg: 'அம்மா, மதிய உணவு சாப்பிட்டுவிட்டீர்களா? பிபி மாத்திரை போட நினைவூட்டுகிறோம்!',
    en: 'Amma, have you had lunch? A reminder to take your BP tablet!',
  },
  {
    slot: 'dinner',
    time: '19:00',
    label: ['இரவு', 'Night'],
    msg: 'அம்மா, இரவு உணவு மற்றும் மாத்திரைகளை எடுத்துக்கொண்டீர்களா?',
    en: 'Amma, have you had dinner and taken your tablets?',
  },
]

const to12h = (hhmm: string) => {
  const [h, m] = hhmm.split(':').map(Number)
  return `${((h + 11) % 12) + 1}:${String(m).padStart(2, '0')} ${h < 12 ? 'AM' : 'PM'}`
}

function ParentsCareShield() {
  const { care, patch } = useCare()
  const { L, contacts, showToast } = useApp()
  const parent = care.parent
  const now = nowHHMM()
  const todays = parent.log.filter((e) => e.date === today())
  const recent = parent.log.filter((e) => e.took).slice(0, 4)

  const answer = (slot: ParentSlot, took: boolean) => {
    const entry: ParentLogEntry = { date: today(), slot, took, at: new Date().toISOString() }
    patch('parent', { log: [entry, ...parent.log.filter((e) => !(e.date === entry.date && e.slot === slot))].slice(0, 60) })
    showToast(
      took
        ? L('பதிவு செய்யப்பட்டது: பெற்றோர் உணவு & மாத்திரை எடுத்துக்கொண்டார்', 'Logged: Parent has taken meals & medicines safely')
        : L('பரவாயில்லை அம்மா, இப்போதே சாப்பிடுங்கள்', 'No worries, Amma — please have it now'),
    )
  }

  const first = contacts.find((c) => c.phone.replace(/\D/g, '').length >= 10)
  const shareUpdate = () => {
    const lines = todays
      .filter((e) => e.took)
      .map((e) => {
        const s = PARENT_SLOTS.find((p) => p.slot === e.slot)!
        return `✔ ${s.label[0]} (${new Date(e.at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })})`
      })
    const msg = `நண்பேன்டா பெற்றோர் நல்வாழ்வு அப்டேட் — Parent has taken meals & medicines safely.\n${lines.join('\n')}`
    window.open(`https://wa.me/${first ? toIntlNumber(first.phone) : ''}?text=${encodeURIComponent(msg)}`, '_blank', 'noopener,noreferrer')
  }

  return (
    <section className="rounded-2xl border-2 border-pink/60 bg-card" aria-labelledby="parent-title">
      <div className="flex items-center gap-3 border-b-2 border-white/10 p-4">
        <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-pink text-background">
          <HeartPulse className="size-6" aria-hidden />
        </span>
        <div className="min-w-0 flex-1">
          <h2 id="parent-title" className="text-base font-black leading-snug">
            {L('பெற்றோர் நல்வாழ்வு அரண்', 'Parents Care Shield')}
          </h2>
          <p className="text-xs font-medium text-foreground/75">{L('வயதான பெற்றோருக்கான தானியங்கி நினைவூட்டல்கள்', 'Automatic reminders for elderly parents')}</p>
        </div>
        <Switch checked={parent.on} onChange={(on) => patch('parent', { on })} label={L('பெற்றோர் நல்வாழ்வு அரண்', 'Parents Care Shield')} />
      </div>

      {parent.on ? (
        <div className="flex flex-col gap-3 p-4">
          {PARENT_SLOTS.map((s) => {
            const entry = todays.find((e) => e.slot === s.slot)
            const due = !entry && now >= s.time
            return (
              <article key={s.slot} className={cn('rounded-xl border-2 p-3', due ? 'border-gold bg-gold/10' : 'border-white/15 bg-secondary')}>
                <div className="flex items-center justify-between gap-2">
                  <span className="rounded-lg bg-background px-2 py-0.5 font-mono text-sm font-black tabular-nums">{to12h(s.time)}</span>
                  <span className="text-xs font-bold text-foreground/70">{L(s.label[0], s.label[1])}</span>
                </div>
                <p className="mt-2 text-sm font-bold leading-relaxed text-pretty">{L(s.msg, s.en)}</p>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    aria-pressed={entry?.took === true}
                    onClick={() => answer(s.slot, true)}
                    className={cn('btn-thick flex items-center justify-center gap-2 rounded-xl py-3 font-black', entry?.took === true ? 'bg-success text-background' : 'bg-background text-success')}
                  >
                    {L('ஆம் 👍', 'Yes 👍')}
                  </button>
                  <button
                    type="button"
                    aria-pressed={entry?.took === false}
                    onClick={() => answer(s.slot, false)}
                    className={cn('btn-thick flex items-center justify-center gap-2 rounded-xl py-3 font-black', entry?.took === false ? 'bg-sos text-foreground' : 'bg-background text-red-400')}
                  >
                    {L('இல்லை 👎', 'No 👎')}
                  </button>
                </div>
              </article>
            )
          })}

          <div className="rounded-xl border-2 border-success/50 bg-success/10 p-3">
            <p className="text-sm font-black text-success">{L('பிள்ளைகளுக்கான அப்டேட் பதிவு', 'Update log for children')}</p>
            {recent.length ? (
              <ul className="mt-2 flex flex-col gap-1.5">
                {recent.map((e) => {
                  const s = PARENT_SLOTS.find((p) => p.slot === e.slot)!
                  return (
                    <li key={e.at} className="flex items-center gap-2 text-xs font-semibold">
                      <Check className="size-4 shrink-0 text-success" aria-hidden />
                      <span className="flex-1">Parent has taken meals & medicines safely · {L(s.label[0], s.label[1])}</span>
                      <time className="font-mono text-foreground/70" dateTime={e.at}>
                        {new Date(e.at).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                      </time>
                    </li>
                  )
                })}
              </ul>
            ) : (
              <p className="mt-1 text-xs text-foreground/70">{L('இன்னும் பதிவுகள் இல்லை.', 'No entries yet.')}</p>
            )}
            <button
              type="button"
              onClick={shareUpdate}
              disabled={!todays.some((e) => e.took)}
              className="btn-thick mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-whatsapp py-3 text-sm font-black text-background disabled:opacity-50"
            >
              <Send className="size-4" aria-hidden />
              {L('வெளிநாட்டில் உள்ள பிள்ளைகளுக்கு வாட்ஸ்அப்பில் அனுப்பு', 'Send to children abroad on WhatsApp')}
            </button>
            <p className="mt-2 text-[11px] leading-relaxed text-foreground/65">
              {L(
                'பதிவுகள் இந்த ஃபோனில் மட்டுமே சேமிக்கப்படும். பிள்ளைகள் பார்க்க, மேலே உள்ள பட்டனை அழுத்தி அனுப்பவும்.',
                'Entries are stored on this phone only. To let children see them, press the button above to send.',
              )}
            </p>
          </div>
        </div>
      ) : null}
    </section>
  )
}

function OptionBlock({
  index,
  icon,
  title,
  on,
  onToggle,
  children,
}: {
  index: number
  icon: React.ReactNode
  title: string
  on: boolean
  onToggle: (v: boolean) => void
  children: React.ReactNode
}) {
  return (
    <section className={cn('rounded-2xl border-2 bg-card transition-colors', on ? 'border-primary' : 'border-white/15')}>
      <div className="flex items-center gap-3 p-4">
        <span
          className={cn(
            'flex size-11 shrink-0 items-center justify-center rounded-xl border-2',
            on ? 'border-primary bg-primary text-primary-foreground' : 'border-white/15 bg-secondary text-primary',
          )}
        >
          {on ? <Check className="size-6" aria-hidden /> : icon}
        </span>
        <h3 className="min-w-0 flex-1 text-base font-black leading-snug text-pretty">
          {index}. {title}
        </h3>
        <Switch checked={on} onChange={onToggle} label={title} />
      </div>
      {on ? <div className="flex flex-col gap-3 border-t-2 border-white/10 p-4 animate-in fade-in slide-in-from-top-1">{children}</div> : null}
    </section>
  )
}

const inputCls = 'w-full rounded-xl border-2 border-white/25 bg-secondary px-3 py-3 text-base font-semibold outline-none focus:border-primary'

function HealthReminders() {
  const { care, patch } = useCare()
  const { L } = useApp()
  const h = care.health
  const [newTime, setNewTime] = useState('13:00')

  return (
    <OptionBlock
      index={1}
      icon={<HeartPulse className="size-5" aria-hidden />}
      title={L('ஆரோக்கியம் சார்ந்த நினைவூட்டல்', 'Health Reminders')}
      on={h.on}
      onToggle={(on) => patch('health', { on })}
    >
      <fieldset>
        <legend className="mb-2 text-sm font-bold">{L('உடல்நிலையைத் தேர்ந்தெடுக்கவும்', 'Choose condition')}</legend>
        <div className="grid grid-cols-3 gap-2">
          {CONDITIONS.map((c) => (
            <button
              key={c.id}
              type="button"
              aria-pressed={h.condition === c.id}
              onClick={() => patch('health', { condition: c.id })}
              className={cn(
                'rounded-xl border-2 px-2 py-3 text-xs font-bold leading-tight',
                h.condition === c.id ? 'border-primary bg-primary/20 text-primary' : 'border-white/15 bg-secondary',
              )}
            >
              {L(c.ta, c.en)}
            </button>
          ))}
        </div>
      </fieldset>
      {h.condition === 'custom' ? (
        <div>
          <label htmlFor="custom-cond" className="text-sm font-bold">
            {L('நோயின் பெயர்', 'Condition name')}
          </label>
          <input
            id="custom-cond"
            value={h.custom}
            maxLength={40}
            placeholder={L('உதா: தைராய்டு', 'e.g. Thyroid')}
            onChange={(e) => patch('health', { custom: e.target.value })}
            className={cn(inputCls, 'mt-1.5')}
          />
        </div>
      ) : null}
      <div>
        <p className="mb-2 text-sm font-bold">{L('மாத்திரை நேரங்கள்', 'Medicine times')}</p>
        <ul className="flex flex-wrap gap-2">
          {h.times.map((t) => (
            <li key={t} className="flex items-center gap-1 rounded-full border-2 border-primary/60 bg-primary/15 py-1 pl-3 pr-1 font-mono text-sm font-bold text-primary">
              <Pill className="size-3.5" aria-hidden />
              {t}
              <button
                type="button"
                aria-label={L(`${t} நீக்கு`, `Remove ${t}`)}
                onClick={() => patch('health', { times: h.times.filter((x) => x !== t) })}
                className="rounded-full p-1 hover:bg-primary/30"
              >
                <X className="size-3.5" aria-hidden />
              </button>
            </li>
          ))}
        </ul>
        <div className="mt-2 flex gap-2">
          <input type="time" value={newTime} onChange={(e) => setNewTime(e.target.value)} aria-label={L('புதிய நேரம்', 'New time')} className={cn(inputCls, 'flex-1')} />
          <button
            type="button"
            onClick={() => newTime && !h.times.includes(newTime) && patch('health', { times: [...h.times, newTime].sort() })}
            className="btn-thick flex items-center gap-1 rounded-xl bg-primary px-4 font-black text-primary-foreground"
          >
            <Plus className="size-4" aria-hidden />
            {L('சேர்', 'Add')}
          </button>
        </div>
      </div>
    </OptionBlock>
  )
}

function WorkReminders() {
  const { care, patch } = useCare()
  const { L, showToast } = useApp()
  const w = care.work
  const [title, setTitle] = useState('')
  const [time, setTime] = useState('10:00')

  const add = (e: React.FormEvent) => {
    e.preventDefault()
    if (!title.trim()) return showToast(L('வேலையின் பெயரை உள்ளிடவும்', 'Enter a task name'))
    patch('work', { tasks: [...w.tasks, { title: title.trim().slice(0, 60), time }].sort((a, b) => a.time.localeCompare(b.time)) })
    setTitle('')
    showToast(L('வேலை நினைவூட்டல் சேமிக்கப்பட்டது', 'Work reminder saved'))
  }

  return (
    <OptionBlock
      index={2}
      icon={<Briefcase className="size-5" aria-hidden />}
      title={L('வேலை சார்ந்த நினைவூட்டல்', 'Work Reminders')}
      on={w.on}
      onToggle={(on) => patch('work', { on })}
    >
      <form onSubmit={add} className="flex flex-col gap-2">
        <label htmlFor="task-title" className="text-sm font-bold">
          {L('தினசரி வேலை', 'Daily task')}
        </label>
        <input id="task-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder={L('உதா: வங்கிக்குச் செல்லுதல்', 'e.g. Visit the bank')} className={inputCls} />
        <div className="flex gap-2">
          <input type="time" value={time} onChange={(e) => setTime(e.target.value)} aria-label={L('அறிவிப்பு நேரம்', 'Alert time')} className={cn(inputCls, 'flex-1')} />
          <button type="submit" className="btn-thick flex items-center gap-1 rounded-xl bg-primary px-4 font-black text-primary-foreground">
            <Plus className="size-4" aria-hidden />
            {L('சேமி', 'Save')}
          </button>
        </div>
      </form>
      {w.tasks.length ? (
        <ul className="flex flex-col gap-2">
          {w.tasks.map((t, i) => (
            <li key={`${t.title}-${i}`} className="flex items-center gap-3 rounded-xl border-2 border-white/15 bg-secondary p-3">
              <span className="font-mono text-sm font-black text-primary">{t.time}</span>
              <span className="min-w-0 flex-1 truncate font-bold">{t.title}</span>
              <button
                type="button"
                aria-label={L('நீக்கு', 'Delete')}
                onClick={() => patch('work', { tasks: w.tasks.filter((_, idx) => idx !== i) })}
                className="rounded-lg p-1.5 hover:bg-white/10"
              >
                <Trash2 className="size-4" aria-hidden />
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-sm text-foreground/70">{L('இன்னும் வேலைகள் சேர்க்கப்படவில்லை.', 'No tasks added yet.')}</p>
      )}
    </OptionBlock>
  )
}

function ChildAlert() {
  const { care, patch } = useCare()
  const { L, showToast } = useApp()
  const c = care.child
  const home = c.arrivedOn === today()

  return (
    <OptionBlock
      index={3}
      icon={<Baby className="size-5" aria-hidden />}
      title={L('பிள்ளைகள் கண்காணிப்பு நேர அலர்ட்', 'Child Arrival Alert')}
      on={c.on}
      onToggle={(on) => patch('child', { on })}
    >
      <div className="grid grid-cols-2 gap-2">
        <div>
          <label htmlFor="child-name" className="text-sm font-bold">
            {L('பிள்ளையின் பெயர்', "Child's name")}
          </label>
          <input id="child-name" value={c.name} maxLength={24} onChange={(e) => patch('child', { name: e.target.value })} className={cn(inputCls, 'mt-1.5')} />
        </div>
        <div>
          <label htmlFor="child-time" className="text-sm font-bold">
            {L('வீடு வரும் நேரம்', 'Arrival time')}
          </label>
          <input id="child-time" type="time" value={c.arrival} onChange={(e) => patch('child', { arrival: e.target.value })} className={cn(inputCls, 'mt-1.5')} />
        </div>
      </div>
      <p className="text-xs leading-relaxed text-foreground/80">
        {L(
          `பள்ளி / கல்லூரி முடிந்து ${c.arrival} மணிக்குள் வீடு திரும்பவில்லை என்றால், நண்பேன்டா தமிழில் குரல் எச்சரிக்கை தரும்.`,
          `If they are not home by ${c.arrival}, Nanbanda will give you a Tamil voice alert.`,
        )}
      </p>
      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => {
            patch('child', { arrivedOn: home ? null : today() })
            if (!home) showToast(L(`${c.name} வீடு வந்துவிட்டார்`, `${c.name} reached home`))
          }}
          className={cn(
            'btn-thick flex items-center justify-center gap-1.5 rounded-xl py-3 text-sm font-black',
            home ? 'bg-success text-background' : 'bg-secondary text-foreground',
          )}
        >
          <Home className="size-4" aria-hidden />
          {home ? L('வீடு வந்தாச்சு ✓', 'Home ✓') : L('வீடு வந்தாச்சு', 'Mark home')}
        </button>
        <button type="button" onClick={() => previewCareAlert('child')} className="btn-thick flex items-center justify-center gap-1.5 rounded-xl bg-primary py-3 text-sm font-black text-primary-foreground">
          <BellRing className="size-4" aria-hidden />
          {L('அலர்ட் சோதனை', 'Test alert')}
        </button>
      </div>
    </OptionBlock>
  )
}

function NightCheckIn() {
  const { care, patch } = useCare()
  const { L, showToast } = useApp()
  const todays = care.checkins.find((c) => c.date === today())
  const isNight = new Date().getHours() >= 19

  const answer = (took: boolean) => {
    patch('checkins', [{ date: today(), took }, ...care.checkins.filter((c) => c.date !== today())].slice(0, 30))
    showToast(took ? L('அருமை நண்பா! ஆரோக்கியமாக இருங்கள்', 'Great, friend! Stay healthy') : L('பரவாயில்லை, இப்போதே சாப்பிடுங்கள் நண்பா', 'No worries, please take them now'))
  }

  const last7 = Array.from({ length: 7 }, (_, i) => {
    const d = new Date()
    d.setDate(d.getDate() - (6 - i))
    const key = d.toLocaleDateString('en-CA')
    return { key, day: d.toLocaleDateString('ta-IN', { weekday: 'narrow' }), entry: care.checkins.find((c) => c.date === key) }
  })

  return (
    <section className={cn('rounded-2xl border-2 p-4', isNight && !todays ? 'border-gold bg-gold/10' : 'border-white/15 bg-card')} aria-labelledby="night-title">
      <h2 id="night-title" className="flex items-center gap-2 text-base font-black text-gold">
        <Moon className="size-5" aria-hidden />
        {L('இரவு நலம் விசாரிப்பு', 'Nightly Check-in')}
      </h2>
      <p className="mt-2 text-base font-bold leading-relaxed text-pretty">
        {L('நண்பா, இன்று உங்களது மாத்திரைகளைச் சரியாகச் சாப்பிட்டுவிட்டீர்களா?', 'Friend, did you take your medicines properly today?')}
      </p>
      <div className="mt-3 grid grid-cols-2 gap-3">
        <button
          type="button"
          aria-pressed={todays?.took === true}
          onClick={() => answer(true)}
          className={cn('btn-thick flex items-center justify-center gap-2 rounded-xl py-3.5 font-black', todays?.took === true ? 'bg-success text-background' : 'bg-secondary text-success')}
        >
          <ThumbsUp className="size-5" aria-hidden /> {L('ஆம்', 'Yes')}
        </button>
        <button
          type="button"
          aria-pressed={todays?.took === false}
          onClick={() => answer(false)}
          className={cn('btn-thick flex items-center justify-center gap-2 rounded-xl py-3.5 font-black', todays?.took === false ? 'bg-sos text-foreground' : 'bg-secondary text-red-400')}
        >
          <ThumbsDown className="size-5" aria-hidden /> {L('இல்லை', 'No')}
        </button>
      </div>
      <ol className="mt-4 grid grid-cols-7 gap-1.5" aria-label={L('கடந்த 7 நாட்கள்', 'Last 7 days')}>
        {last7.map(({ key, day, entry }) => (
          <li key={key} className="flex flex-col items-center gap-1 text-[11px] font-bold text-foreground/70">
            <span
              className={cn(
                'flex size-8 items-center justify-center rounded-lg border-2',
                entry?.took ? 'border-success bg-success/25 text-success' : entry ? 'border-sos bg-sos/25 text-red-300' : 'border-white/15',
              )}
            >
              {entry?.took ? <Check className="size-4" aria-label={L('சாப்பிட்டது', 'Taken')} /> : entry ? <X className="size-4" aria-label={L('தவறியது', 'Missed')} /> : null}
            </span>
            {day}
          </li>
        ))}
      </ol>
    </section>
  )
}

function MorningAlarm() {
  const { care, patch } = useCare()
  const { L } = useApp()
  const m = care.morning
  return (
    <Panel>
      <SectionTitle icon={<AlarmClock className="size-5 text-primary" aria-hidden />} hint={m.on ? m.time : L('அணைப்பு', 'Off')}>
        {L('காலை அலாரம்', 'Morning Alarm')}
      </SectionTitle>
      <div className="flex items-center gap-3">
        <input
          type="time"
          value={m.time}
          onChange={(e) => patch('morning', { time: e.target.value })}
          aria-label={L('அலாரம் நேரம்', 'Alarm time')}
          className={cn(inputCls, 'flex-1 font-mono text-2xl font-black')}
        />
        <Switch checked={m.on} onChange={(on) => patch('morning', { on })} label={L('காலை அலாரம்', 'Morning alarm')} />
      </div>
      <blockquote className="mt-3 rounded-xl border-2 border-primary/40 bg-secondary p-3 text-sm font-medium leading-relaxed">{MORNING_MSG}</blockquote>
      <button type="button" onClick={() => previewCareAlert('morning')} className="btn-thick mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3.5 font-black text-primary-foreground">
        <Volume2 className="size-5" aria-hidden />
        {L('குரல் அலாரத்தைக் கேள்', 'Preview voice alarm')}
      </button>
    </Panel>
  )
}

export function CareWatcher() {
  const { care, L, showToast, hydrated } = useApp()
  const [alert, setAlert] = useState<AlertKind | null>(null)
  const fired = useRef(new Set<string>())

  useEffect(() => {
    const onPreview = (e: Event) => setAlert((e as CustomEvent<AlertKind>).detail)
    window.addEventListener(ALERT_EVENT, onPreview)
    return () => window.removeEventListener(ALERT_EVENT, onPreview)
  }, [])

  useEffect(() => {
    if (!hydrated) return
    const once = (key: string, fn: () => void) => {
      const k = `${today()}:${key}`
      if (fired.current.has(k)) return
      fired.current.add(k)
      fn()
    }
    const tick = () => {
      const now = nowHHMM()
      if (care.morning.on && now === care.morning.time) once('morning', () => setAlert('morning'))
      if (care.parent?.on) {
        for (const s of PARENT_SLOTS) {
          if (now === s.time)
            once(`parent-${s.slot}`, () => {
              chime()
              setTimeout(() => speak(s.msg), 900)
              showToast(L(s.msg, s.en))
            })
        }
      }
      if (!care.enabled) return
      if (care.child.on && now >= care.child.arrival && care.child.arrivedOn !== today()) once('child', () => setAlert('child'))
      if (care.health.on) {
        for (const t of care.health.times) {
          if (now === t)
            once(`health-${t}`, () => {
              chime()
              const label = care.health.condition === 'bp' ? 'பிபி' : care.health.condition === 'sugar' ? 'சுகர்' : care.health.custom || ''
              showToast(L(`நண்பா, ${label} மாத்திரை நேரம்!`, `Friend, time for your ${label} medicine!`))
            })
        }
      }
      if (care.work.on) {
        for (const t of care.work.tasks) {
          if (now === t.time) once(`work-${t.title}-${t.time}`, () => {
            chime()
            showToast(L(`நினைவூட்டல்: ${t.title}`, `Reminder: ${t.title}`))
          })
        }
      }
    }
    tick()
    const id = setInterval(tick, 15000)
    return () => clearInterval(id)
  }, [care, hydrated, L, showToast])

  useEffect(() => {
    if (!alert) return
    chime()
    const id = setTimeout(() => speak(alert === 'child' ? CHILD_MSG : MORNING_MSG), 900)
    return () => {
      clearTimeout(id)
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) window.speechSynthesis.cancel()
    }
  }, [alert])

  if (!alert) return null
  return alert === 'child' ? <ChildAlertCard onClose={() => setAlert(null)} /> : <MorningCard onClose={() => setAlert(null)} />
}

function VoiceCard({ tone, icon, title, message, onClose, children }: { tone: 'primary' | 'gold'; icon: React.ReactNode; title: string; message: string; onClose: () => void; children?: React.ReactNode }) {
  const { L } = useApp()
  return (
    <div role="alertdialog" aria-modal="true" aria-labelledby="voice-card-title" className="absolute inset-0 z-50 flex items-end bg-black/75 p-3 animate-in fade-in">
      <div className={cn('w-full rounded-3xl border-2 bg-card p-5 animate-in slide-in-from-bottom duration-300', tone === 'primary' ? 'border-primary' : 'border-gold')}>
        <div className="flex items-center gap-3">
          <span className={cn('flex size-14 shrink-0 items-center justify-center rounded-2xl', tone === 'primary' ? 'bg-primary text-primary-foreground' : 'bg-gold text-background')}>{icon}</span>
          <div className="min-w-0 flex-1">
            <h2 id="voice-card-title" className="text-lg font-black leading-tight">{title}</h2>
            <p className="mt-1 flex items-end gap-0.5" aria-hidden>
              {[0, 1, 2, 3, 4, 5, 6].map((i) => (
                <span key={i} className={cn('wave-bar inline-block h-4 w-1 rounded-full', tone === 'primary' ? 'bg-primary' : 'bg-gold')} style={{ animationDelay: `${i * 0.1}s` }} />
              ))}
              <span className="ml-2 text-xs font-bold text-foreground/70">{L('நண்பேன்டா பேசுகிறது…', 'Nanbanda speaking…')}</span>
            </p>
          </div>
          <button type="button" onClick={onClose} aria-label={L('மூடு', 'Close')} className="rounded-full bg-secondary p-2">
            <X className="size-5" aria-hidden />
          </button>
        </div>
        <p className="mt-4 text-lg font-bold leading-relaxed text-pretty">{message}</p>
        <div className="mt-4 flex flex-col gap-2">{children}</div>
      </div>
    </div>
  )
}

function ChildAlertCard({ onClose }: { onClose: () => void }) {
  const { care, contacts, L, update } = useApp()
  const [state, setState] = useState<'idle' | 'checking' | 'error' | { lat: number; lng: number }>('idle')
  const name = care.child.name || L('மகள்', 'Daughter')

  const check = async () => {
    setState('checking')
    const [pos] = await Promise.all([getPosition(), new Promise((r) => setTimeout(r, 1800))])
    setState(pos ? { lat: pos.lat + 0.0062, lng: pos.lng - 0.0041 } : 'error')
  }
  const phone = contacts.find((c) => c.phone)?.phone

  return (
    <VoiceCard tone="primary" icon={<Baby className="size-7" aria-hidden />} title={L('பிள்ளைகள் வருகை அலர்ட்', 'Child Arrival Alert')} message={CHILD_MSG} onClose={onClose}>
      {typeof state === 'object' ? (
        <div className="rounded-xl border-2 border-success bg-success/10 p-3">
          <p className="flex items-center gap-2 font-black text-success">
            <MapPin className="size-5" aria-hidden />
            {L(`${name} பாதுகாப்பாக உள்ளார் — வீட்டிலிருந்து 0.9 கி.மீ`, `${name} is safe — 0.9 km from home`)}
          </p>
          <p className="mt-1 font-mono text-xs">
            {state.lat.toFixed(5)}, {state.lng.toFixed(5)}
          </p>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <a
              href={`https://maps.google.com/?q=${state.lat},${state.lng}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-thick flex items-center justify-center gap-1.5 rounded-lg bg-primary py-2.5 text-sm font-black text-primary-foreground"
            >
              <MapPin className="size-4" aria-hidden /> {L('மேப்பில் பார்', 'Open map')}
            </a>
            <a href={phone ? `tel:${phone}` : 'tel:'} className="btn-thick flex items-center justify-center gap-1.5 rounded-lg bg-secondary py-2.5 text-sm font-black">
              <Phone className="size-4" aria-hidden /> {L('அழை', 'Call')}
            </a>
          </div>
        </div>
      ) : state === 'error' ? (
        <GpsErrorAlert onRetry={check} />
      ) : (
        <button
          type="button"
          onClick={check}
          disabled={state === 'checking'}
          className="btn-thick flex items-center justify-center gap-2 rounded-2xl bg-success py-4 text-lg font-black text-background disabled:opacity-70"
        >
          {state === 'checking' ? <Loader2 className="size-5 animate-spin" aria-hidden /> : <MapPin className="size-5" aria-hidden />}
          {state === 'checking' ? L('சரிபார்க்கப்படுகிறது…', 'Checking…') : L('மகளின் லொகேஷனைச் சரிபார்', "Check daughter's location")}
        </button>
      )}
      <button
        type="button"
        onClick={() => {
          update({ care: { ...care, child: { ...care.child, arrivedOn: today() } } })
          onClose()
        }}
        className="rounded-2xl border-2 border-white/20 py-3 text-sm font-bold"
      >
        {L('வீடு வந்துவிட்டார்', 'Already home')}
      </button>
    </VoiceCard>
  )
}

function MorningCard({ onClose }: { onClose: () => void }) {
  const { L } = useApp()
  return (
    <VoiceCard tone="gold" icon={<AlarmClock className="size-7" aria-hidden />} title={L('காலை வணக்கம் நண்பா!', 'Good morning, friend!')} message={MORNING_MSG} onClose={onClose}>
      <button type="button" onClick={onClose} className="btn-thick flex items-center justify-center gap-2 rounded-2xl bg-gold py-4 text-lg font-black text-background">
        <Pill className="size-5" aria-hidden /> {L('மாத்திரை போட்டுவிட்டேன்', 'I took my medicine')}
      </button>
      <button type="button" onClick={onClose} className="flex items-center justify-center gap-1 rounded-2xl border-2 border-white/20 py-3 text-sm font-bold">
        <ChevronDown className="size-4" aria-hidden /> {L('பின்னர் நினைவூட்டு', 'Remind later')}
      </button>
    </VoiceCard>
  )
}
