'use client'

import { useState } from 'react'
import { BadgeCheck, Bike, Car, Crown, FilePlus2, HeartPulse, Loader2, Send, ShieldCheck, Zap } from 'lucide-react'
import { useApp } from '@/lib/store'
import { Panel, Sheet } from './primitives'
import { CheckoutSheet } from './checkout-sheet'

const POLICIES = [
  {
    id: 'health',
    ta: 'மருத்துவ & விபத்துக் காப்பீடு',
    en: 'Health & Accident',
    insurer: 'Star Health Assure',
    number: 'SHA/26/4471-0093',
    cover: '₹10,00,000',
    expiry: '2027-03-14',
    icon: HeartPulse,
  },
  {
    id: 'vehicle',
    ta: 'வாகனக் காப்பீடு · TN 09 BX 4421',
    en: 'Vehicle · TN 09 BX 4421',
    insurer: 'ICICI Lombard Motor',
    number: 'ICL/MTR/26/88120',
    cover: 'IDV ₹6,40,000',
    expiry: '2026-11-02',
    icon: Car,
  },
] as const

type Policy = (typeof POLICIES)[number]

function daysLeft(date: string) {
  return Math.ceil((new Date(date).getTime() - Date.now()) / 86400000)
}

export function WalletTab() {
  const { premium, L } = useApp()
  const [claimFor, setClaimFor] = useState<Policy | null>(null)
  const [checkout, setCheckout] = useState<null | 'pay' | 'waiver'>(null)

  return (
    <div className="flex flex-col gap-4">
      <section aria-labelledby="vault-title">
        <h2 id="vault-title" className="mb-3 text-base font-bold text-gold">
          {L('டிஜிட்டல் பாலிசி பெட்டகம்', 'Digital Insurance Wallet')}
        </h2>
        <div className="flex flex-col gap-3">
          {POLICIES.map((p) => {
            const d = daysLeft(p.expiry)
            const Icon = p.icon
            return (
              <article key={p.id} className="rounded-2xl border-2 border-white/20 bg-card p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span className="flex size-11 items-center justify-center rounded-xl border-2 border-primary/50 bg-primary/15">
                      <Icon className="size-5 text-primary" aria-hidden />
                    </span>
                    <div>
                      <p className="font-bold leading-snug">{L(p.ta, p.en)}</p>
                      <p className="text-xs text-foreground/75">{p.insurer}</p>
                    </div>
                  </div>
                  <span className={`shrink-0 rounded-full px-2 py-0.5 text-[11px] font-bold ${d < 45 ? 'bg-primary/20 text-primary' : 'bg-success/15 text-success'}`}>
                    {d < 45 ? L(`${d} நாளில் புதுப்பி`, `Renew in ${d}d`) : L('செயலில்', 'Active')}
                  </span>
                </div>
                <dl className="mt-4 grid grid-cols-3 gap-2 text-xs">
                  <div>
                    <dt className="text-foreground/70">{L('பாலிசி எண்', 'Policy no.')}</dt>
                    <dd className="mt-0.5 break-all font-mono text-[11px] font-bold">{p.number}</dd>
                  </div>
                  <div>
                    <dt className="text-foreground/70">{L('காப்பீட்டுத் தொகை', 'Cover')}</dt>
                    <dd className="mt-0.5 font-bold">{p.cover}</dd>
                  </div>
                  <div>
                    <dt className="text-foreground/70">{L('காலாவதி', 'Expiry')}</dt>
                    <dd className="mt-0.5 font-bold">
                      {new Date(p.expiry).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                    </dd>
                  </div>
                </dl>
              </article>
            )
          })}
        </div>
      </section>

      <BuyPolicy onBought={() => setCheckout('waiver')} />

      <section className="rounded-2xl border-2 border-neon bg-neon/10 p-4" aria-labelledby="why-title">
        <h2 id="why-title" className="flex items-center gap-2 text-base font-black text-neon">
          <ShieldCheck className="size-5" aria-hidden />
          {L('நண்பேன்டா இன்சூரன்ஸ் மாபெரும் நன்மை', 'The big Nanbanda insurance advantage')}
        </h2>
        <p className="mt-2 text-sm font-medium leading-relaxed text-pretty">
          {L(
            'எங்களிடம் இன்சூரன்ஸ் எடுப்பதன் மூலம், விபத்து அவசர காலத்தில் உங்கள் போன் எடுக்கப்போகும் லைவ் வீடியோ, மைக்ரோஃபோன் ஆடியோ பதிவுகள் மற்றும் விபத்தின் தாக்க அளவீடுகள் அனைத்தும் இன்சூரன்ஸ் நிறுவனத்திற்குச் சென்றுவிடும்! இதனால் எந்தவொரு ஆதாரக் குழப்பமும் இன்றி, 24 மணிநேரத்திற்குள் உங்கள் கேஷ்லெஸ் க்ளைம் (Cashless Claim) உடனடியாகப் பாஸ் ஆகிவிடும்!',
            'When you insure with us, the live video, microphone audio and crash impact metrics your phone captures during an accident go straight to the insurer! With no evidence disputes, your cashless claim gets approved within 24 hours!',
          )}
        </p>
        <button
          type="button"
          onClick={() => setClaimFor(POLICIES[1])}
          className="btn-thick mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-4 font-black text-primary-foreground"
        >
          <Zap className="size-5" aria-hidden />
          {L('உடனடி இன்சூரன்ஸ் க்ளைம் உதவி', 'Instant Insurance Claim Help')}
        </button>
      </section>

      <section className="relative overflow-hidden rounded-2xl border-2 border-gold bg-gold/10 p-5 shadow-[0_0_40px_-10px] shadow-gold/70" aria-labelledby="savings-title">
        <div className="premium-sheen pointer-events-none absolute inset-0" aria-hidden />
        <div className="relative">
          <h2 id="savings-title" className="flex items-center gap-2 text-base font-black text-gold">
            <Crown className="size-5" aria-hidden />
            {L('நண்பேன்டா மாபெரும் சேமிப்புத் திட்டம்', 'Nanbanda Super Savings Plan')}
          </h2>
          {premium ? (
            <p className="mt-3 flex items-center gap-2 text-lg font-black text-success">
              <BadgeCheck className="size-6" aria-hidden />
              {L('பிரீமியம் பிளான் செயலில் உள்ளது', 'Premium plan active')}
            </p>
          ) : (
            <p className="mt-2 flex items-baseline gap-1">
              <span className="text-5xl font-black text-gold">₹49</span>
              <span className="text-sm font-bold">/ {L('மாதம்', 'month')}</span>
            </p>
          )}
          <p className="mt-3 text-sm font-medium leading-relaxed text-pretty">
            {L(
              'மாதம் வெறும் ₹49 பிரீமியம் பிளான்! ஆனால், உங்களது வாகன அல்லது மருத்துவ இன்சூரன்ஸை நண்பேன்டா ஆப் மூலமாகவே இந்த மாதம் புதுப்பித்தால் அல்லது எடுத்தால், இந்தக் குறிப்பிட்ட மாதத்திற்கான ₹49 சப்ஸ்கிரிப்ஷன் கட்டணம் 100% முற்றிலும் இலவசம் (Current Month Subscription Fee Waived Off)!',
              'Premium plan for just ₹49/month! But if you renew or buy your vehicle or health insurance through Nanbanda this month, that month’s ₹49 subscription fee is 100% free (Current Month Subscription Fee Waived Off)!',
            )}
          </p>
          {!premium ? (
            <div className="mt-4 flex flex-col gap-2">
              <button type="button" onClick={() => setCheckout('pay')} className="btn-thick w-full rounded-xl bg-gold py-4 font-black text-background">
                {L('₹49 செலுத்தி பிரீமியம் பெறுக', 'Pay ₹49 for Premium')}
              </button>
              <button type="button" onClick={() => setCheckout('waiver')} className="btn-thick w-full rounded-xl border-2 border-success bg-success/15 py-3.5 font-bold text-success">
                {L('பாலிசி இணைத்து இலவசமாகப் பெறுக', 'Link policy & get it free')}
              </button>
            </div>
          ) : null}
        </div>
      </section>

      {claimFor ? <ClaimSheet policy={claimFor} onClose={() => setClaimFor(null)} /> : null}
      {checkout ? <CheckoutSheet mode={checkout} onClose={() => setCheckout(null)} /> : null}
    </div>
  )
}

const PLAN_TYPES = [
  { id: 'bike', icon: Bike, ta: 'பைக்', en: 'Bike', price: 1249 },
  { id: 'car', icon: Car, ta: 'கார்', en: 'Car', price: 4899 },
  { id: 'health', icon: HeartPulse, ta: 'மருத்துவம் / விபத்து', en: 'Health / Accident', price: 6999 },
] as const

function BuyPolicy({ onBought }: { onBought: () => void }) {
  const { L, premium, showToast } = useApp()
  const [type, setType] = useState<(typeof PLAN_TYPES)[number]['id']>('bike')
  const [name, setName] = useState('')
  const [detail, setDetail] = useState('')
  const [busy, setBusy] = useState(false)
  const plan = PLAN_TYPES.find((p) => p.id === type)!
  const isVehicle = type !== 'health'

  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim() || !detail.trim()) return showToast(L('அனைத்து விவரங்களையும் நிரப்பவும்', 'Please fill in all details'))
    setBusy(true)
    setTimeout(() => {
      setBusy(false)
      setName('')
      setDetail('')
      showToast(L(`${plan.ta} பாலிசி பதிவு செய்யப்பட்டது!`, `${plan.en} policy registered!`))
      if (!premium) onBought()
    }, 1400)
  }

  return (
    <Panel>
      <h2 className="mb-3 flex items-center gap-2 text-base font-black text-primary">
        <FilePlus2 className="size-5" aria-hidden />
        {L('புதிய பாலிசி வாங்குக', 'Buy New Policy')}
      </h2>
      <form onSubmit={submit} className="flex flex-col gap-3">
        <fieldset className="grid grid-cols-3 gap-2">
          <legend className="sr-only">{L('பாலிசி வகை', 'Policy type')}</legend>
          {PLAN_TYPES.map((p) => {
            const Icon = p.icon
            const active = p.id === type
            return (
              <button
                key={p.id}
                type="button"
                aria-pressed={active}
                onClick={() => setType(p.id)}
                className={`flex flex-col items-center gap-1 rounded-xl border-2 px-1 py-3 text-xs font-black leading-tight ${
                  active ? 'border-primary bg-primary text-primary-foreground' : 'border-white/15 bg-secondary'
                }`}
              >
                <Icon className="size-5" aria-hidden />
                {L(p.ta, p.en)}
              </button>
            )
          })}
        </fieldset>
        <label className="flex flex-col gap-1 text-sm font-bold">
          {L('உரிமையாளர் பெயர்', 'Owner name')}
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            autoComplete="name"
            className="rounded-xl border-2 border-white/20 bg-secondary px-3 py-3 text-base font-medium outline-none focus:border-primary"
          />
        </label>
        <label className="flex flex-col gap-1 text-sm font-bold">
          {isVehicle ? L('வாகன எண்', 'Vehicle number') : L('வயது', 'Age')}
          <input
            value={detail}
            onChange={(e) => setDetail(isVehicle ? e.target.value.toUpperCase() : e.target.value.replace(/\D/g, '').slice(0, 3))}
            inputMode={isVehicle ? 'text' : 'numeric'}
            placeholder={isVehicle ? 'TN 09 AB 1234' : '35'}
            className="rounded-xl border-2 border-white/20 bg-secondary px-3 py-3 font-mono text-base outline-none focus:border-primary"
          />
        </label>
        <p className="flex items-baseline justify-between rounded-xl bg-secondary px-3 py-2.5 text-sm">
          <span className="font-bold">{L('ஆண்டு பிரீமியம்', 'Yearly premium')}</span>
          <span className="text-xl font-black text-gold">₹{plan.price.toLocaleString('en-IN')}</span>
        </p>
        <button
          type="submit"
          disabled={busy}
          className="btn-thick flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-4 font-black text-primary-foreground disabled:opacity-60"
        >
          {busy ? <Loader2 className="size-5 animate-spin" aria-hidden /> : <ShieldCheck className="size-5" aria-hidden />}
          {busy ? L('பதிவு செய்யப்படுகிறது…', 'Registering…') : L('பாலிசி பதிவு செய்', 'Register policy')}
        </button>
      </form>
    </Panel>
  )
}

function ClaimSheet({ policy, onClose }: { policy: Policy; onClose: () => void }) {
  const { userName, gpsLog, showToast, L } = useApp()
  const last = gpsLog[0]
  const metrics = [
    [L('பாலிசி', 'Policy'), `${policy.number}`],
    [L('காப்பீட்டாளர்', 'Insured'), userName],
    [L('சம்பவ நேரம்', 'Incident time'), new Date(last?.at ?? Date.now()).toLocaleString('en-IN')],
    [L('இருப்பி��ம்', 'Location'), last ? `${last.lat.toFixed(5)}, ${last.lng.toFixed(5)}` : L('GPS கிடைக்கவில்லை', 'GPS unavailable')],
    [L('அதிகபட்ச தாக்கம்', 'Peak impact'), '6.8 g'],
    [L('மோதலுக்கு முந்தைய வேகம்', 'Pre-impact speed'), '42 km/h'],
    [L('ஆதாரங்கள்', 'Evidence'), L('லைவ் வீடியோ + குரல் பதிவு', 'Live video + voice')],
  ]
  const report = ['NANBANDA CASHLESS CLAIM', ...metrics.map(([k, v]) => `${k}: ${v}`)].join('\n')

  const send = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ title: 'Claim', text: report })
        return
      } catch {}
    }
    await navigator.clipboard?.writeText(report)
    showToast(L('க்ளைம் விவரம் நகலெடுக்கப்பட்டது', 'Claim summary copied'))
  }

  return (
    <Sheet title={L('உடனடி க்ளைம் டாஷ்போர்டு', 'Instant Claim Dashboard')} onClose={onClose}>
      <p className="text-sm text-foreground/85">{L('விபத்து அளவீடுகள் கேஷ்லெஸ் க்ளைமுக்குத் தயார்.', 'Crash metrics ready for cashless clearance.')}</p>
      <dl className="mt-3 flex flex-col divide-y divide-white/10 rounded-xl border-2 border-white/15 bg-secondary">
        {metrics.map(([k, v]) => (
          <div key={k} className="flex justify-between gap-3 px-3 py-2 text-sm">
            <dt className="text-foreground/75">{k}</dt>
            <dd className="text-right font-bold">{v}</dd>
          </div>
        ))}
      </dl>
      <button type="button" onClick={send} className="btn-thick mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3.5 font-black text-primary-foreground">
        <Send className="size-4" aria-hidden /> {L('இன்சூரன்ஸ் நிறுவனத்திற்கு அனுப்பு', 'Send to insurer')}
      </button>
    </Sheet>
  )
}
