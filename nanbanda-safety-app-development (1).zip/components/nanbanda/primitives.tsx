'use client'

import { MapPinOff, X } from 'lucide-react'
import { GPS_ERROR_EN, GPS_ERROR_TA, useApp } from '@/lib/store'
import { cn } from '@/lib/utils'

export function GpsErrorAlert({ onRetry, className }: { onRetry?: () => void; className?: string }) {
  const { L } = useApp()
  return (
    <div role="alert" className={cn('flex items-start gap-3 rounded-2xl border-2 border-sos bg-sos/15 p-3.5', className)}>
      <MapPinOff className="mt-0.5 size-6 shrink-0 text-sos" aria-hidden />
      <div className="min-w-0 flex-1">
        <p className="text-sm font-black leading-snug text-sos text-pretty">{L(GPS_ERROR_TA, GPS_ERROR_EN)}</p>
        {onRetry ? (
          <button type="button" onClick={onRetry} className="mt-2 rounded-lg border-2 border-sos px-3 py-1.5 text-xs font-bold text-sos">
            {L('மீண்டும் முயற்சி', 'Try again')}
          </button>
        ) : null}
      </div>
    </div>
  )
}

export function Sheet({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  const { L } = useApp()
  return (
    <div className="absolute inset-0 z-50 flex items-end bg-black/70 animate-in fade-in" role="dialog" aria-modal="true" aria-label={title}>
      <button type="button" aria-label={L('மூடு', 'Close')} className="absolute inset-0 cursor-default" onClick={onClose} tabIndex={-1} />
      <div className="relative max-h-[92%] w-full overflow-y-auto rounded-t-3xl border-t-2 border-white/20 bg-card p-5 animate-in slide-in-from-bottom duration-300">
        <div className="mx-auto mb-3 h-1.5 w-12 rounded-full bg-white/30" aria-hidden />
        <div className="flex items-center justify-between gap-3">
          <h3 className="text-lg font-bold text-gold">{title}</h3>
          <button type="button" onClick={onClose} aria-label={L('மூடு', 'Close')} className="rounded-full bg-secondary p-2 hover:bg-accent">
            <X className="size-5" aria-hidden />
          </button>
        </div>
        <div className="mt-3">{children}</div>
      </div>
    </div>
  )
}

export function Panel({ className, ...props }: React.HTMLAttributes<HTMLElement>) {
  return <section className={cn('rounded-2xl border-2 border-white/15 bg-card p-4', className)} {...props} />
}

export function SectionTitle({ children, hint, icon }: { children: React.ReactNode; hint?: React.ReactNode; icon?: React.ReactNode }) {
  return (
    <div className="mb-3 flex items-start justify-between gap-2">
      <h2 className="flex items-center gap-2 text-base font-bold leading-snug text-gold text-balance">
        {icon}
        {children}
      </h2>
      {hint ? <span className="shrink-0 rounded-full bg-secondary px-2 py-0.5 text-[11px] font-semibold text-foreground">{hint}</span> : null}
    </div>
  )
}

export function Switch({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={cn(
        'relative inline-flex h-7 w-12 shrink-0 items-center rounded-full border-2 transition-colors',
        checked ? 'border-primary bg-primary' : 'border-white/25 bg-white/10',
      )}
    >
      <span className={cn('inline-block size-5 rounded-full bg-white shadow transition-transform', checked ? 'translate-x-5.5' : 'translate-x-0.5')} />
    </button>
  )
}

export function ToggleRow({
  icon,
  title,
  desc,
  checked,
  onChange,
}: {
  icon: React.ReactNode
  title: string
  desc?: string
  checked: boolean
  onChange: (v: boolean) => void
}) {
  return (
    <div className="flex items-center gap-3 py-3">
      <span className="flex size-10 shrink-0 items-center justify-center rounded-xl border-2 border-white/15 bg-secondary text-primary">{icon}</span>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-bold">{title}</p>
        {desc ? <p className="text-xs leading-relaxed text-muted-foreground">{desc}</p> : null}
      </div>
      <Switch checked={checked} onChange={onChange} label={title} />
    </div>
  )
}
