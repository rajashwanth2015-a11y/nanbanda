'use client'

import { useState } from 'react'
import { Ambulance, Car, ChevronRight, MessageCircle, Mic, PersonStanding, PhoneIncoming, Siren, Users, Vibrate } from 'lucide-react'
import { toIntlNumber, useApp, vibrate, type TriggerSource } from '@/lib/store'
import { GpsErrorAlert, Panel, SectionTitle } from './primitives'
import { FakeCall } from './fake-call'
import { VoiceSosPanel } from './voice-sos'
import { FailSafeInfo, FamilyHero, LockScreenCardButton, ProtocolMarquee } from './home-hero'

export function HomeTab() {
  const { L } = useApp()
  return (
    <div className="space-y-4">
      <FamilyHero />
      <ProtocolMarquee />
      <SosButton />
      <FailSafeInfo />
      <LockScreenCardButton />
      <div className="grid grid-cols-2 gap-3">
        <a
          href="tel:112"
          className="btn-thick flex flex-col items-start gap-2 rounded-2xl border-2 border-red-300/40 bg-[#b91c1c] p-4 text-white"
        >
          <Siren className="size-8" aria-hidden />
          <span className="text-base font-black leading-tight">{L('போலீஸ் அழைப்பு', 'Call Police')}</span>
          <span className="rounded-lg bg-black/25 px-2 py-0.5 text-lg font-black tabular-nums">112</span>
        </a>
        <a
          href="tel:108"
          className="btn-thick flex flex-col items-start gap-2 rounded-2xl border-2 border-orange-200/50 bg-primary p-4 text-primary-foreground"
        >
          <Ambulance className="size-8" aria-hidden />
          <span className="text-base font-black leading-tight">{L('ஆம்புலன்ஸ் அழைப்பு', 'Call Ambulance')}</span>
          <span className="rounded-lg bg-black/15 px-2 py-0.5 text-lg font-black tabular-nums">108</span>
        </a>
      </div>
      <VoiceSosPanel />
      <QuickActions />
      <FamilyFirstInfo />
      <SimulationRow />
    </div>
  )
}

function SosButton() {
  const { L, activateSOS } = useApp()
  return (
    <div className="flex flex-col items-center py-3">
      <button
        type="button"
        aria-label={L('SOS அவசர அழைப்பு — அழுத்தவும்', 'SOS emergency — press')}
        onClick={() => {
          vibrate(60)
          activateSOS('Manual SOS')
        }}
        className="sos-glow flex size-52 select-none flex-col items-center justify-center rounded-full border-8 border-red-300/30 bg-[radial-gradient(circle_at_35%_30%,#f87171,#dc2626_50%,#991b1b)] text-white transition-transform active:scale-95"
      >
        <span className="text-6xl font-black tracking-wider drop-shadow">SOS</span>
        <span className="mt-1 rounded-full bg-black/25 px-3 py-1 text-sm font-bold">- {L('அழுத்தவும்', 'Press')}</span>
      </button>
      <p className="mt-4 text-center text-xs font-medium text-foreground/80">
        {L('அழுத்தியவுடன் சைரன் ஒலிக்கும், குடும்பத்தினருக்கான SMS / வாட்ஸ்அப் செய்தி தயாராகும்', 'Siren sounds and an SMS / WhatsApp alert is prepared for your family')}
      </p>
    </div>
  )
}

function QuickActions() {
  const { L, contacts, userName, showToast, logLocation } = useApp()
  const [fakeCallOpen, setFakeCallOpen] = useState(false)
  const [gpsFailed, setGpsFailed] = useState(false)
  const [sharing, setSharing] = useState(false)

  const shareLocation = async () => {
    setSharing(true)
    const pos = await logLocation('WhatsApp share')
    setSharing(false)
    setGpsFailed(!pos)
    if (!pos) return
    const msg = `நண்பேன்டா அவசர எச்சரிக்கை — ${userName}. என் நேரடி இருப்பிடம்: https://maps.google.com/?q=${pos.lat},${pos.lng}`
    const first = contacts.find((c) => c.phone.replace(/\D/g, '').length >= 10)
    const phone = first ? toIntlNumber(first.phone) : ''
    window.open(`https://wa.me/${phone}?text=${encodeURIComponent(msg)}`, '_blank', 'noopener,noreferrer')
    showToast(L('வாட்ஸ்அப் திறக்கப்பட்டது — அனுப்பு அழுத்தவும்', 'WhatsApp opened — press Send'))
  }

  return (
    <Panel>
      <SectionTitle>{L('விரைவுச் செயல்கள்', 'Quick Actions')}</SectionTitle>
      <div className="space-y-3">
        {gpsFailed ? <GpsErrorAlert onRetry={shareLocation} /> : null}
        <button
          type="button"
          onClick={shareLocation}
          disabled={sharing}
          aria-busy={sharing}
          className="btn-thick flex w-full disabled:opacity-70 items-center gap-3 rounded-2xl border-2 border-green-200/40 bg-[#128c3e] p-4 text-left text-white"
        >
          <span className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-white/15">
            <MessageCircle className="size-7" aria-hidden />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-base font-black leading-snug">{L('வாட்ஸ்அப் லைவ் லொகேஷன் பகிர்வு', 'WhatsApp Live Location')}</span>
            <span className="block text-xs font-medium text-white/85">{L('உடனடியாக நேரடி இருப்பிடத்தை அனுப்பவும்', 'Send live tracking instantly')}</span>
          </span>
          <ChevronRight className="size-5 shrink-0" aria-hidden />
        </button>
        <button
          type="button"
          onClick={() => setFakeCallOpen(true)}
          className="btn-thick flex w-full items-center gap-3 rounded-2xl border-2 border-sky-200/40 bg-[#1d4ed8] p-4 text-left text-white"
        >
          <span className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-white/15">
            <PhoneIncoming className="size-7" aria-hidden />
          </span>
          <span className="min-w-0 flex-1">
            <span className="block text-base font-black leading-snug">{L('போலி அழைப்பு சிமுலேட்டர்', 'Fake Call Simulator')}</span>
            <span className="block text-xs font-medium text-white/85">{L("'அப்பா', 'இன்ஸ்பெக்டர்' அழைப்பது போல் தப்பிக்கவும்", "Escape safely with a call from 'Appa' or 'Inspector'")}</span>
          </span>
          <ChevronRight className="size-5 shrink-0" aria-hidden />
        </button>
      </div>
      {fakeCallOpen ? <FakeCall onClose={() => setFakeCallOpen(false)} /> : null}
    </Panel>
  )
}

function FamilyFirstInfo() {
  const { L } = useApp()
  return (
    <Panel className="border-primary/50 bg-gradient-to-br from-primary/15 to-card">
      <SectionTitle icon={<Users className="size-5 text-primary" aria-hidden />}>
        {L('குடும்ப முன்னுரிமை அலாரத் தடுப்பு', 'Family-First Anti-False Alarm')}
      </SectionTitle>
      <p className="text-sm leading-relaxed text-foreground/90 text-pretty">
        {L(
          'சென்சார் ஆபத்தைக் கண்டறிந்தால் 15 வினாடி கவுண்ட்டவுன் மற்றும் சைரன் ஒலிக்கும். ரத்து செய்யாவிட்டால், லைவ் ஜிபிஎஸ் லிங்குடன் கூடிய SMS / வாட்ஸ்அப் செய்தி உங்கள் 3 அவசரத் தொடர்புகளுக்குத் தயாராகும். அனுப்பு பட்டனை நீங்களே அழுத்த வேண்டும். உயிருக்கு ஆபத்தெனில் 112-ஐ அழைக்கவும்.',
          'When a sensor detects danger, a 15-second countdown and siren start. If not cancelled, an SMS / WhatsApp message with your live GPS link is prepared for your 3 emergency contacts — you press Send. For life-threatening danger, call 112.',
        )}
      </p>
    </Panel>
  )
}

const SIMS: { source: TriggerSource; icon: typeof Car; ta: string; en: string; tone: string }[] = [
  { source: 'Shake', icon: Vibrate, ta: 'ஃபோன் குலுக்கல்', en: 'Shake Test', tone: 'border-primary/60 text-primary' },
  { source: 'Fall', icon: PersonStanding, ta: 'தடுமாறி விழுதல்', en: 'Fall Test', tone: 'border-gold/60 text-gold' },
  { source: 'Voice', icon: Mic, ta: 'குரல் அலறல்', en: 'Voice Test', tone: 'border-neon/60 text-neon' },
  { source: 'Crash', icon: Car, ta: 'விபத்து மோதல்', en: 'Crash Test', tone: 'border-sos/70 text-red-400' },
]

function SimulationRow() {
  const { L, triggerDetection } = useApp()
  return (
    <Panel>
      <SectionTitle hint={L('15 வி. ரத்து', '15s cancel')}>{L('நேரடி சோதனை பொத்தான்கள்', 'Safe Simulation Area')}</SectionTitle>
      <div className="grid grid-cols-2 gap-3">
        {SIMS.map(({ source, icon: Icon, ta, en, tone }) => (
          <button
            key={source}
            type="button"
            onClick={() => triggerDetection(source)}
            className={`btn-thick flex flex-col items-center gap-2 rounded-2xl border-2 bg-secondary p-3.5 text-center ${tone}`}
          >
            <Icon className="size-7" aria-hidden />
            <span className="text-sm font-black leading-tight text-foreground">{L(ta, en)}</span>
            <span className="text-[11px] font-semibold opacity-90">{en}</span>
          </button>
        ))}
      </div>
    </Panel>
  )
}
