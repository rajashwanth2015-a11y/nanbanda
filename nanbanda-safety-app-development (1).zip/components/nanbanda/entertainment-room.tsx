'use client'

import { useEffect, useState } from 'react'
import { BookOpen, Brain, RotateCcw, Square, Volume2 } from 'lucide-react'
import { speak, useApp } from '@/lib/store'
import { cn } from '@/lib/utils'
import { Panel, SectionTitle } from './primitives'

const STORIES = [
  {
    ta: 'காகமும் தண்ணீர் குடமும்',
    en: 'The Crow and the Pot',
    body: 'ஒரு வெயில் நாளில் தாகமான காகம் ஒரு குடத்தைக் கண்டது. அதில் தண்ணீர் அடியில் மட்டுமே இருந்தது. காகம் யோசித்து, சிறு கற்களை ஒவ்வொன்றாகப் போட்டது. தண்ணீர் மேலே வந்தது, காகம் தாகம் தீர்த்தது. முயற்சியும் யோசனையும் இருந்தால் எதையும் சாதிக்கலாம்.',
  },
  {
    ta: 'சிங்கமும் சுண்டெலியும்',
    en: 'The Lion and the Mouse',
    body: 'ஒரு சிங்கம் ஒரு சின்ன சுண்டெலியை மன்னித்து விட்டது. பின்னர் சிங்கம் வேடனின் வலையில் சிக்கியபோது, அந்த சுண்டெலி வலையைக் கடித்து சிங்கத்தைக் காப்பாற்றியது. சிறிய உதவியும் பெரிய பலன் தரும்.',
  },
  {
    ta: 'ஆமையும் முயலும்',
    en: 'The Tortoise and the Hare',
    body: 'வேகமான முயல் ஆமையைக் கேலி செய்தது. இருவரும் ஓட்டப் பந்தயம் வைத்தனர். முயல் வழியில் தூங்கிவிட்டது. ஆமை நிதானமாக நடந்து வெற்றி பெற்றது. நிதானமும் விடாமுயற்சியும் வெற்றியைத் தரும்.',
  },
  {
    ta: 'நரியும் திராட்சையும்',
    en: 'The Fox and the Grapes',
    body: 'பசியான நரி உயரத்தில் தொங்கிய திராட்சைக் கொத்தைப் பார்த்தது. பலமுறை குதித்தும் எட்டவில்லை. "இந்தத் திராட்சை புளிக்கும்" என்று சொல்லிவிட்டுப் போனது. கிடைக்காததைக் குறை சொல்வது எளிது; முயற்சியைத் தொடர்வதே சிறந்தது.',
  },
  {
    ta: 'பேராசைக்கார நாய்',
    en: 'The Greedy Dog',
    body: 'எலும்புடன் பாலத்தைக் கடந்த நாய் தண்ணீரில் தன் நிழலைக் கண்டது. அந்த எலும்பையும் பறிக்க குரைத்தது. வாயிலிருந்த எலும்பு தண்ணீரில் விழுந்தது. பேராசை இருப்பதையும் இழக்கச் செய்யும்.',
  },
  {
    ta: 'ஒற்றுமையே பலம்',
    en: 'Unity is Strength',
    body: 'ஒரு விவசாயி தன் மகன்களிடம் ஒரு குச்சியை உடைக்கச் சொன்னார் — எளிதாக உடைந்தது. பிறகு குச்சிகளைக் கட்டாகக் கொடுத்தார் — யாராலும் உடைக்க முடியவில்லை. ஒற்றுமையாக இருந்தால் யாரும் நம்மை வெல்ல முடியாது.',
  },
  {
    ta: 'பொய் சொன்ன இடைச் சிறுவன்',
    en: 'The Boy Who Cried Wolf',
    body: 'ஆடு மேய்க்கும் சிறுவன் விளையாட்டாக "ஓநாய் வருகிறது!" என்று கத்தினான். ஊரார் ஓடி வந்து ஏமாந்தனர். உண்மையில் ஓநாய் வந்தபோது யாரும் நம்பவில்லை. பொய் சொல்பவரை உண்மை சொல்லும்போதும் யாரும் நம்ப மாட்டார்கள்.',
  },
  {
    ta: 'எறும்பும் வெட்டுக்கிளியும்',
    en: 'The Ant and the Grasshopper',
    body: 'கோடையில் எறும்பு உணவு சேமித்தது; வெட்டுக்கிளி பாடி விளையாடியது. மழைக்காலம் வந்ததும் எறும்பிடம் உணவு இருந்தது, வெட்டுக்கிளி பசியால் வாடியது. இன்றைய உழைப்பு நாளைய பாதுகாப்பு.',
  },
  {
    ta: 'தெனாலிராமனும் திருடர்களும்',
    en: 'Tenali Raman and the Thieves',
    body: 'திருடர்கள் தோட்டத்தில் ஒளிந்திருப்பதைக் கண்ட தெனாலிராமன், "நகைப் பெட்டியைக் கிணற்றில் போட்டுவிட்டேன்" என்று சத்தமாகச் சொன்னார். திருடர்கள் இரவு முழுவதும் கிணற்று நீரை இறைத்தனர் — தோட்டத்துக்கு இலவசமாகத் தண்ணீர் கிடைத்தது! புத்திசாலித்தனம் பெரிய ஆயுதம்.',
  },
]

const STORIES_SHOWN = 3

function pickStories() {
  return STORIES.map((s) => ({ s, r: Math.random() }))
    .sort((a, b) => a.r - b.r)
    .slice(0, STORIES_SHOWN)
    .map((x) => x.s)
}

const CARD_POOL = ['மா', 'பலா', 'வாழை', 'தேங்காய்', 'பூ', 'மயில்', 'யானை', 'கிளி', 'தாமரை', 'மல்லிகை', 'நிலா', 'சூரியன்']
const PAIRS = 6

function shuffledDeck() {
  const picks = CARD_POOL.map((v) => ({ v, r: Math.random() }))
    .sort((a, b) => a.r - b.r)
    .slice(0, PAIRS)
    .map((x) => x.v)
  return [...picks, ...picks]
    .map((v, i) => ({ id: i, v, r: Math.random() }))
    .sort((a, b) => a.r - b.r)
}

export function EntertainmentRoom() {
  return (
    <>
      <Stories />
      <MemoryGame />
    </>
  )
}

function Stories() {
  const { L } = useApp()
  const [playing, setPlaying] = useState<number | null>(null)
  const [stories, setStories] = useState(() => STORIES.slice(0, STORIES_SHOWN))

  useEffect(() => setStories(pickStories()), [])

  const reshuffle = () => {
    if ('speechSynthesis' in window) window.speechSynthesis.cancel()
    setPlaying(null)
    setStories(pickStories())
  }

  useEffect(() => () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) window.speechSynthesis.cancel()
  }, [])

  const stop = () => {
    if ('speechSynthesis' in window) window.speechSynthesis.cancel()
    setPlaying(null)
  }

  return (
    <Panel>
      <SectionTitle icon={<BookOpen className="size-5 text-success" aria-hidden />}>
        {L('தமிழ் நீதிக் கதைகள்', 'Tamil Moral Stories')}
      </SectionTitle>
      <button
        type="button"
        onClick={reshuffle}
        className="mb-3 flex w-full items-center justify-center gap-2 rounded-xl border-2 border-success/60 py-2.5 text-sm font-bold text-success"
      >
        <RotateCcw className="size-4" aria-hidden /> {L('புதிய கதைகள்', 'New stories')}
      </button>
      <ul className="flex flex-col gap-2.5">
        {stories.map((s, i) => (
          <li key={s.en} className="rounded-xl border-2 border-white/15 bg-secondary p-3">
            <div className="flex items-center justify-between gap-3">
              <p className="font-black">{L(s.ta, s.en)}</p>
              <button
                type="button"
                onClick={() => {
                  if (playing === i) return stop()
                  speak(s.body)
                  setPlaying(i)
                }}
                aria-label={playing === i ? L('நிறுத்து', 'Stop') : L('கதை கேள்', 'Listen to story')}
                className={cn(
                  'btn-thick flex size-11 shrink-0 items-center justify-center rounded-full',
                  playing === i ? 'bg-sos text-sos-foreground' : 'bg-success text-background',
                )}
              >
                {playing === i ? <Square className="size-5" aria-hidden /> : <Volume2 className="size-5" aria-hidden />}
              </button>
            </div>
            {playing === i ? <p className="mt-2 text-sm leading-relaxed text-foreground/90">{s.body}</p> : null}
          </li>
        ))}
      </ul>
    </Panel>
  )
}

function MemoryGame() {
  const { L } = useApp()
  const [deck, setDeck] = useState(shuffledDeck)
  const [open, setOpen] = useState<number[]>([])
  const [matched, setMatched] = useState<string[]>([])
  const [moves, setMoves] = useState(0)

  useEffect(() => {
    if (open.length !== 2) return
    const [a, b] = open
    const id = setTimeout(() => {
      if (deck[a].v === deck[b].v) setMatched((m) => [...m, deck[a].v])
      setOpen([])
    }, 700)
    return () => clearTimeout(id)
  }, [open, deck])

  const reset = () => {
    setDeck(shuffledDeck())
    setOpen([])
    setMatched([])
    setMoves(0)
  }

  const won = matched.length === PAIRS

  return (
    <Panel>
      <SectionTitle
        icon={<Brain className="size-5 text-success" aria-hidden />}
        hint={`${L('நகர்வுகள்', 'Moves')}: ${moves}`}
      >
        {L('நினைவாற்றல் விளையாட்டு', 'Memory Match')}
      </SectionTitle>
      <p className="mb-3 text-sm leading-relaxed text-foreground/80">
        {L('ஒரே மாதிரியான இரண்டு அட்டைகளைக் கண்டுபிடியுங்கள்.', 'Find the matching pairs of cards.')}
      </p>
      <div className="grid grid-cols-4 gap-2">
        {deck.map((c, i) => {
          const shown = open.includes(i) || matched.includes(c.v)
          return (
            <button
              key={c.id}
              type="button"
              disabled={shown || open.length === 2}
              onClick={() => {
                setOpen((o) => [...o, i])
                if (open.length === 1) setMoves((m) => m + 1)
              }}
              aria-label={shown ? c.v : L('மூடிய அட்டை', 'Hidden card')}
              className={cn(
                'flex aspect-square items-center justify-center rounded-xl border-2 text-sm font-black transition-colors',
                matched.includes(c.v)
                  ? 'border-success bg-success/20 text-success'
                  : shown
                    ? 'border-primary bg-primary text-primary-foreground'
                    : 'border-white/15 bg-secondary text-foreground/40',
              )}
            >
              {shown ? c.v : '?'}
            </button>
          )
        })}
      </div>
      {won ? (
        <p role="status" className="mt-3 rounded-xl bg-success/15 p-3 text-center font-black text-success">
          {L(`அருமை நண்பா! ${moves} நகர்வுகளில் வென்றீர்கள்`, `Well done, friend! Won in ${moves} moves`)}
        </p>
      ) : null}
      <button
        type="button"
        onClick={reset}
        className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl border-2 border-white/25 py-3 font-bold"
      >
        <RotateCcw className="size-4" aria-hidden />
        {L('மீண்டும் விளையாடு', 'Play again')}
      </button>
    </Panel>
  )
}
