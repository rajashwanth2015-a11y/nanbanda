'use client'

import { useEffect, useRef, useState } from 'react'
import { Ear, EarOff } from 'lucide-react'
import { useApp } from '@/lib/store'
import { cn } from '@/lib/utils'
import { Switch } from './primitives'

type Recognition = {
  lang: string
  continuous: boolean
  interimResults: boolean
  start: () => void
  stop: () => void
  onresult: ((e: { resultIndex: number; results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null
  onend: (() => void) | null
  onerror: ((e: { error: string }) => void) | null
}

const KEYWORDS = /காப்பா(த்|ற்)|காப்பாத்து|help\s*me|ஹெல்ப்|bachao|save\s*me/i

function getRecognitionCtor(): (new () => Recognition) | null {
  if (typeof window === 'undefined') return null
  const w = window as unknown as { SpeechRecognition?: new () => Recognition; webkitSpeechRecognition?: new () => Recognition }
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null
}

export function VoiceSosListener() {
  const { voiceSos, emergency, triggerDetection, update, showToast, L } = useApp()
  const idle = emergency.stage === 'idle'
  const latest = useRef({ triggerDetection, idle })
  latest.current = { triggerDetection, idle }

  useEffect(() => {
    if (!voiceSos) return
    const Ctor = getRecognitionCtor()
    if (!Ctor) return
    let stopped = false
    const rec = new Ctor()
    rec.lang = 'ta-IN'
    rec.continuous = true
    rec.interimResults = true
    rec.onresult = (e) => {
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const text = e.results[i][0]?.transcript ?? ''
        if (KEYWORDS.test(text) && latest.current.idle) {
          latest.current.triggerDetection('Voice')
          return
        }
      }
    }
    rec.onerror = (e) => {
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') {
        stopped = true
        update({ voiceSos: false })
        showToast(L('குரல் SOS-க்கு மைக்ரோஃபோன் அனுமதி தேவை', 'Microphone permission needed for Voice SOS'))
      }
    }
    rec.onend = () => {
      if (!stopped) {
        try {
          rec.start()
        } catch {}
      }
    }
    try {
      rec.start()
    } catch {}
    return () => {
      stopped = true
      rec.onend = null
      rec.stop()
    }
  }, [voiceSos, update, showToast, L])

  return null
}

export function VoiceSosPanel() {
  const { voiceSos, update, showToast, L } = useApp()
  const [supported, setSupported] = useState(true)
  useEffect(() => setSupported(!!getRecognitionCtor()), [])

  const toggle = (v: boolean) => {
    if (v && !supported) return showToast(L('இந்த உலாவியில் குரல் கண்டறிதல் இல்லை — குரல் சோதனையைப் பயன்படுத்தவும்', 'Speech recognition unsupported here — use Voice Test'))
    update({ voiceSos: v })
  }

  return (
    <section className={cn('rounded-2xl border-2 p-4', voiceSos ? 'border-neon bg-neon/10' : 'border-white/15 bg-card')} aria-labelledby="voice-sos-title">
      <div className="flex items-center gap-3">
        <span className={cn('flex size-12 shrink-0 items-center justify-center rounded-xl', voiceSos ? 'bg-neon text-background' : 'bg-secondary text-neon')}>
          {voiceSos ? <Ear className="size-6" aria-hidden /> : <EarOff className="size-6" aria-hidden />}
        </span>
        <div className="min-w-0 flex-1">
          <h2 id="voice-sos-title" className="text-base font-black leading-snug">
            {L('குரல் SOS கண்காணிப்பு', 'Voice SOS Trigger')}
          </h2>
          <p className={cn('text-xs font-bold', voiceSos ? 'text-neon' : 'text-foreground/70')}>
            {voiceSos ? (
              <span className="inline-flex items-center gap-1.5">
                <span className="pulse-dot size-2 rounded-full bg-neon" aria-hidden />
                {L('கேட்டுக்கொண்டிருக்கிறது…', 'Listening…')}
              </span>
            ) : (
              L('அணைக்கப்பட்டுள்ளது', 'Off')
            )}
          </p>
        </div>
        <Switch checked={voiceSos} onChange={toggle} label={L('குரல் SOS', 'Voice SOS')} />
      </div>
      <p className="mt-3 text-sm leading-relaxed text-foreground/90 text-pretty">
        {L('நீங்கள் ', 'If you scream ')}
        <strong className="text-gold">{'"காப்பாத்துங்க"'}</strong>
        {L(' அல்லது ', ' or ')}
        <strong className="text-gold">{'"Help Me"'}</strong>
        {L(' என்று அலறினால், 15 வினாடி SOS கவுண்ட்டவுன் தானாகத் தொடங்கும்.', ', the 15-second SOS countdown starts automatically.')}
      </p>
    </section>
  )
}
