'use client'

import { useEffect, useRef, useState } from 'react'
import { Volume2, X } from 'lucide-react'
import { speak, useApp } from '@/lib/store'
import { cn } from '@/lib/utils'

const PHRASE = 'அப்பா, கோவப்படாதீங்க.. நான் இருக்கேன்ல.. ரிலாக்ஸ் பண்ணுங்க!'
const TOTAL = 120
const PHASES = ['Inhale', 'Hold', 'Exhale', 'Hold'] as const
const PHASE_TA = ['மூச்சை இழு', 'நிறுத்து', 'மூச்சை விடு', 'நிறுத்து']
const STEP = 4

const MOODS = [
  { emoji: '😡', label: 'Angry', ta: 'கோபம்' },
  { emoji: '😟', label: 'Stressed', ta: 'பதற்றம்' },
  { emoji: '😐', label: 'Okay', ta: 'பரவாயில்லை' },
  { emoji: '🙂', label: 'Calm', ta: 'அமைதி' },
  { emoji: '😊', label: 'Happy', ta: 'மகிழ்ச்சி' },
]

export function MoodTracker({ compact }: { compact?: boolean }) {
  const { moods, update, showToast, L } = useApp()
  const latest = moods[0]
  return (
    <div>
      <div className="flex justify-between gap-1" role="group" aria-label={L('நீங்கள் எப்படி உணர்கிறீர்கள்?', 'How are you feeling?')}>
        {MOODS.map((m) => (
          <button
            key={m.label}
            type="button"
            onClick={() => {
              update({ moods: [{ mood: m.label, at: new Date().toISOString() }, ...moods].slice(0, 30) })
              showToast(L(`மனநிலை பதிவு: ${m.ta}`, `Mood logged: ${m.label}`))
            }}
            aria-pressed={latest?.mood === m.label}
            className={cn(
              'flex flex-1 flex-col items-center gap-1 rounded-xl py-2 transition-transform active:scale-90',
              latest?.mood === m.label ? 'bg-primary/15 ring-1 ring-primary' : 'bg-secondary/60',
            )}
          >
            <span className="text-2xl" aria-hidden>
              {m.emoji}
            </span>
            <span className="text-[11px] font-bold text-foreground/80">{L(m.ta, m.label)}</span>
          </button>
        ))}
      </div>
      {!compact && moods.length ? (
        <p className="mt-3 text-xs text-muted-foreground">
          {L('கடைசி 7:', 'Last 7:')}{' '}
          {moods
            .slice(0, 7)
            .map((m) => MOODS.find((x) => x.label === m.mood)?.emoji)
            .join(' ')}
        </p>
      ) : null}
    </div>
  )
}

export function ChellaKuralMode({ onClose }: { onClose: () => void }) {
  const { chellaPhoto, chellaAudio, L } = useApp()
  const [talking, setTalking] = useState(false)
  const [elapsed, setElapsed] = useState(0)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  const play = () => {
    setTalking(true)
    if (chellaAudio) {
      audioRef.current?.pause()
      const a = new Audio(chellaAudio)
      audioRef.current = a
      a.onended = () => setTalking(false)
      a.play().catch(() => setTalking(false))
    } else {
      speak(PHRASE)
      setTimeout(() => setTalking(false), 5500)
    }
  }

  useEffect(() => {
    play()
    const id = setInterval(() => setElapsed((e) => (e >= TOTAL ? e : e + 1)), 1000)
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    return () => {
      clearInterval(id)
      window.removeEventListener('keydown', onKey)
      audioRef.current?.pause()
      if ('speechSynthesis' in window) window.speechSynthesis.cancel()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const done = elapsed >= TOTAL
  const phaseIndex = Math.floor(elapsed / STEP) % 4
  const phaseCount = STEP - (elapsed % STEP)
  const remaining = TOTAL - elapsed
  const scale = phaseIndex === 0 ? 1 : phaseIndex === 2 ? 0.55 : phaseIndex === 1 ? 1 : 0.55

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={L('செல்லக் குரல் அமைதி முறை', 'Chella Kural calming mode')}
      className="absolute inset-0 z-50 flex flex-col overflow-y-auto bg-[radial-gradient(ellipse_at_top,#3b2353,#0f172a_65%)] px-5 pb-6 pt-5 animate-in fade-in zoom-in-95"
    >
      <div className="flex items-center justify-between">
        <p className="text-sm font-semibold text-white/80">செல்லக் குரல்</p>
        <button type="button" onClick={onClose} aria-label={L('மூடு', 'Close')} className="rounded-full bg-white/10 p-2 text-white">
          <X className="size-5" aria-hidden />
        </button>
      </div>

      <div className="mt-4 flex flex-col items-center">
        <div className={cn('relative size-52 overflow-hidden rounded-full ring-4 ring-pink/60', talking && 'portrait-talk')}>
          <img src={chellaPhoto ?? '/images/chella-default.png'} alt={L('உங்கள் அன்புக்குரியவரின் பேசும் உருவப்படம்', 'Talking portrait of your loved one')} className="size-full object-cover" />
          <div className="blink-lid pointer-events-none absolute inset-x-0 top-[30%] h-[18%] bg-gradient-to-b from-transparent via-black/45 to-transparent" aria-hidden />
          <div className="pointer-events-none absolute inset-0 rounded-full shadow-[inset_0_0_40px_rgba(249,115,22,0.35)]" aria-hidden />
        </div>

        <div className="mt-4 flex h-8 items-center gap-1" aria-hidden>
          {Array.from({ length: 14 }).map((_, i) => (
            <span
              key={i}
              className={cn('w-1 rounded-full bg-pink', talking ? 'wave-bar' : 'opacity-30')}
              style={{ height: `${10 + ((i * 7) % 22)}px`, animationDelay: `${(i % 5) * 0.12}s` }}
            />
          ))}
        </div>
        <p className="mt-2 text-center text-lg font-semibold leading-relaxed text-white text-balance">&ldquo;{PHRASE}&rdquo;</p>
        <button type="button" onClick={play} className="mt-2 inline-flex items-center gap-1.5 text-xs font-medium text-primary">
          <Volume2 className="size-4" aria-hidden /> {L('மீண்டும் கேள்', 'Play again')}
        </button>
      </div>

      <div className="mt-6 rounded-3xl border border-white/10 bg-white/5 p-5">
        <div className="flex items-center justify-between text-xs text-white/60">
          <span>{L('மூச்சுப் பெட்டி', 'Breathing Box')} · 4-4-4-4</span>
          <span className="tabular-nums">
            {Math.floor(remaining / 60)}:{String(remaining % 60).padStart(2, '0')}
          </span>
        </div>
        <div className="relative mx-auto mt-4 flex size-40 items-center justify-center rounded-2xl border-2 border-white/15">
          <div
            className="absolute rounded-2xl bg-pink/25 transition-all ease-in-out"
            style={{ inset: 0, transform: `scale(${done ? 0.7 : scale})`, transitionDuration: `${STEP}s` }}
            aria-hidden
          />
          <div className="relative text-center" aria-live="polite">
            {done ? (
              <p className="text-lg font-bold text-white">{L('அருமை!', 'Well done!')}</p>
            ) : (
              <>
                <p className="text-lg font-bold text-white">{L(PHASE_TA[phaseIndex], PHASES[phaseIndex])}</p>
                <p className="mt-1 text-3xl font-bold tabular-nums text-primary">{phaseCount}</p>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="mt-4 rounded-3xl border border-white/10 bg-white/5 p-4">
        <p className="mb-3 text-xs text-white/60">{L('இப்போது எப்படி உணர்கிறீர்கள்?', 'How do you feel now?')}</p>
        <MoodTracker compact />
      </div>
    </div>
  )
}
