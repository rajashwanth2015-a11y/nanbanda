'use client'

import { useState } from 'react'
import { BellRing, HeartPulse, Home, Lock, ShieldCheck, ShieldPlus } from 'lucide-react'
import { useApp } from '@/lib/store'
import { cn } from '@/lib/utils'
import { HomeTab } from './home-tab'
import { GuardTab, SensorWatcher } from './guard-tab'
import { WellnessTab } from './wellness-tab'
import { WalletTab } from './wallet-tab'
import { SettingsTab } from './settings-tab'
import { EmergencyOverlay } from './emergency-overlay'
import { CareWatcher, DailyCareTab } from './daily-care-tab'
import { VoiceSosListener } from './voice-sos'

const TABS = [
  { id: 'home', icon: Home, ta: 'முகப்பு', en: 'Home' },
  { id: 'guard', icon: ShieldCheck, ta: 'பாதுகாப்பு', en: 'Safety' },
  { id: 'care', icon: BellRing, ta: 'தினசரி', en: 'Daily' },
  { id: 'wellness', icon: HeartPulse, ta: 'நலம்', en: 'Wellness' },
  { id: 'wallet', icon: ShieldPlus, ta: 'இன்சூரன்ஸ்', en: 'Insurance' },
  { id: 'settings', icon: Lock, ta: 'தனியுரிமை', en: 'Privacy' },
] as const

type TabId = (typeof TABS)[number]['id']

export function AppShell() {
  const { L, premium, toast, language, update } = useApp()
  const [tab, setTab] = useState<TabId>('home')

  return (
    <div className="flex min-h-dvh justify-center bg-[#070b16]">
      <div className="relative flex h-dvh w-full max-w-md flex-col overflow-hidden bg-background md:my-4 md:h-[calc(100dvh-2rem)] md:rounded-[2rem] md:border-2 md:border-white/15 md:shadow-2xl">
        <header className="border-b-2 border-white/10 bg-gradient-to-b from-[#1a1030] to-background px-4 pb-3 pt-4">
          <div className="flex items-start justify-between gap-3">
            <div className="flex min-w-0 items-center gap-2.5">
              <span className="flex size-11 shrink-0 items-center justify-center rounded-xl bg-sos text-white shadow-[0_0_20px_-2px] shadow-sos/70">
                <ShieldCheck className="size-6" aria-hidden />
              </span>
              <div className="min-w-0">
                <h1 className="text-xl font-black leading-tight tracking-tight">
                  நண்பேன்டா <span className="text-sm font-semibold text-gold">(Nanbanda)</span>
                </h1>
                <p className="text-pretty text-xs font-medium leading-snug text-foreground/85">
                  ஆபத்திலும் அவசரத்திலும் உங்கள் உயிர் நண்பன்!
                </p>
              </div>
            </div>
            <div className="flex shrink-0 overflow-hidden rounded-xl border-2 border-white/20" role="radiogroup" aria-label="மொழி / Language">
              {(['ta', 'en'] as const).map((l) => (
                <button
                  key={l}
                  type="button"
                  role="radio"
                  aria-checked={language === l}
                  onClick={() => update({ language: l })}
                  className={cn('px-2.5 py-1.5 text-xs font-bold', language === l ? 'bg-primary text-primary-foreground' : 'bg-secondary text-foreground')}
                >
                  {l === 'ta' ? 'தமிழ்' : 'English'}
                </button>
              ))}
            </div>
          </div>
          <p className="mt-3 inline-flex items-center gap-2 rounded-full border-2 border-success/50 bg-success/15 px-3 py-1 text-xs font-bold text-success">
            <span className="pulse-dot size-2.5 rounded-full bg-success" aria-hidden />
            {L('உங்கள் பாதுகாப்பு உறுதி செய்யப்பட்டது', 'Your safety is secured')}
          </p>
        </header>

        <main className="flex-1 overflow-y-auto px-4 pb-6 pt-4">
          {tab === 'home' && <HomeTab />}
          {tab === 'guard' && <GuardTab />}
          {tab === 'care' && <DailyCareTab />}
          {tab === 'wellness' && <WellnessTab />}
          {tab === 'wallet' && <WalletTab />}
          {tab === 'settings' && <SettingsTab />}
        </main>

        <nav aria-label={L('முதன்மை வழிசெலுத்தல்', 'Main navigation')} className="grid grid-cols-6 gap-0.5 border-t-2 border-white/10 bg-card px-1 pb-[max(env(safe-area-inset-bottom),0.5rem)] pt-2">
          {TABS.map(({ id, icon: Icon, ta, en }) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              aria-current={tab === id ? 'page' : undefined}
              className={cn(
                'relative flex min-w-0 flex-col items-center gap-1 rounded-xl px-0.5 py-1.5 text-center text-[10px] font-bold leading-tight transition-colors',
                tab === id ? 'bg-primary/15 text-primary' : 'text-foreground/75 hover:text-foreground',
              )}
            >
              <Icon className="size-5" aria-hidden />
              {L(ta, en)}
              {id === 'wallet' && !premium ? <span className="absolute right-2 top-1 size-2 rounded-full bg-gold" aria-hidden /> : null}
            </button>
          ))}
        </nav>

        <SensorWatcher />
        <VoiceSosListener />
        <CareWatcher />
        <EmergencyOverlay />

        {toast ? (
          <div
            role="status"
            className="pointer-events-none absolute inset-x-4 bottom-24 z-[60] rounded-xl border-2 border-primary/60 bg-popover px-4 py-3 text-sm font-semibold shadow-xl animate-in fade-in slide-in-from-bottom-2"
          >
            {toast}
          </div>
        ) : null}
      </div>
    </div>
  )
}
