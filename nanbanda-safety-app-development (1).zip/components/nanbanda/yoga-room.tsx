'use client'

import { useState } from 'react'
import { Flower2, Volume2 } from 'lucide-react'
import { speak, useApp } from '@/lib/store'
import { cn } from '@/lib/utils'
import { Panel, SectionTitle } from './primitives'

type Category = 'meditation' | 'standing' | 'seated' | 'prone' | 'supine' | 'balance'

const CATEGORY_LABEL: Record<Category, [string, string]> = {
  meditation: ['தியானம்', 'Meditation'],
  standing: ['நின்று', 'Standing'],
  seated: ['அமர்ந்து', 'Seated'],
  prone: ['குப்புற', 'Prone'],
  supine: ['மல்லாந்து', 'Supine'],
  balance: ['சமநிலை', 'Balance'],
}

const ASANAS: { ta: string; en: string; c: Category; benefit: string }[] = [
  { ta: 'பத்மாசனம்', en: 'Padmasana', c: 'meditation', benefit: 'மன அமைதி, முதுகுத்தண்டு நிமிர்வு' },
  { ta: 'வஜ்ராசனம்', en: 'Vajrasana', c: 'meditation', benefit: 'உணவுக்குப் பின் செரிமானம் மேம்படும்' },
  { ta: 'சுகாசனம்', en: 'Sukhasana', c: 'meditation', benefit: 'மன அழுத்தம் குறையும்' },
  { ta: 'யோக முத்ராசனம்', en: 'Yoga Mudrasana', c: 'meditation', benefit: 'செரிமானம், மன அமைதி' },
  { ta: 'சிம்ஹாசனம்', en: 'Simhasana', c: 'meditation', benefit: 'தொண்டை, முகத் தசை தளர்வு' },
  { ta: 'தாடாசனம்', en: 'Tadasana', c: 'standing', benefit: 'உடல் நிலைப்பாடு சீராகும்' },
  { ta: 'திரிகோணாசனம்', en: 'Trikonasana', c: 'standing', benefit: 'இடுப்பு, கால் தசை நீட்சி' },
  { ta: 'வீரபத்ராசனம் I', en: 'Virabhadrasana I', c: 'standing', benefit: 'கால் வலிமை, மார்பு விரிவு' },
  { ta: 'வீரபத்ராசனம் II', en: 'Virabhadrasana II', c: 'standing', benefit: 'தோள் வலிமை, சகிப்புத் தன்மை' },
  { ta: 'உத்கடாசனம்', en: 'Utkatasana', c: 'standing', benefit: 'தொடைத் தசை வலிமை' },
  { ta: 'உத்தானாசனம்', en: 'Uttanasana', c: 'standing', benefit: 'தலைவலி, பதற்றம் குறையும்' },
  { ta: 'பார்ஸ்வோத்தானாசனம்', en: 'Parsvottanasana', c: 'standing', benefit: 'கால் பின்தசை நீட்சி' },
  { ta: 'அதோமுக ஸ்வானாசனம்', en: 'Adho Mukha Svanasana', c: 'standing', benefit: 'முழு உடல் நீட்சி, சோர்வு நீங்கும்' },
  { ta: 'விருக்ஷாசனம்', en: 'Vrikshasana', c: 'balance', benefit: 'சமநிலை, கவனம் கூடும்' },
  { ta: 'கருடாசனம்', en: 'Garudasana', c: 'balance', benefit: 'சமநிலை, மூட்டு வலிமை' },
  { ta: 'நடராஜாசனம்', en: 'Natarajasana', c: 'balance', benefit: 'சமநிலை, ஒருமுகப்பாடு' },
  { ta: 'அர்த்த சந்திராசனம்', en: 'Ardha Chandrasana', c: 'balance', benefit: 'இடுப்பு வலிமை, சமநிலை' },
  { ta: 'பகாசனம்', en: 'Bakasana', c: 'balance', benefit: 'கை, மணிக்கட்டு வலிமை' },
  { ta: 'மயூராசனம்', en: 'Mayurasana', c: 'balance', benefit: 'செரிமானம், கை வலிமை' },
  { ta: 'வசிஷ்டாசனம்', en: 'Vasisthasana', c: 'balance', benefit: 'கை, வயிற்று மையத் தசை வலிமை' },
  { ta: 'கும்பகாசனம்', en: 'Kumbhakasana', c: 'prone', benefit: 'வயிற்று மையத் தசை வலிமை' },
  { ta: 'சதுரங்க தண்டாசனம்', en: 'Chaturanga Dandasana', c: 'prone', benefit: 'கை, தோள் வலிமை' },
  { ta: 'புஜங்காசனம்', en: 'Bhujangasana', c: 'prone', benefit: 'முதுகுவலி நிவாரணம்' },
  { ta: 'தனுராசனம்', en: 'Dhanurasana', c: 'prone', benefit: 'வயிற்றுத் தசை வலிமை' },
  { ta: 'சலபாசனம்', en: 'Shalabhasana', c: 'prone', benefit: 'கீழ் முதுகு வலிமை' },
  { ta: 'மகராசனம்', en: 'Makarasana', c: 'prone', benefit: 'முதுகு ஓய்வு, சுவாசம் சீராகும்' },
  { ta: 'பாலாசனம்', en: 'Balasana', c: 'prone', benefit: 'ஓய்வு, பதற்றம் குறையும்' },
  { ta: 'மார்ஜாரியாசனம்', en: 'Marjaryasana', c: 'prone', benefit: 'முதுகுத்தண்டு நெகிழ்வு' },
  { ta: 'பிட்டிலாசனம்', en: 'Bitilasana', c: 'prone', benefit: 'முதுகுவலி குறையும்' },
  { ta: 'தண்டாசனம்', en: 'Dandasana', c: 'seated', benefit: 'நிமிர்ந்த அமர்வு நிலை' },
  { ta: 'பச்சிமோத்தாசனம்', en: 'Paschimottanasana', c: 'seated', benefit: 'தொடை நரம்பு நீட்சி, செரிமானம்' },
  { ta: 'ஜானு சிரசாசனம்', en: 'Janu Sirsasana', c: 'seated', benefit: 'சிறுநீரகம், கல்லீரல் தூண்டல்' },
  { ta: 'அர்த்த மத்ஸ்யேந்திராசனம்', en: 'Ardha Matsyendrasana', c: 'seated', benefit: 'முதுகுத்தண்டு சுழற்சி' },
  { ta: 'கோமுகாசனம்', en: 'Gomukhasana', c: 'seated', benefit: 'தோள் நெகிழ்வு' },
  { ta: 'பத்த கோணாசனம்', en: 'Baddha Konasana', c: 'seated', benefit: 'இடுப்பு நெகிழ்வு' },
  { ta: 'உபவிஷ்ட கோணாசனம்', en: 'Upavistha Konasana', c: 'seated', benefit: 'இடுப்பு, தொடை நீட்சி' },
  { ta: 'உஷ்ட்ராசனம்', en: 'Ustrasana', c: 'seated', benefit: 'மார்பு விரிவு, தோரணை மேம்படும்' },
  { ta: 'நவாசனம்', en: 'Navasana', c: 'seated', benefit: 'வயிற்றுத் தசை வலிமை' },
  { ta: 'சுப்த வஜ்ராசனம்', en: 'Supta Vajrasana', c: 'seated', benefit: 'வயிறு, தொடை நீட்சி' },
  { ta: 'சவாசனம்', en: 'Shavasana', c: 'supine', benefit: 'முழு உடல் ஓய்வு' },
  { ta: 'பவனமுக்தாசனம்', en: 'Pawanmuktasana', c: 'supine', benefit: 'வாயுத் தொல்லை நீங்கும்' },
  { ta: 'சர்வாங்காசனம்', en: 'Sarvangasana', c: 'supine', benefit: 'தைராய்டு, இரத்த ஓட்டம்' },
  { ta: 'ஹலாசனம்', en: 'Halasana', c: 'supine', benefit: 'முதுகுத்தண்டு நெகிழ்வு' },
  { ta: 'மத்ஸ்யாசனம்', en: 'Matsyasana', c: 'supine', benefit: 'சுவாசம் மேம்படும்' },
  { ta: 'சேது பந்தாசனம்', en: 'Setu Bandhasana', c: 'supine', benefit: 'முதுகு, இடுப்பு வலிமை' },
  { ta: 'சக்கராசனம்', en: 'Chakrasana', c: 'supine', benefit: 'முதுகுத்தண்டு வலிமை' },
  { ta: 'விபரீத கரணி', en: 'Viparita Karani', c: 'supine', benefit: 'கால் சோர்வு, வீக்கம் குறையும்' },
  { ta: 'ஆன���்த பாலாசனம்', en: 'Ananda Balasana', c: 'supine', benefit: 'கீழ் முதுகு ஓய்வு' },
  { ta: 'சுப்த பாதாங்குஷ்டாசனம்', en: 'Supta Padangusthasana', c: 'supine', benefit: 'தொடை பின்தசை நீட்சி' },
  { ta: 'சிரசாசனம்', en: 'Sirsasana', c: 'balance', benefit: 'கவனம் கூடும் (பயிற்சியாளர் உதவியுடன் மட்டும்)' },
]

const FILTERS: ('all' | Category)[] = ['all', 'meditation', 'standing', 'seated', 'prone', 'supine', 'balance']

export function YogaRoom() {
  const { L } = useApp()
  const [filter, setFilter] = useState<'all' | Category>('all')
  const list = filter === 'all' ? ASANAS : ASANAS.filter((a) => a.c === filter)

  return (
    <Panel>
      <SectionTitle icon={<Flower2 className="size-5 text-pink" aria-hidden />} hint={`${ASANAS.length}`}>
        {L('யோகாசனங்கள்', 'Yoga Asanas')}
      </SectionTitle>

      <div className="-mx-1 mb-3 flex gap-1.5 overflow-x-auto px-1 pb-1" role="group" aria-label={L('வகை', 'Category')}>
        {FILTERS.map((f) => (
          <button
            key={f}
            type="button"
            aria-pressed={filter === f}
            onClick={() => setFilter(f)}
            className={cn(
              'shrink-0 rounded-full border-2 px-3 py-1.5 text-xs font-bold',
              filter === f ? 'border-pink bg-pink text-background' : 'border-white/15 bg-secondary',
            )}
          >
            {f === 'all' ? L('அனைத்தும்', 'All') : L(...CATEGORY_LABEL[f])}
          </button>
        ))}
      </div>

      <ul className="grid grid-cols-2 gap-2">
        {list.map((a) => (
          <li key={a.en} className="flex flex-col rounded-xl border-2 border-white/15 bg-secondary p-3">
            <div className="flex items-center justify-between gap-2">
              <span className="flex size-6 items-center justify-center rounded-full bg-pink text-[11px] font-black text-background">
                {ASANAS.indexOf(a) + 1}
              </span>
              <span className="rounded-md bg-background px-1.5 py-0.5 text-[10px] font-bold text-pink">{L(...CATEGORY_LABEL[a.c])}</span>
            </div>
            <p className="mt-1.5 text-sm font-black leading-snug">{a.ta}</p>
            <p className="text-[11px] font-semibold text-foreground/60">{a.en}</p>
            <p className="mt-1.5 flex-1 text-xs leading-relaxed text-foreground/85">{a.benefit}</p>
            <button
              type="button"
              onClick={() => speak(`${a.ta}. ${a.benefit}`)}
              aria-label={L(`${a.ta} கேள்`, `Listen to ${a.en}`)}
              className="mt-2 flex items-center justify-center gap-1.5 rounded-lg border border-white/15 py-1.5 text-xs font-bold"
            >
              <Volume2 className="size-3.5" aria-hidden /> {L('கேள்', 'Listen')}
            </button>
          </li>
        ))}
      </ul>

      <p className="mt-3 text-xs leading-relaxed text-foreground/70 text-pretty">
        {L(
          'இரத்த அழுத்தம், இதய நோய், கர்ப்பம் அல்லது முதுகுத் தண்டு பிரச்சனை உள்ளவர்கள் மருத்துவர் / யோகா பயிற்சியாளர் ஆலோசனைக்குப் பின் மட்டும் செய்யவும்.',
          'If you have BP, heart conditions, pregnancy or spine issues, practise only after advice from a doctor or yoga teacher.',
        )}
      </p>
    </Panel>
  )
}
