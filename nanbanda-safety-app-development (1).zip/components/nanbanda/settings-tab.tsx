'use client'

import { useState } from 'react'
import { BluetoothSearching, Check, Database, KeyRound, Loader2, Users, Watch } from 'lucide-react'
import { useApp } from '@/lib/store'
import { cn } from '@/lib/utils'
import { Panel, SectionTitle } from './primitives'

export function SettingsTab() {
  return (
    <div className="flex flex-col gap-4">
      <ContactsPanel />
      <ConsentPanel />
      <PrivacyBanner />
      <BluetoothPanel />
    </div>
  )
}

function ContactsPanel() {
  const { contacts, update, showToast, L } = useApp()
  const [phones, setPhones] = useState(contacts.map((c) => c.phone))

  const save = (e: React.FormEvent) => {
    e.preventDefault()
    const invalid = phones.some((p) => p && p.replace(/\D/g, '').length < 10)
    if (invalid) return showToast(L('மொபைல் எண்ணில் குறைந்தது 10 இலக்கங்கள் வேண்டும்', 'Numbers need at least 10 digits'))
    update({ contacts: contacts.map((c, i) => ({ ...c, phone: phones[i] ?? '' })) })
    showToast(L('அவசரகால எண்கள் சேமிக்கப்பட்டன', 'Emergency numbers saved'))
  }

  return (
    <Panel>
      <SectionTitle icon={<Users className="size-5" aria-hidden />}>{L('பெற்றோர் கண்காணிப்பு வளையம்', 'Parental Control Hub')}</SectionTitle>
      <form onSubmit={save} className="flex flex-col gap-3">
        {[0, 1, 2].map((i) => (
          <div key={i}>
            <label htmlFor={`ph-${i}`} className="text-sm font-bold">
              {L(`அவசரகால மொபைல் எண் ${i + 1}`, `Emergency mobile number ${i + 1}`)}
            </label>
            <input
              id={`ph-${i}`}
              type="tel"
              inputMode="tel"
              autoComplete="tel"
              value={phones[i] ?? ''}
              placeholder="+91 98XXX XXXXX"
              onChange={(e) => setPhones((p) => p.map((v, idx) => (idx === i ? e.target.value.replace(/[^\d+\s]/g, '').slice(0, 16) : v)))}
              className="mt-1.5 w-full rounded-xl border-2 border-white/25 bg-secondary px-3 py-3 text-base font-semibold outline-none focus:border-primary"
            />
          </div>
        ))}
        <button type="submit" className="btn-thick w-full rounded-xl bg-sos py-4 font-black text-foreground">
          {L('எண்களைச் சேமி', 'Save numbers')}
        </button>
      </form>
    </Panel>
  )
}

function ConsentPanel() {
  const { trackingPin, update, showToast, L } = useApp()
  const generate = () => {
    const pin = String(Math.floor(100000 + Math.random() * 900000))
    update({ trackingPin: pin })
    showToast(L('புதிய டிராக்கிங் PIN உருவாக்கப்பட்டது', 'New tracking PIN generated'))
  }
  return (
    <section className="rounded-2xl border-2 border-primary bg-primary/10 p-4" aria-labelledby="consent-title">
      <h2 id="consent-title" className="flex items-center gap-2 text-base font-black text-primary">
        <KeyRound className="size-5" aria-hidden />
        {L('இருதரப்பு அனுமதி நெறிமுறை', 'Two-Way Consent Framework')}
      </h2>
      <p className="mt-2 text-sm font-medium leading-relaxed text-pretty">
        <strong className="text-gold">{L('பெற்றோர் கண்காணிப்பு வசதி:', 'Parental tracking:')}</strong>{' '}
        {L(
          'பெண் பிள்ளைகள் அல்லது குடும்பத்தினர் வீட்டை விட்டு வெளியே சென்றவுடன், அவர்களின் அனுமதியோடு (Dynamic Tracking PIN) பெற்றோர் தங்களின் சொந்த போனில் இருந்தே பிள்ளைகள் எங்கே இருக்கிறார்கள் என்பதை 24 மணிநேரமும் லைவ் மேப்பில் கண்காணிக்கலாம். உங்கள் மகளின் பாதுகாப்பு உங்கள் கைகளில்!',
          'When daughters or family members leave home, with their consent (Dynamic Tracking PIN), parents can watch their live location 24 hours from their own phone. Your daughter’s safety is in your hands!',
        )}
      </p>
      <div className="mt-3 flex items-center gap-3 rounded-xl border-2 border-white/15 bg-background p-3">
        <div className="min-w-0 flex-1">
          <p className="text-xs text-foreground/75">{L('டிராக்கிங் PIN', 'Tracking PIN')}</p>
          <p className="font-mono text-2xl font-black tracking-[0.3em] text-gold">{trackingPin ?? '------'}</p>
        </div>
        <button type="button" onClick={generate} className="btn-thick rounded-xl bg-primary px-4 py-3 text-sm font-black text-primary-foreground">
          {trackingPin ? L('மாற்று', 'Renew') : L('உருவாக்கு', 'Generate')}
        </button>
      </div>
    </section>
  )
}

function PrivacyBanner() {
  const { L } = useApp()
  return (
    <section className="rounded-2xl border-2 border-success bg-success/10 p-4" aria-labelledby="priv-title">
      <h2 id="priv-title" className="flex items-center gap-2 text-base font-black text-success">
        <Database className="size-5" aria-hidden />
        Zero Server Storage
      </h2>
      <p className="mt-2 text-sm font-medium leading-relaxed text-pretty">
        {L(
          'உங்களது குடும்பப் புகைப்படங்கள், ரகசிய வாய்ஸ் பதிவுகள், மற்றும் இன்சூரன்ஸ் பத்திரங்கள் அனைத்தும் உங்கள் சொந்த மொபைல் நினைவகத்தில் (Local Phone Storage) மட்டுமே பத்திரமாக இருக்கும். உங்கள் அனுமதி இல்லாமல் எங்கள் நிறுவனத்தால் கூட இதைப் பார்க்க முடியாது!',
          'Your family photos, secret voice recordings and insurance papers stay only in your phone’s Local Storage. Without your permission, not even our company can see them!',
        )}
      </p>
    </section>
  )
}

function BluetoothPanel() {
  const { watchPaired, update, showToast, triggerDetection, L } = useApp()
  const [scanning, setScanning] = useState(false)

  const pair = async () => {
    setScanning(true)
    try {
      const bt = (navigator as Navigator & { bluetooth?: { requestDevice: (o: object) => Promise<{ name?: string }> } }).bluetooth
      if (bt) {
        const device = await bt.requestDevice({ acceptAllDevices: true })
        update({ watchPaired: device.name || 'Smartwatch' })
      } else {
        await new Promise((r) => setTimeout(r, 1800))
        update({ watchPaired: 'Noise ColorFit Pro 5' })
      }
      showToast(L('ஸ்மார்ட்வாட்ச் இணைக்கப்பட்டது', 'Smartwatch paired'))
    } catch {
      showToast(L('இணைப்பு ரத்து செய்யப்பட்டது', 'Pairing cancelled'))
    } finally {
      setScanning(false)
    }
  }

  return (
    <section className="rounded-2xl border-2 border-neon bg-card p-4" aria-labelledby="bt-title">
      <h2 id="bt-title" className="flex items-center gap-2 text-base font-black text-neon">
        <Watch className="size-5" aria-hidden />
        {L('ஸ்மார்ட்வாட்ச் ப்ளூடூத் இணைப்பு', 'Smartwatch Bluetooth Link')}
      </h2>
      <p className="mt-2 text-sm font-medium leading-relaxed text-pretty">
        {L(
          'ஆபத்து அவசர காலங்களில் உங்கள் ஸ்மார்ட்வாட்ச் பட்டனை 3 முறை தொடர்ந்து அழுத்தினால், போனைத் தொடாமலேயே நண்பேன்டா SOS தானாக இயங்கும்!',
          'In an emergency, press your smartwatch button 3 times in a row and Nanbanda SOS starts automatically — without touching your phone!',
        )}
      </p>
      <div className="mt-3 flex items-center gap-3 rounded-xl border-2 border-white/15 bg-secondary p-3">
        <span className={cn('flex size-11 items-center justify-center rounded-xl', watchPaired ? 'bg-neon text-background' : 'bg-background text-foreground/70')}>
          <BluetoothSearching className="size-5" aria-hidden />
        </span>
        <div className="min-w-0 flex-1">
          <p className="truncate font-bold">{watchPaired ?? L('சாதனம் இணைக்கப்படவில்லை', 'No device paired')}</p>
          <p className={cn('text-xs font-bold', watchPaired ? 'text-success' : 'text-foreground/70')}>
            {watchPaired ? L('இணைக்கப்பட்டுள்ளது', 'Connected') : L('துண்டிக்கப்பட்டுள்ளது', 'Disconnected')}
          </p>
        </div>
        {watchPaired ? <Check className="size-6 text-success" aria-hidden /> : null}
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2">
        {watchPaired ? (
          <>
            <button type="button" onClick={() => triggerDetection('Smartwatch')} className="btn-thick rounded-xl bg-sos py-3 text-sm font-black text-foreground">
              {L('3 முறை அழுத்தல் சோதனை', 'Test triple-press')}
            </button>
            <button type="button" onClick={() => update({ watchPaired: null })} className="rounded-xl border-2 border-white/20 py-3 text-sm font-bold">
              {L('துண்டி', 'Unpair')}
            </button>
          </>
        ) : (
          <button
            type="button"
            onClick={pair}
            disabled={scanning}
            className="btn-thick col-span-2 flex items-center justify-center gap-2 rounded-xl bg-neon py-3.5 font-black text-background disabled:opacity-60"
          >
            {scanning ? <Loader2 className="size-5 animate-spin" aria-hidden /> : <BluetoothSearching className="size-5" aria-hidden />}
            {scanning ? L('தேடுகிறது…', 'Scanning…') : L('ஸ்மார்ட்வாட்ச் இணை', 'Pair smartwatch')}
          </button>
        )}
      </div>
    </section>
  )
}
