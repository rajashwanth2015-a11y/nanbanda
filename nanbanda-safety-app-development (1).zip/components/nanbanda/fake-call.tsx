'use client'

import { useEffect, useState } from 'react'
import { Phone, PhoneOff } from 'lucide-react'
import { useApp, vibrate } from '@/lib/store'
import { cn } from '@/lib/utils'
import { Sheet } from './primitives'

const PRESETS = ['அப்பா', 'அம்மா', 'இன்ஸ்பெக்டர்', 'பாஸ்', 'அண்ணா']

export function FakeCall({ onClose }: { onClose: () => void }) {
  const { L } = useApp()
  const [name, setName] = useState(PRESETS[0])
  const [delay, setDelay] = useState(5)
  const [phase, setPhase] = useState<'setup' | 'waiting' | 'ringing' | 'talking'>('setup')
  const [seconds, setSeconds] = useState(0)

  useEffect(() => {
    if (phase === 'waiting') {
      const id = setTimeout(() => setPhase('ringing'), delay * 1000)
      return () => clearTimeout(id)
    }
    if (phase === 'ringing') {
      vibrate([1000, 600, 1000, 600, 1000, 600, 1000])
      return () => vibrate(0)
    }
    if (phase === 'talking') {
      const id = setInterval(() => setSeconds((s) => s + 1), 1000)
      return () => clearInterval(id)
    }
  }, [phase, delay])

  if (phase === 'ringing' || phase === 'talking') {
    const mm = String(Math.floor(seconds / 60)).padStart(2, '0')
    const ss = String(seconds % 60).padStart(2, '0')
    return (
      <div
        className="absolute inset-0 z-50 flex flex-col items-center justify-between bg-gradient-to-b from-[#1c2b4a] to-black px-6 py-16 animate-in fade-in"
        role="dialog"
        aria-modal="true"
        aria-label={L(`${name} அழைக்கிறார்`, `Incoming call from ${name}`)}
      >
        <div className="text-center">
          <p className="text-sm text-white/70">{phase === 'ringing' ? L('உள்வரும் அழைப்பு…', 'Incoming call…') : `${mm}:${ss}`}</p>
          <div className="mx-auto mt-6 flex size-24 items-center justify-center rounded-full bg-white/10 text-4xl font-semibold text-white">{name.charAt(0)}</div>
          <p className="mt-4 text-3xl font-semibold text-white">{name}</p>
          <p className="mt-1 text-sm text-white/70">{L('மொபைல்', 'Mobile')} · +91 98••• ••210</p>
        </div>
        <div className="flex w-full items-center justify-around">
          <button type="button" onClick={onClose} aria-label={L('நிராகரி', 'Decline')} className="flex size-16 items-center justify-center rounded-full bg-[#e53935] text-white">
            <PhoneOff className="size-7" aria-hidden />
          </button>
          {phase === 'ringing' ? (
            <button
              type="button"
              onClick={() => {
                vibrate(0)
                setPhase('talking')
              }}
              aria-label={L('ஏற்று', 'Accept')}
              className="flex size-16 animate-bounce items-center justify-center rounded-full bg-success text-white"
            >
              <Phone className="size-7" aria-hidden />
            </button>
          ) : null}
        </div>
      </div>
    )
  }

  return (
    <Sheet title={L('போலி அழைப்பு சிமுலேட்டர்', 'Fake Call Simulator')} onClose={onClose}>
      {phase === 'waiting' ? (
        <p className="py-8 text-center text-base font-semibold text-foreground/90 text-pretty">
          {L(`${delay} வினாடிகளில் ${name} உங்களை அழைப்பார். இயல்பாக நடந்து செல்லுங்கள்.`, `${name} will call you in ${delay}s. Keep walking naturally.`)}
        </p>
      ) : (
        <>
          <label htmlFor="caller" className="block text-sm font-bold">
            {L('அழைப்பவர் பெயர்', 'Caller name')}
          </label>
          <input
            id="caller"
            value={name}
            onChange={(e) => setName(e.target.value.slice(0, 30))}
            className="mt-1.5 w-full rounded-xl border-2 border-white/20 bg-secondary px-3 py-3 text-base outline-none focus:border-primary"
          />
          <div className="mt-3 flex flex-wrap gap-2">
            {PRESETS.map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => setName(p)}
                className={cn('rounded-full border-2 px-3.5 py-1.5 text-sm font-bold', name === p ? 'border-primary bg-primary/20 text-primary' : 'border-white/20')}
              >
                {p}
              </button>
            ))}
          </div>
          <p className="mt-4 text-sm font-bold">{L('எப்போது ஒலிக்க வேண்டும்?', 'Ring after')}</p>
          <div className="mt-1.5 grid grid-cols-4 gap-2">
            {[0, 5, 15, 30].map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => setDelay(d)}
                className={cn('rounded-xl border-2 py-2.5 text-sm font-bold', delay === d ? 'border-primary bg-primary/20 text-primary' : 'border-white/20')}
              >
                {d === 0 ? L('இப்போது', 'Now') : L(`${d} வி.`, `${d}s`)}
              </button>
            ))}
          </div>
          <button
            type="button"
            disabled={!name.trim()}
            onClick={() => setPhase(delay === 0 ? 'ringing' : 'waiting')}
            className="btn-thick mt-5 w-full rounded-2xl bg-primary py-4 text-base font-black text-primary-foreground disabled:opacity-50"
          >
            {L('அழைப்பைத் திட்டமிடு', 'Schedule call')}
          </button>
        </>
      )}
    </Sheet>
  )
}
