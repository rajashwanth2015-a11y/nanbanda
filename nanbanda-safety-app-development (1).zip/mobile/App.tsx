import { useCallback, useEffect, useRef, useState } from 'react'
import { ActivityIndicator, BackHandler, Linking, Pressable, StyleSheet, Text, View } from 'react-native'
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context'
import { StatusBar } from 'expo-status-bar'
import Constants from 'expo-constants'
import * as Location from 'expo-location'
import { WebView, type WebViewNavigation } from 'react-native-webview'

const WEB_URL: string = Constants.expoConfig?.extra?.webUrl ?? 'https://nanbanda-five.vercel.app'
const WEB_ORIGIN = new URL(WEB_URL).origin

export default function App() {
  const webViewRef = useRef<WebView>(null)
  const [canGoBack, setCanGoBack] = useState(false)
  const [hasError, setHasError] = useState(false)

  useEffect(() => {
    Location.requestForegroundPermissionsAsync().catch(() => {})
  }, [])

  useEffect(() => {
    const sub = BackHandler.addEventListener('hardwareBackPress', () => {
      if (canGoBack) {
        webViewRef.current?.goBack()
        return true
      }
      return false
    })
    return () => sub.remove()
  }, [canGoBack])

  const onNavChange = useCallback((nav: WebViewNavigation) => setCanGoBack(nav.canGoBack), [])

  // tel:, sms:, whatsapp:, maps and other external links must leave the WebView so the SOS dialer works.
  const onShouldStart = useCallback((req: { url: string }) => {
    if (req.url.startsWith(WEB_ORIGIN) || req.url.startsWith('about:') || req.url.startsWith('blob:') || req.url.startsWith('data:')) {
      return true
    }
    Linking.openURL(req.url).catch(() => {})
    return false
  }, [])

  return (
    <SafeAreaProvider>
      <SafeAreaView style={styles.container} edges={['top', 'bottom']}>
        <StatusBar style="dark" />
        {hasError ? (
          <View style={styles.center}>
            <Text style={styles.errorTitle}>இணைப்பு இல்லை / No connection</Text>
            <Pressable
              style={styles.retry}
              onPress={() => {
                setHasError(false)
                webViewRef.current?.reload()
              }}
            >
              <Text style={styles.retryText}>Retry</Text>
            </Pressable>
          </View>
        ) : (
          <WebView
            ref={webViewRef}
            source={{ uri: WEB_URL }}
            style={styles.container}
            originWhitelist={['*']}
            javaScriptEnabled
            domStorageEnabled
            geolocationEnabled
            mediaPlaybackRequiresUserAction={false}
            allowsInlineMediaPlayback
            mediaCapturePermissionGrantType="grant"
            setSupportMultipleWindows={false}
            pullToRefreshEnabled
            startInLoadingState
            renderLoading={() => (
              <View style={styles.center}>
                <ActivityIndicator size="large" color="#15803d" />
              </View>
            )}
            onNavigationStateChange={onNavChange}
            onShouldStartLoadWithRequest={onShouldStart}
            onError={() => setHasError(true)}
          />
        )}
      </SafeAreaView>
    </SafeAreaProvider>
  )
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#ffffff' },
  center: { ...StyleSheet.absoluteFill, alignItems: 'center', justifyContent: 'center', gap: 16, backgroundColor: '#ffffff' },
  errorTitle: { fontSize: 18, color: '#111827' },
  retry: { backgroundColor: '#15803d', paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12 },
  retryText: { color: '#ffffff', fontSize: 16, fontWeight: '600' },
})
