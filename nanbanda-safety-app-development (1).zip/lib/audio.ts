let ctx: AudioContext | null = null

function audio() {
  if (typeof window === 'undefined') return null
  if (!ctx) {
    const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
    if (!AC) return null
    ctx = new AC()
  }
  if (ctx.state === 'suspended') void ctx.resume()
  return ctx
}

export function startSiren(volume = 0.22) {
  const c = audio()
  if (!c) return () => {}
  const osc = c.createOscillator()
  osc.type = 'sawtooth'
  osc.frequency.value = 900
  const lfo = c.createOscillator()
  lfo.frequency.value = 0.9
  const depth = c.createGain()
  depth.gain.value = 380
  lfo.connect(depth).connect(osc.frequency)
  const gain = c.createGain()
  gain.gain.value = volume
  osc.connect(gain).connect(c.destination)
  osc.start()
  lfo.start()
  return () => {
    gain.gain.setTargetAtTime(0, c.currentTime, 0.04)
    osc.stop(c.currentTime + 0.25)
    lfo.stop(c.currentTime + 0.25)
  }
}

export function beep(freq = 1250, duration = 0.32, volume = 0.3) {
  const c = audio()
  if (!c) return
  const osc = c.createOscillator()
  osc.type = 'square'
  osc.frequency.value = freq
  const gain = c.createGain()
  gain.gain.setValueAtTime(volume, c.currentTime)
  gain.gain.exponentialRampToValueAtTime(0.001, c.currentTime + duration)
  osc.connect(gain).connect(c.destination)
  osc.start()
  osc.stop(c.currentTime + duration)
}

export function chime() {
  const c = audio()
  if (!c) return
  ;[659.25, 783.99, 1046.5].forEach((f, i) => {
    const t = c.currentTime + i * 0.28
    const o = c.createOscillator()
    o.type = 'sine'
    o.frequency.value = f
    const g = c.createGain()
    g.gain.setValueAtTime(0.0001, t)
    g.gain.exponentialRampToValueAtTime(0.25, t + 0.03)
    g.gain.exponentialRampToValueAtTime(0.0001, t + 1.1)
    o.connect(g).connect(c.destination)
    o.start(t)
    o.stop(t + 1.2)
  })
}

function noiseBuffer(c: AudioContext, kind: 'white' | 'brown') {
  const len = c.sampleRate * 3
  const buf = c.createBuffer(1, len, c.sampleRate)
  const data = buf.getChannelData(0)
  let last = 0
  for (let i = 0; i < len; i++) {
    const w = Math.random() * 2 - 1
    if (kind === 'white') data[i] = w
    else {
      last = (last + 0.02 * w) / 1.02
      data[i] = last * 3.5
    }
  }
  return buf
}

export type AmbientKind = 'rain' | 'forest' | 'ocean'

export function startAmbient(kind: AmbientKind) {
  const c = audio()
  if (!c) return () => {}
  const src = c.createBufferSource()
  src.buffer = noiseBuffer(c, kind === 'rain' ? 'white' : 'brown')
  src.loop = true
  const filter = c.createBiquadFilter()
  const master = c.createGain()
  const timers: ReturnType<typeof setInterval>[] = []
  const extras: AudioScheduledSourceNode[] = []

  if (kind === 'rain') {
    filter.type = 'bandpass'
    filter.frequency.value = 2400
    filter.Q.value = 0.4
    master.gain.value = 0.28
  } else if (kind === 'ocean') {
    filter.type = 'lowpass'
    filter.frequency.value = 700
    master.gain.value = 0.35
    const swell = c.createOscillator()
    swell.frequency.value = 0.12
    const swellDepth = c.createGain()
    swellDepth.gain.value = 0.28
    swell.connect(swellDepth).connect(master.gain)
    swell.start()
    extras.push(swell)
  } else {
    filter.type = 'lowpass'
    filter.frequency.value = 1400
    master.gain.value = 0.12
    const chirp = () => {
      const t = c.currentTime
      const o = c.createOscillator()
      const g = c.createGain()
      const base = 2600 + Math.random() * 1600
      o.frequency.setValueAtTime(base, t)
      o.frequency.exponentialRampToValueAtTime(base * 1.4, t + 0.08)
      o.frequency.exponentialRampToValueAtTime(base * 0.9, t + 0.16)
      g.gain.setValueAtTime(0.0001, t)
      g.gain.exponentialRampToValueAtTime(0.06, t + 0.02)
      g.gain.exponentialRampToValueAtTime(0.0001, t + 0.18)
      o.connect(g).connect(c.destination)
      o.start(t)
      o.stop(t + 0.2)
    }
    timers.push(setInterval(() => Math.random() > 0.35 && chirp(), 900))
  }

  src.connect(filter).connect(master).connect(c.destination)
  src.start()

  return () => {
    timers.forEach(clearInterval)
    master.gain.setTargetAtTime(0, c.currentTime, 0.15)
    src.stop(c.currentTime + 0.6)
    extras.forEach((n) => n.stop(c.currentTime + 0.6))
  }
}
