export type Lang = 'ta' | 'en'

export function pick(lang: Lang, ta: string, en: string) {
  return lang === 'en' ? en : ta
}
