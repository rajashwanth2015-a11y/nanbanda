import type { GpsPoint } from './store'

export async function generatePoliceReport(opts: {
  userName: string
  imei: string
  contacts: { name: string; phone: string }[]
  gpsLog: GpsPoint[]
}) {
  const { jsPDF } = await import('jspdf')
  const doc = new jsPDF({ unit: 'pt', format: 'a4' })
  const W = doc.internal.pageSize.getWidth()
  const H = doc.internal.pageSize.getHeight()
  const now = new Date()
  const refNo = `NB-${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}-${Math.floor(Math.random() * 90000 + 10000)}`

  doc.setFillColor(15, 23, 42)
  doc.rect(0, 0, W, 90, 'F')
  doc.setTextColor(255, 255, 255)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(20)
  doc.text('NANBANDA', 40, 42)
  doc.setFontSize(11)
  doc.setFont('helvetica', 'normal')
  doc.text('Device Theft / Loss — Police Tracking Report', 40, 64)
  doc.setFillColor(249, 115, 22)
  doc.rect(0, 90, W, 4, 'F')

  doc.setTextColor(15, 23, 42)
  let y = 125
  const row = (label: string, value: string) => {
    doc.setFont('helvetica', 'bold')
    doc.text(label, 40, y)
    doc.setFont('helvetica', 'normal')
    doc.text(value, 190, y)
    y += 18
  }
  doc.setFontSize(10)
  row('Report reference', refNo)
  row('Generated at', now.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }) + ' IST')
  row('Complainant', opts.userName || '—')
  row('Device IMEI', opts.imei)
  row(
    'Emergency contacts',
    opts.contacts
      .filter((c) => c.name || c.phone)
      .map((c) => `${c.name}${c.phone ? ` (${c.phone})` : ''}`)
      .join(', ') || '—',
  )
  row('GPS points recorded', String(opts.gpsLog.length))

  y += 10
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(12)
  doc.text('Location history (most recent first)', 40, y)
  y += 16

  doc.setFillColor(241, 245, 249)
  doc.rect(40, y - 11, W - 80, 18, 'F')
  doc.setFontSize(9)
  const cols = [44, 70, 230, 330, 430]
  ;['#', 'Timestamp (IST)', 'Latitude', 'Longitude', 'Event'].forEach((h, i) => doc.text(h, cols[i], y))
  y += 18
  doc.setFont('helvetica', 'normal')

  const points = opts.gpsLog.length ? opts.gpsLog : []
  points.forEach((p, i) => {
    if (y > H - 110) {
      doc.addPage()
      y = 60
    }
    doc.text(String(i + 1), cols[0], y)
    doc.text(new Date(p.at).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }), cols[1], y)
    doc.text(p.lat.toFixed(6), cols[2], y)
    doc.text(p.lng.toFixed(6), cols[3], y)
    doc.text(p.event.slice(0, 28), cols[4], y)
    y += 15
  })
  if (!points.length) {
    doc.text('No GPS points recorded yet.', 44, y)
    y += 15
  }

  y = Math.max(y + 20, H - 100)
  if (y > H - 60) {
    doc.addPage()
    y = 60
  }
  doc.setDrawColor(203, 213, 225)
  doc.line(40, y, W - 40, y)
  doc.setFontSize(8)
  doc.setTextColor(100, 116, 139)
  doc.text(
    doc.splitTextToSize(
      'This report was auto-compiled on-device by the Nanbanda app for submission to the jurisdictional police station / CEIR portal (ceir.gov.in). The complainant has been advised not to confront any suspect directly. Coordinates are approximate and subject to device GPS accuracy.',
      W - 80,
    ),
    40,
    y + 16,
  )

  doc.save(`Nanbanda-Police-Report-${refNo}.pdf`)
  return refNo
}
